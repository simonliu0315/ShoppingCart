/*    */ package com.hitrust.regional.security;
/*    */ 
/*    */ public class RegionalSecurityException extends Exception
/*    */ {
/*    */   public RegionalSecurityException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public RegionalSecurityException(String s)
/*    */   {
/* 20 */     super(s);
/*    */   }
/*    */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.regional.security.RegionalSecurityException
 * JD-Core Version:    0.6.0
 */