/*     */ package com.hitrust.regional.security;
/*     */ 
/*     */ import au.net.aba.crypto.provider.ABAProvider;
/*     */ import au.net.aba.crypto.provider.RSAPrivKeyCrt;
/*     */ import au.net.aba.crypto.provider.RSAPubKey;
/*     */ import com.hitrust.regional.tool.ByteUtil;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.Security;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.CipherInputStream;
/*     */ import javax.crypto.CipherOutputStream;
/*     */ 
/*     */ public class RSA
/*     */ {
/*     */   public static final int MD5 = 1;
/*     */   public static final int SHA = 2;
/*     */ 
/*     */   public static RSAPrivKeyCrt loadPKCS8DERPrivKey(String strPrivateKeyFilename)
/*     */     throws RegionalSecurityException
/*     */   {
/*  43 */     Security.addProvider(new ABAProvider());
/*     */     try
/*     */     {
/*  46 */       fileInput = new FileInputStream(strPrivateKeyFilename);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       FileInputStream fileInput;
/*  49 */       throw new RegionalSecurityException(e.getMessage());
/*     */     }
/*     */     try
/*     */     {
/*     */       FileInputStream fileInput;
/*  53 */       byte[] bytes = new byte[fileInput.available()];
/*  54 */       int intRead = fileInput.read(bytes);
/*     */ 
/*  56 */       RSAPrivKeyCrt rsaPrivateKey = new RSAPrivKeyCrt(bytes);
/*     */ 
/*  58 */       fileInput.close();
/*     */     }
/*     */     catch (Exception e) {
/*  61 */       throw new RegionalSecurityException(e.getMessage());
/*     */     }
/*     */     int intRead;
/*     */     byte[] bytes;
/*     */     RSAPrivKeyCrt rsaPrivateKey;
/*  64 */     return rsaPrivateKey;
/*     */   }
/*     */ 
/*     */   public static RSAPubKey loadX509DERPublicKey(String strPublicKeyFilename)
/*     */     throws RegionalSecurityException
/*     */   {
/*  82 */     Security.addProvider(new ABAProvider());
/*     */     try
/*     */     {
/*  85 */       fileInput = new FileInputStream(strPublicKeyFilename);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       FileInputStream fileInput;
/*  88 */       throw new RegionalSecurityException(e.getMessage());
/*     */     }
/*     */     try
/*     */     {
/*     */       FileInputStream fileInput;
/*  92 */       byte[] bytes = new byte[fileInput.available()];
/*  93 */       int intRead = fileInput.read(bytes);
/*     */ 
/*  95 */       RSAPubKey rsaPublicKey = new RSAPubKey(bytes);
/*     */ 
/*  97 */       fileInput.close();
/*     */     }
/*     */     catch (Exception e) {
/* 100 */       throw new RegionalSecurityException(e.getMessage());
/*     */     }
/*     */     int intRead;
/*     */     byte[] bytes;
/*     */     RSAPubKey rsaPublicKey;
/* 103 */     return rsaPublicKey;
/*     */   }
/*     */ 
/*     */   public static byte[] rsaDec(byte[] bytesCipher, RSAPrivKeyCrt rsaPriKey, int intByteLen)
/*     */     throws RegionalSecurityException
/*     */   {
/* 120 */     byte[] bytesOriginal = new byte[intByteLen];
/*     */     try
/*     */     {
/* 123 */       Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding", "ABA");
/* 124 */       cipher.init(2, rsaPriKey);
/*     */     }
/*     */     catch (Exception e) {
/* 127 */       throw new RegionalSecurityException(e.getMessage());
/*     */     }
/*     */     Cipher cipher;
/* 130 */     ByteArrayInputStream bytesInput = new ByteArrayInputStream(bytesCipher);
/* 131 */     CipherInputStream cipherInput = new CipherInputStream(bytesInput, cipher);
/*     */     try
/*     */     {
/* 134 */       DataInputStream dIn = new DataInputStream(cipherInput);
/* 135 */       dIn.readFully(bytesOriginal);
/* 136 */       dIn.close();
/* 137 */       cipherInput.close();
/*     */     }
/*     */     catch (Exception e) {
/* 140 */       throw new RegionalSecurityException(e.getMessage());
/*     */     }
/*     */ 
/* 143 */     return bytesOriginal;
/*     */   }
/*     */ 
/*     */   public static byte[] rsaDec(byte[] bytesCipher, String strPrivKeyFilename, int intByteLen)
/*     */     throws RegionalSecurityException
/*     */   {
/* 158 */     RSAPrivKeyCrt rsaPrivKey = loadPKCS8DERPrivKey(strPrivKeyFilename);
/*     */ 
/* 160 */     return rsaDec(bytesCipher, rsaPrivKey, intByteLen);
/*     */   }
/*     */ 
/*     */   public static byte[] rsaEnc(byte[] bytesSource, RSAPubKey rsaPubKey)
/*     */     throws RegionalSecurityException
/*     */   {
/* 180 */     Security.addProvider(new ABAProvider());
/* 181 */     SecureRandom rand = new SecureRandom();
/*     */ 
/* 183 */     rand.setSeed(System.currentTimeMillis());
/*     */     try
/*     */     {
/* 186 */       Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding", "ABA");
/* 187 */       cipher.init(1, rsaPubKey, rand);
/*     */     }
/*     */     catch (Exception e) {
/* 190 */       throw new RegionalSecurityException(e.getMessage());
/*     */     }
/*     */     Cipher cipher;
/* 193 */     ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/*     */ 
/* 195 */     CipherOutputStream cipherOut = new CipherOutputStream(bytesOut, cipher);
/*     */     try
/*     */     {
/* 198 */       cipherOut.write(bytesSource);
/* 199 */       cipherOut.close();
/*     */     }
/*     */     catch (Exception e) {
/* 202 */       throw new RegionalSecurityException(e.getMessage());
/*     */     }
/*     */ 
/* 205 */     return bytesOut.toByteArray();
/*     */   }
/*     */ 
/*     */   public static byte[] rsaEnc(byte[] bytesSource, String strPubKeyFilename)
/*     */     throws RegionalSecurityException
/*     */   {
/* 220 */     RSAPubKey rsaPubKey = loadX509DERPublicKey(strPubKeyFilename);
/*     */ 
/* 222 */     return rsaEnc(bytesSource, rsaPubKey);
/*     */   }
/*     */ 
/*     */   public static byte[] rsaSign(byte[] bytesSource, RSAPrivKeyCrt rsaPrivKey, int intHashType)
/*     */     throws RegionalSecurityException
/*     */   {
/* 241 */     byte[] bytesDigest = null;
/*     */ 
/* 243 */     switch (intHashType) {
/*     */     case 1:
/* 245 */       bytesDigest = Hash.genDigest(bytesSource, "MD5");
/* 246 */       break;
/*     */     case 2:
/* 248 */       bytesDigest = Hash.genDigest(bytesSource, "SHA");
/* 249 */       break;
/*     */     default:
/* 251 */       bytesDigest = Hash.genDigest(bytesSource, "MD5");
/*     */     }
/*     */ 
/* 255 */     Security.addProvider(new ABAProvider());
/* 256 */     SecureRandom rand = new SecureRandom();
/* 257 */     rand.setSeed(System.currentTimeMillis());
/*     */     try
/*     */     {
/* 260 */       Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding", "ABA");
/* 261 */       cipher.init(1, rsaPrivKey, rand);
/*     */     }
/*     */     catch (Exception e) {
/* 264 */       throw new RegionalSecurityException(e.getMessage());
/*     */     }
/*     */     Cipher cipher;
/* 267 */     ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/*     */ 
/* 269 */     CipherOutputStream cipherOut = new CipherOutputStream(bytesOut, cipher);
/*     */     try
/*     */     {
/* 273 */       cipherOut.write(bytesDigest);
/* 274 */       cipherOut.close();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 278 */       throw new RegionalSecurityException(e.getMessage());
/*     */     }
/*     */ 
/* 281 */     return bytesOut.toByteArray();
/*     */   }
/*     */ 
/*     */   public static byte[] rsaSign(byte[] bytesSource, String strPrivKeyFilename, int intHashType)
/*     */     throws RegionalSecurityException
/*     */   {
/* 295 */     RSAPrivKeyCrt rsaPrivKey = loadPKCS8DERPrivKey(strPrivKeyFilename);
/*     */ 
/* 297 */     return rsaSign(bytesSource, rsaPrivKey, intHashType);
/*     */   }
/*     */ 
/*     */   public static boolean rsaVerify(byte[] bytesSign, byte[] bytesSource, RSAPubKey rsaPubKey, int intHashType)
/*     */     throws RegionalSecurityException
/*     */   {
/* 312 */     Security.addProvider(new ABAProvider());
/*     */ 
/* 318 */     byte[] bytesOriginal = null;
/*     */ 
/* 320 */     switch (intHashType) {
/*     */     case 1:
/* 322 */       bytesOriginal = new byte[16];
/* 323 */       break;
/*     */     case 2:
/* 325 */       bytesOriginal = new byte[20];
/* 326 */       break;
/*     */     default:
/* 328 */       bytesOriginal = new byte[16];
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 333 */       Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding", "ABA");
/* 334 */       cipher.init(2, rsaPubKey);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 338 */       throw new RegionalSecurityException(e.getMessage());
/*     */     }
/*     */     Cipher cipher;
/* 341 */     ByteArrayInputStream bytesInput = new ByteArrayInputStream(bytesSign);
/* 342 */     CipherInputStream cipherInput = new CipherInputStream(bytesInput, cipher);
/*     */     try
/*     */     {
/* 345 */       DataInputStream dIn = new DataInputStream(cipherInput);
/* 346 */       dIn.readFully(bytesOriginal);
/* 347 */       dIn.close();
/* 348 */       cipherInput.close();
/*     */     }
/*     */     catch (Exception e) {
/* 351 */       throw new RegionalSecurityException(e.getMessage());
/*     */     }
/*     */ 
/* 356 */     byte[] bytesDigest = Hash.genDigest(bytesSource, "MD5");
/*     */ 
/* 358 */     String strHexDigest = ByteUtil.bytes2HexStr(bytesDigest);
/* 359 */     String strHexSign = ByteUtil.bytes2HexStr(bytesOriginal);
/*     */ 
/* 362 */     return strHexDigest.equals(strHexSign);
/*     */   }
/*     */ 
/*     */   public static boolean rsaVerify(byte[] bytesSign, byte[] bytesSource, String strPubKeyFilename, int intHashType)
/*     */     throws RegionalSecurityException
/*     */   {
/* 383 */     RSAPubKey rsaPubKey = loadX509DERPublicKey(strPubKeyFilename);
/*     */ 
/* 385 */     return rsaVerify(bytesSign, bytesSource, rsaPubKey, intHashType);
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.regional.security.RSA
 * JD-Core Version:    0.6.0
 */