/*     */ package com.hitrust.regional.security;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.Security;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.CipherInputStream;
/*     */ import javax.crypto.CipherOutputStream;
/*     */ import javax.crypto.KeyGenerator;
/*     */ import javax.crypto.SecretKey;
/*     */ import org.bouncycastle.jce.provider.BouncyCastleProvider;
/*     */ 
/*     */ public class RC4
/*     */ {
/*     */   private static SecretKey rc4Key;
/*     */ 
/*     */   public static byte[] rc4Dec(byte[] bytesCipher, SecretKey rc4Key)
/*     */     throws RegionalSecurityException
/*     */   {
/*     */     try
/*     */     {
/*  49 */       Cipher cipher = Cipher.getInstance("RC4", "BC");
/*  50 */       cipher.init(2, rc4Key);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  54 */       throw new RegionalSecurityException(e.getMessage());
/*     */     }
/*     */     Cipher cipher;
/*  57 */     ByteArrayInputStream bytesInput = new ByteArrayInputStream(bytesCipher);
/*     */ 
/*  59 */     CipherInputStream cipherInput = new CipherInputStream(bytesInput, cipher);
/*     */     try
/*     */     {
/*  63 */       cipherInput.read(bytesCipher);
/*     */ 
/*  65 */       cipherInput.close();
/*     */     }
/*     */     catch (Exception e) {
/*  68 */       throw new RegionalSecurityException(e.getMessage());
/*     */     }
/*     */ 
/*  71 */     return bytesCipher;
/*     */   }
/*     */ 
/*     */   public static byte[] rc4Enc(byte[] bytesSource, SecretKey rc4Key)
/*     */     throws RegionalSecurityException
/*     */   {
/*     */     try
/*     */     {
/*  93 */       Cipher cipher = Cipher.getInstance("RC4", "BC");
/*  94 */       cipher.init(1, rc4Key);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  98 */       throw new RegionalSecurityException(e.getMessage());
/*     */     }
/*     */     Cipher cipher;
/* 101 */     ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/* 102 */     CipherOutputStream cipherOut = new CipherOutputStream(bytesOut, cipher);
/*     */     try
/*     */     {
/* 105 */       cipherOut.write(bytesSource);
/*     */     }
/*     */     catch (Exception e) {
/* 108 */       throw new RegionalSecurityException(e.getMessage());
/*     */     }
/*     */ 
/* 113 */     byte[] bytesCipher = bytesOut.toByteArray();
/*     */ 
/* 115 */     return bytesCipher;
/*     */   }
/*     */ 
/*     */   public static SecretKey rc4KeyGen(int intKeyLen)
/*     */     throws RegionalSecurityException
/*     */   {
/* 126 */     SecureRandom rand = new SecureRandom();
/* 127 */     KeyGenerator rc4KeyGen = null;
/*     */     try
/*     */     {
/* 130 */       rc4KeyGen = KeyGenerator.getInstance("RC4", "BC");
/* 131 */       rc4KeyGen.init(intKeyLen, rand);
/* 132 */       rc4Key = rc4KeyGen.generateKey();
/*     */     }
/*     */     catch (Exception e) {
/* 135 */       throw new RegionalSecurityException(e.getMessage());
/*     */     }
/*     */ 
/* 138 */     return rc4Key;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  18 */     Security.addProvider(new BouncyCastleProvider());
/*     */ 
/*  23 */     rc4Key = null;
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.regional.security.RC4
 * JD-Core Version:    0.6.0
 */