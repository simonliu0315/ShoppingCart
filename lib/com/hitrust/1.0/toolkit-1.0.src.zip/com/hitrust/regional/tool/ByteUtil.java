/*    */ package com.hitrust.regional.tool;
/*    */ 
/*    */ public class ByteUtil
/*    */ {
/* 13 */   private static final char[] bcdLookup = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/*    */ 
/*    */   public static String bytes2HexStr(byte[] bytes)
/*    */   {
/* 27 */     if (bytes != null) {
/* 28 */       StringBuffer temp = new StringBuffer(bytes.length * 2);
/*    */ 
/* 30 */       for (int i = 0; i < bytes.length; i++) {
/* 31 */         temp.append(bcdLookup[(bytes[i] >>> 4 & 0xF)]);
/* 32 */         temp.append(bcdLookup[(bytes[i] & 0xF)]);
/*    */       }
/*    */ 
/* 35 */       return temp.toString();
/*    */     }
/*    */ 
/* 38 */     return null;
/*    */   }
/*    */ 
/*    */   public static byte[] hexStr2Bytes(String strHex)
/*    */   {
/* 51 */     if (strHex != null)
/*    */     {
/* 54 */       byte[] bytes = new byte[strHex.length() / 2];
/*    */ 
/* 56 */       for (int i = 0; i < bytes.length; i++) {
/* 57 */         bytes[i] = (byte)Integer.parseInt(strHex.substring(2 * i, 2 * i + 2), 16);
/*    */       }
/* 59 */       return bytes;
/*    */     }
/*    */ 
/* 62 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.regional.tool.ByteUtil
 * JD-Core Version:    0.6.0
 */