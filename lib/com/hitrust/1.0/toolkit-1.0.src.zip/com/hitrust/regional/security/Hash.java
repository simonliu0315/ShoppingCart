/*    */ package com.hitrust.regional.security;
/*    */ 
/*    */ import com.hitrust.regional.tool.ByteUtil;
/*    */ import java.security.MessageDigest;
/*    */ 
/*    */ public class Hash
/*    */ {
/*    */   public static byte[] genDigest(byte[] bytesSource, String strAlgorithm)
/*    */     throws RegionalSecurityException
/*    */   {
/*    */     try
/*    */     {
/* 41 */       digest = MessageDigest.getInstance(strAlgorithm);
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */       MessageDigest digest;
/* 44 */       throw new RegionalSecurityException(e.getMessage());
/*    */     }
/*    */     MessageDigest digest;
/* 47 */     digest.update(bytesSource);
/* 48 */     byte[] bytesDigest = digest.digest();
/*    */ 
/* 50 */     return bytesDigest;
/*    */   }
/*    */ 
/*    */   public static String genDigest2String(byte[] bytesSource, String strAlgorithm)
/*    */     throws RegionalSecurityException
/*    */   {
/* 63 */     return ByteUtil.bytes2HexStr(genDigest(bytesSource, strAlgorithm));
/*    */   }
/*    */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.regional.security.Hash
 * JD-Core Version:    0.6.0
 */