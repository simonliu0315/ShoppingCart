/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.util.HiServer;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class TenpayItemTrx extends B2CPay
/*     */ {
/*     */   public void transaction()
/*     */   {
/*  26 */     boolean logflag = false;
/*     */     try {
/*  28 */       if (isEmpty(getStoreId())) {
/*  29 */         throw new ToolkitException("-32");
/*     */       }
/*  31 */       getHiMerchant();
/*     */ 
/*  33 */       getLogger();
/*     */ 
/*  35 */       setShip_fee_mode("2");
/*  36 */       setWeight("1");
/*  37 */       setLength("1");
/*  38 */       setWidth("1");
/*  39 */       setHeight("1");
/*  40 */       logflag = true;
/*     */ 
/*  42 */       this.log.info("----- New TenpayItem Start -----");
/*  43 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*     */ 
/*  46 */       checkData();
/*  47 */       this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/*  50 */       organizeMessage();
/*  51 */       this.log.info("Organize Message [ ok ].");
/*     */ 
/*  54 */       this.log.info("Send Message......");
/*  55 */       connectTo(HiServer.getTenpayItemUrl());
/*  56 */       this.log.info("Receive Response [ ok ].");
/*     */ 
/*  59 */       parserResult();
/*  60 */       this.log.info("parsing Message[ ok ].");
/*     */ 
/*  62 */       this.log.info("----- New TenpayItem End -----\n");
/*     */     } catch (ToolkitException e) {
/*  64 */       setRetCode(e.getMessage());
/*  65 */       if (logflag) {
/*  66 */         this.log.info("Run Error! Code ==" + getRetCode());
/*  67 */         this.log.info("----- New TenpayItem End -----\n");
/*     */       }
/*     */     } catch (Exception e) {
/*  70 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkData() throws ToolkitException, Exception
/*     */   {
/*  76 */     int type = Integer.parseInt(getType());
/*  77 */     this.log.info("[P]TrxType      = " + type);
/*  78 */     if ((isEmpty(getType())) || (type < 23) || (type > 28)) {
/*  79 */       this.log.error("<Toolkit MSG> Input Parameter [TrxType] is wrong.");
/*  80 */       throw new ToolkitException("-45");
/*     */     }
/*  82 */     String[] trxType = { "Item_CREATE", "Item_MODIFY", "Item_QUERY", "REFUND_Query", "Item_DELETE" };
/*     */ 
/*  84 */     this.log.info("[P]TrxType      = " + trxType[(Integer.parseInt(getType()) - 23)]);
/*     */ 
/*  86 */     if (type != 25) {
/*  87 */       if (isEmpty(getProdNo())) {
/*  88 */         this.log.error("<Toolkit MSG> Input Parameter [Item prodNo is null or empty.");
/*  89 */         throw new ToolkitException("-70");
/*     */       }
/*  91 */       this.log.info("[P]ProdNo      = " + getOrderNo());
/*     */     }
/*     */ 
/*  94 */     if (getType().equals("23")) {
/*  95 */       if (isEmpty(getProdName())) {
/*  96 */         this.log.error("<Toolkit MSG> Input Parameter [Item prodName is null or empty.");
/*  97 */         throw new ToolkitException("-71");
/*     */       }
/*  99 */       this.log.info("[P]ProdName      = " + getProdName());
/*     */     }
/*     */ 
/* 105 */     if ((getType().equals("23")) || (getType().equals("24"))) {
/* 106 */       if (isEmpty(getAmount())) {
/* 107 */         this.log.error("<Toolkit MSG> Input Parameter [AMOUNT] is null or empty.");
/* 108 */         throw new ToolkitException("-35");
/*     */       }
/* 110 */       this.log.info("[P]Amount       = " + getAmount());
/*     */     }
/*     */ 
/* 113 */     if (getType().equals("23")) {
/* 114 */       Pattern regex = Pattern.compile("[$&+,:;=?@#|]");
/* 115 */       Matcher matcher = regex.matcher(getProdName());
/* 116 */       if (matcher.matches())
/*     */       {
/* 118 */         this.log.error("<Toolkit MSG> Input Parameter [Item prodName is null or empty.");
/* 119 */         throw new Exception("-71");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void organizeMessage() throws ToolkitException, Exception {
/* 125 */     String message = "";
/* 126 */     message = "T01=" + getType() + "&" + "T03=" + getStoreId() + "&" + "E43=" + getProdNo() + "&" + "E44=" + getProdName() + "&" + "T06=" + getAmount() + "&" + "E46=" + getWeight() + "&" + "E49=" + getLength() + "&" + "E50=" + getWidth() + "&" + "E51=" + getHeight() + "&" + "E47=" + getShip_fee_mode();
/*     */ 
/* 136 */     System.out.println(message);
/* 137 */     if (isEmpty(message)) {
/* 138 */       this.log.error("<Toolkit MSG> No Request Message.");
/* 139 */       throw new ToolkitException("-3");
/*     */     }
/* 141 */     setRequestMessage(message);
/*     */   }
/*     */ 
/*     */   private void parserResult() {
/* 145 */     setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/*     */ 
/* 147 */     if ("25".equals(getType())) {
/* 148 */       setProdName(parsingKeyword(getResponseMessage(), "E44"));
/* 149 */       setProdNo(parsingKeyword(getResponseMessage(), "E43"));
/* 150 */       setAmount(parsingKeyword(getResponseMessage(), "T06"));
/*     */     }
/* 152 */     this.log.info("@ResponseMessage        = " + getResponseMessage());
/* 153 */     this.log.info("@ProdName        = " + getProdName());
/* 154 */     this.log.info("@ProdNo         = " + getProdNo());
/* 155 */     this.log.info("@RetCode        = " + getRetCode());
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.TenpayItemTrx
 * JD-Core Version:    0.6.0
 */