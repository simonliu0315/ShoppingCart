/*    */ package com.hitrust.b2ctoolkit.util;
/*    */ 
/*    */ public class ToolkitException extends Exception
/*    */ {
/*    */   public ToolkitException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ToolkitException(String s)
/*    */   {
/* 23 */     super(s);
/*    */   }
/*    */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.util.ToolkitException
 * JD-Core Version:    0.6.0
 */