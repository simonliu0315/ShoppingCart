/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.util.HiServer;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class TenpayItemTrx20150706 extends B2CPay
/*     */ {
/*     */   public void transaction()
/*     */   {
/*  26 */     boolean logflag = false;
/*     */     try {
/*  28 */       if (isEmpty(getStoreId())) {
/*  29 */         throw new ToolkitException("-32");
/*     */       }
/*  31 */       getHiMerchant();
/*     */ 
/*  33 */       getLogger();
/*     */ 
/*  35 */       setShip_fee_mode("0");
/*  36 */       setWeight("0");
/*  37 */       logflag = true;
/*     */ 
/*  39 */       this.log.info("----- New TenpayItem Start -----");
/*  40 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*     */ 
/*  43 */       checkData();
/*  44 */       this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/*  47 */       organizeMessage();
/*  48 */       this.log.info("Organize Message [ ok ].");
/*     */ 
/*  51 */       this.log.info("Send Message......");
/*  52 */       connectTo(HiServer.getTenpayItemUrl());
/*  53 */       this.log.info("Receive Response [ ok ].");
/*     */ 
/*  56 */       parserResult();
/*  57 */       this.log.info("parsing Message[ ok ].");
/*     */ 
/*  59 */       this.log.info("----- New TenpayItem End -----\n");
/*     */     } catch (ToolkitException e) {
/*  61 */       setRetCode(e.getMessage());
/*  62 */       if (logflag) {
/*  63 */         this.log.info("Run Error! Code ==" + getRetCode());
/*  64 */         this.log.info("----- New TenpayItem End -----\n");
/*     */       }
/*     */     } catch (Exception e) {
/*  67 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkData() throws ToolkitException, Exception
/*     */   {
/*  73 */     int type = Integer.parseInt(getType());
/*     */ 
/*  75 */     if ((isEmpty(getType())) || (type < 23) || (type > 26)) {
/*  76 */       this.log.error("<Toolkit MSG> Input Parameter [TrxType] is wrong.");
/*  77 */       throw new ToolkitException("-45");
/*     */     }
/*     */ 
/*  80 */     String[] trxType = { "Item_CREATE", "Item_MODIFY", "Item_QUERY" };
/*     */ 
/*  82 */     this.log.info("[P]TrxType      = " + trxType[(Integer.parseInt(getType()) - 23)]);
/*     */ 
/*  84 */     if (type != 25) {
/*  85 */       if (isEmpty(getProdNo())) {
/*  86 */         this.log.error("<Toolkit MSG> Input Parameter [Item prodNo is null or empty.");
/*  87 */         throw new ToolkitException("-70");
/*     */       }
/*  89 */       this.log.info("[P]ProdNo      = " + getOrderNo());
/*     */     }
/*     */ 
/*  92 */     if (getType().equals("23")) {
/*  93 */       if (isEmpty(getProdName())) {
/*  94 */         this.log.error("<Toolkit MSG> Input Parameter [Item prodName is null or empty.");
/*  95 */         throw new ToolkitException("-71");
/*     */       }
/*  97 */       this.log.info("[P]ProdName      = " + getProdName());
/*     */     }
/*     */ 
/* 103 */     if ((getType().equals("23")) || (getType().equals("24"))) {
/* 104 */       if (isEmpty(getAmount())) {
/* 105 */         this.log.error("<Toolkit MSG> Input Parameter [AMOUNT] is null or empty.");
/* 106 */         throw new ToolkitException("-35");
/*     */       }
/* 108 */       this.log.info("[P]Amount       = " + getAmount());
/*     */     }
/*     */ 
/* 111 */     if (getType().equals("23")) {
/* 112 */       Pattern regex = Pattern.compile("[$&+,:;=?@#|]");
/* 113 */       Matcher matcher = regex.matcher(getProdName());
/* 114 */       if (matcher.matches())
/*     */       {
/* 116 */         this.log.error("<Toolkit MSG> Input Parameter [Item prodName is null or empty.");
/* 117 */         throw new Exception("-71");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void organizeMessage() throws ToolkitException, Exception {
/* 123 */     String message = "";
/* 124 */     message = "T01=" + getType() + "&" + "T03=" + getStoreId() + "&" + "E43=" + getProdNo() + "&" + "E44=" + getProdName() + "&" + "T06=" + getAmount() + "&" + "E46=" + getWeight() + "&" + "E47=" + getShip_fee_mode();
/*     */ 
/* 132 */     if (isEmpty(message)) {
/* 133 */       this.log.error("<Toolkit MSG> No Request Message.");
/* 134 */       throw new ToolkitException("-3");
/*     */     }
/* 136 */     setRequestMessage(message);
/*     */   }
/*     */ 
/*     */   private void parserResult() {
/* 140 */     setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/*     */ 
/* 142 */     if ("25".equals(getType())) {
/* 143 */       setProdName(parsingKeyword(getResponseMessage(), "E44"));
/* 144 */       setProdNo(parsingKeyword(getResponseMessage(), "E43"));
/* 145 */       setAmount(parsingKeyword(getResponseMessage(), "T06"));
/*     */     }
/* 147 */     this.log.info("@ResponseMessage        = " + getResponseMessage());
/* 148 */     this.log.info("@ProdName        = " + getProdName());
/* 149 */     this.log.info("@ProdNo         = " + getProdNo());
/* 150 */     this.log.info("@RetCode        = " + getRetCode());
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.TenpayItemTrx20150706
 * JD-Core Version:    0.6.0
 */