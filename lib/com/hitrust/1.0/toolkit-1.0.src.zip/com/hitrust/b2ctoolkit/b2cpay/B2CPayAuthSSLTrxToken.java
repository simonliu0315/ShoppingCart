/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.util.HiMerchant;
/*     */ import com.hitrust.b2ctoolkit.util.HiServer;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class B2CPayAuthSSLTrxToken extends B2CPay
/*     */ {
/*     */   public void transaction()
/*     */   {
/*  27 */     boolean logflag = false;
/*     */     try {
/*  29 */       if (isEmpty(getStoreId())) {
/*  30 */         throw new ToolkitException("-32");
/*     */       }
/*  32 */       getHiMerchant();
/*     */ 
/*  34 */       getLogger();
/*     */ 
/*  36 */       logflag = true;
/*     */ 
/*  38 */       this.log.info("----- New AuthSSLTrxToken Start  -----");
/*  39 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*     */ 
/*  43 */       setType("22");
/*     */ 
/*  46 */       checkData();
/*  47 */       this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/*  50 */       organizeMessage();
/*  51 */       this.log.info("Organize Message [ ok ].");
/*     */ 
/*  54 */       this.log.info("Send Message......");
/*  55 */       connectTo(HiServer.getOtherUrl());
/*  56 */       this.log.info("Receive Response [ ok ].");
/*     */ 
/*  59 */       parserResult();
/*  60 */       this.log.info("parsing Message [ ok ].");
/*     */ 
/*  62 */       this.log.info("----- New AuthSSLTrxToken End  -----\n");
/*     */     } catch (ToolkitException e) {
/*  64 */       setRetCode(e.getMessage());
/*  65 */       if (logflag) {
/*  66 */         this.log.info("Run Error! Code ==" + getRetCode());
/*  67 */         this.log.info("----- New AuthSSLTrxToken End  -----\n");
/*     */       }
/*     */     } catch (Exception e) {
/*  70 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkData() throws ToolkitException, Exception
/*     */   {
/*  76 */     if (isEmpty(getType())) {
/*  77 */       this.log.error("<Toolkit MSG> Input Parameter [TrxType] is wrong.");
/*  78 */       throw new ToolkitException("-45");
/*     */     }
/*     */ 
/*  81 */     if (isEmpty(getOrderNo())) {
/*  82 */       this.log.error("<Toolkit MSG> Input Parameter [ORDERNO] is null or empty.");
/*  83 */       throw new ToolkitException("-31");
/*     */     }
/*  85 */     this.log.info("[P]OrderNo      = " + getOrderNo());
/*     */ 
/*  88 */     if (isEmpty(getOrderDesc())) {
/*  89 */       if (isEmpty(this.hiMerchant.getOrderDesc())) {
/*  90 */         this.log.error("<Toolkit MSG> Input Parameter [ORDERDESC] is null or empty.");
/*  91 */         throw new ToolkitException("-33");
/*     */       }
/*  93 */       setOrderDesc(this.hiMerchant.getOrderDesc());
/*  94 */       this.log.info("[C]OrderDesc    = " + getOrderDesc());
/*     */     }
/*     */     else {
/*  97 */       this.log.info("[P]OrderDesc    = " + getOrderDesc());
/*     */     }
/*     */ 
/* 100 */     if (isEmpty(getCurrency())) {
/* 101 */       if (isEmpty(this.hiMerchant.getCurrency())) {
/* 102 */         this.log.error("<Toolkit MSG> Input Parameter [CURRENCY] is null or empty.");
/* 103 */         throw new ToolkitException("-34");
/*     */       }
/* 105 */       setCurrency(this.hiMerchant.getCurrency());
/* 106 */       this.log.info("[C]Currency     = " + getCurrency());
/*     */     }
/*     */     else {
/* 109 */       this.log.info("[P]Currency     = " + getCurrency());
/*     */     }
/*     */ 
/* 112 */     if (isEmpty(getAmount())) {
/* 113 */       this.log.error("<Toolkit MSG> Input Parameter [AMOUNT] is null or empty.");
/* 114 */       throw new ToolkitException("-35");
/*     */     }
/* 116 */     this.log.info("[P]Amount       = " + getAmount());
/*     */ 
/* 119 */     if (isEmpty(getReturnURL())) {
/* 120 */       if (isEmpty(this.hiMerchant.getReturnURL())) {
/* 121 */         this.log.error("<Toolkit MSG> Input Parameter [RETURNURL] is null or empty.");
/* 122 */         throw new ToolkitException("-37");
/*     */       }
/* 124 */       setReturnURL(this.hiMerchant.getReturnURL());
/* 125 */       this.log.info("[C]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */     else {
/* 128 */       this.log.info("[P]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */ 
/* 131 */     if (isEmpty(getDepositFlag())) {
/* 132 */       if (isEmpty(this.hiMerchant.getDeposit())) {
/* 133 */         this.log.error("<Toolkit MSG> Input Parameter [DEPOSIT] is null or empty.");
/* 134 */         throw new ToolkitException("-38");
/*     */       }
/* 136 */       setDepositFlag(this.hiMerchant.getDeposit());
/* 137 */       this.log.info("[C]Deposit      = " + getDepositFlag());
/*     */     }
/*     */     else {
/* 140 */       this.log.info("[P]Deposit      = " + getDepositFlag());
/*     */     }
/*     */ 
/* 143 */     if (isEmpty(getQueryFlag())) {
/* 144 */       if (isEmpty(this.hiMerchant.getQueryFlag())) {
/* 145 */         this.log.error("<Toolkit MSG> Input Parameter [QUERYFLAG] is null or empty.");
/* 146 */         throw new ToolkitException("-39");
/*     */       }
/* 148 */       setQueryFlag(this.hiMerchant.getQueryFlag());
/* 149 */       this.log.info("[C]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */     else {
/* 152 */       this.log.info("[P]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */ 
/* 155 */     if (isEmpty(getUpdateURL())) {
/* 156 */       if (isEmpty(this.hiMerchant.getUpdateURL())) {
/* 157 */         this.log.error("<Toolkit MSG> Input Parameter [UPDATEURL] is null or empty.");
/* 158 */         throw new ToolkitException("-40");
/*     */       }
/* 160 */       setUpdateURL(this.hiMerchant.getUpdateURL());
/* 161 */       this.log.info("[C]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */     else {
/* 164 */       this.log.info("[P]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */ 
/* 168 */     if (getTicketNo() == null) setTicketNo("");
/* 169 */     if (getPan() == null) setPan("");
/* 170 */     if (getExpiry() == null) setExpiry("");
/* 171 */     if (getE01() == null) setE01("");
/* 172 */     if (getE02() == null) setE02("");
/* 173 */     if (getE03() == null) setE03("");
/* 174 */     if (getE04() == null) setE04("");
/* 175 */     if (getE05() == null) setE05("");
/* 176 */     if (getE11() == null) setE11("");
/* 177 */     if (getE12() == null) setE12("");
/* 178 */     if (getE13() == null) setE13("");
/* 179 */     if (getE14() == null) setE14("");
/* 180 */     if (getE36() == null) setE36("");
/* 181 */     if (getE37() == null) setE37("");
/* 182 */     if (getE38() == null) setE38("");
/* 183 */     if (getE39() == null) setE39("");
/* 184 */     if (getE40() == null) setE40("");
/* 185 */     if (getE41() == null) setE41("");
/* 186 */     if (getE42() == null) setE42("");
/* 187 */     if (getE52() == null) setE52("");
/* 188 */     if (getE53() == null) setE53("");
/* 189 */     if (getE54() == null) setE54("");
/*     */ 
/* 191 */     this.log.info("[P]TicketNo     = " + getTicketNo());
/*     */ 
/* 203 */     if (isEmpty(getTrxToken())) {
/* 204 */       this.log.error("-76");
/* 205 */       throw new ToolkitException("<Toolkit MSG> Input Parameter [TrxToken] is null or empty.");
/*     */     }
/* 207 */     this.log.info("[P]TrxToken     = " + getTrxToken());
/*     */ 
/* 210 */     if ((!isEmpty(getE36())) && 
/* 211 */       (getE36().length() > 10)) {
/* 212 */       this.log.error("<Toolkit MSG> Input Parameter [ID] is null or empty or format error.");
/* 213 */       throw new ToolkitException("-60");
/*     */     }
/* 215 */     if ((!isEmpty(getE37())) && 
/* 216 */       (getE37().length() > 15)) {
/* 217 */       this.log.error("<Toolkit MSG> Input Parameter [CELLPHONE] is null or empty or length error.");
/* 218 */       throw new ToolkitException("-61");
/*     */     }
/*     */ 
/* 221 */     if (!isEmpty(getE38())) {
/* 222 */       if (getE38().length() != 4) {
/* 223 */         this.log.error("<Toolkit MSG> Input Parameter [YEAR_OF_BIRTH] is null or empty or length error.");
/* 224 */         throw new ToolkitException("-62");
/* 225 */       }if (getE39().length() == 0) {
/* 226 */         this.log.error("<Toolkit MSG> Input Parameter [MMDD_OF_BIRTH] is null or empty or length error.");
/* 227 */         throw new ToolkitException("-63");
/*     */       }
/*     */     }
/*     */ 
/* 231 */     if (!isEmpty(getE39())) {
/* 232 */       if (getE39().length() != 4) {
/* 233 */         this.log.error("<Toolkit MSG> Input Parameter [MMDD_OF_BIRTH] is null or empty or length error.");
/* 234 */         throw new ToolkitException("-63");
/* 235 */       }if (getE38().length() == 0) {
/* 236 */         this.log.error("<Toolkit MSG> Input Parameter [YEAR_OF_BIRTH] is null or empty or length error.");
/* 237 */         throw new ToolkitException("-62");
/*     */       }
/*     */     }
/* 239 */     if ((!"".equals(getE40())) && (null != getE40()) && 
/* 240 */       (getE40().length() > 15)) {
/* 241 */       this.log.error("<Toolkit MSG> Input Parameter [HomePHONE] is null or empty or length error.");
/* 242 */       throw new ToolkitException("-64");
/*     */     }
/*     */ 
/* 245 */     if ((!"".equals(getE41())) && (null != getE41()) && 
/* 246 */       (getE41().length() > 15)) {
/* 247 */       this.log.error("<Toolkit MSG> Input Parameter [OfficePHONE] is null or empty or length error.");
/* 248 */       throw new ToolkitException("-65");
/*     */     }
/*     */ 
/* 251 */     if ("Y".equalsIgnoreCase(getE42()))
/*     */     {
/* 253 */       if (("".equals(getE36().trim())) && ("".equals(getE37().trim())) && ("".equals(getE38().trim())) && ("".equals(getE39().trim())) && ("".equals(getE40().trim())) && ("".equals(getE41().trim()))) {
/* 254 */         this.log.error("<Toolkit MSG> Input Parameter all is blank for identifying.");
/* 255 */         throw new ToolkitException("-66");
/*     */       }
/* 257 */       if ("1".equals(getDepositFlag())) {
/* 258 */         this.log.error("<Toolkit MSG> Input Parameter only for identifying cannot with depositeflag.");
/* 259 */         throw new ToolkitException("-67");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 266 */     if (!isEmpty(getE52()))
/*     */     {
/* 269 */       if (getE52().matches("[0-9]{8}"))
/*     */       {
/* 272 */         if (!isEmpty(getE53()))
/*     */         {
/* 274 */           if (!getE53().matches("[0-9]{4}"))
/*     */           {
/* 276 */             this.log.error("<Toolkit MSG> Input Parameter [E54] format error.");
/* 277 */             throw new ToolkitException("-74");
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 282 */           this.log.error("<Toolkit MSG> Input Parameter [E53] is null or empty.");
/* 283 */           throw new ToolkitException("-73");
/*     */         }
/*     */ 
/* 287 */         if (!isEmpty(getE54()))
/*     */         {
/* 289 */           if (getE54().length() > 10)
/*     */           {
/* 291 */             this.log.error("<Toolkit MSG> Input Parameter [E54] format error.");
/* 292 */             throw new ToolkitException("-74");
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 297 */           this.log.error("<Toolkit MSG> Input Parameter [E54] is null or empty.");
/* 298 */           throw new ToolkitException("-75");
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 303 */         this.log.error("<Toolkit MSG> Input Parameter [E52] format error.");
/* 304 */         throw new ToolkitException("-72");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 310 */     this.log.info("[P]E02          = " + getE02());
/* 311 */     this.log.info("[P]E03          = " + getE03());
/* 312 */     this.log.info("[P]E04          = " + getE04());
/* 313 */     this.log.info("[P]E05          = " + getE05());
/*     */ 
/* 315 */     this.log.info("[P]E11          = " + getE11());
/* 316 */     this.log.info("[P]E12          = " + getE12());
/* 317 */     this.log.info("[P]E13          = " + getE13());
/* 318 */     this.log.info("[P]E14          = " + getE14());
/*     */ 
/* 320 */     this.log.info("[P]E15          = " + getName());
/* 321 */     this.log.info("[P]E16          = " + getEmail());
/* 322 */     this.log.info("[P]E17          = " + getE17());
/*     */ 
/* 333 */     this.log.info("[P]E52          = " + getE52());
/* 334 */     this.log.info("[P]E53          = " + getE53());
/* 335 */     this.log.info("[P]E54          = " + getE54());
/*     */   }
/*     */ 
/*     */   private void organizeMessage() throws ToolkitException, Exception
/*     */   {
/* 340 */     String message = "";
/* 341 */     message = "T01=" + getType() + "&" + "T02=" + getOrderNo() + "&" + "T03=" + getStoreId() + "&" + "T04=" + getOrderDesc() + "&" + "T05=" + getCurrency() + "&" + "T06=" + getAmount() + "&" + "T08=" + getReturnURL() + "&" + "T09=" + getDepositFlag() + "&" + "T10=" + getQueryFlag() + "&" + "T11=" + getExtendField() + "&" + "T12=" + getUpdateURL() + "&" + "T13=" + getPan() + "&" + "T14=" + getExpiry() + "&" + "T15=" + getMerUpdateURL() + "&" + "T16=" + getTrxToken() + "&" + "O01=" + getTicketNo() + "&" + "E01=" + getE01() + "&" + "E02=" + getE02() + "&" + "E03=" + getE03() + "&" + "E04=" + getE04() + "&" + "E05=" + getE05() + "&" + "E11=" + getE11() + "&" + "E12=" + getE12() + "&" + "E13=" + getE13() + "&" + "E14=" + getE14() + "&" + "E15=" + getName() + "&" + "E16=" + getEmail() + "&" + "E17=" + getE17() + "&" + "E36=" + getE36() + "&" + "E37=" + getE37() + "&" + "E38=" + getE38() + "&" + "E39=" + getE39() + "&" + "E40=" + getE40() + "&" + "E41=" + getE41() + "&" + "E42=" + getE42() + "&" + "E52=" + getE52() + "&" + "E53=" + getE53() + "&" + "E54=" + getE54();
/*     */ 
/* 381 */     if (isEmpty(message)) {
/* 382 */       this.log.error("<Toolkit MSG> No Request Message.");
/* 383 */       throw new ToolkitException("-3");
/*     */     }
/* 385 */     setRequestMessage(message);
/*     */   }
/*     */ 
/*     */   private void parserResult() {
/* 389 */     setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/* 390 */     setOrderDesc(parsingKeyword(getResponseMessage(), "T04"));
/* 391 */     setCurrency(parsingKeyword(getResponseMessage(), "T05"));
/* 392 */     if (getQueryFlag().equals("1")) {
/* 393 */       setSecCode(parsingKeyword(getResponseMessage(), "R02"));
/* 394 */       setAuthCode(parsingKeyword(getResponseMessage(), "R03"));
/* 395 */       setAuthRRN(parsingKeyword(getResponseMessage(), "R04"));
/* 396 */       setOrderStatus(parsingKeyword(getResponseMessage(), "R05"));
/* 397 */       setCreditStatus(parsingKeyword(getResponseMessage(), "R06"));
/* 398 */       setAcquirer(parsingKeyword(getResponseMessage(), "R07"));
/* 399 */       setCardType(parsingKeyword(getResponseMessage(), "R08"));
/* 400 */       setApproveAmount(parsingKeyword(getResponseMessage(), "R09"));
/* 401 */       setCaptureAmount(parsingKeyword(getResponseMessage(), "R10"));
/* 402 */       setCaptureNum(parsingKeyword(getResponseMessage(), "R11"));
/* 403 */       setRefundAmount(parsingKeyword(getResponseMessage(), "R12"));
/* 404 */       setRefundNum(parsingKeyword(getResponseMessage(), "R13"));
/* 405 */       setOrderDate(parsingKeyword(getResponseMessage(), "R14"));
/* 406 */       setPayBatchNum(parsingKeyword(getResponseMessage(), "R15"));
/* 407 */       setCaptureCode(parsingKeyword(getResponseMessage(), "R16"));
/* 408 */       setCaptureDate(parsingKeyword(getResponseMessage(), "R17"));
/* 409 */       setPaymentNum(parsingKeyword(getResponseMessage(), "R18"));
/* 410 */       setRefundBatch(parsingKeyword(getResponseMessage(), "R20"));
/* 411 */       setRefundCode(parsingKeyword(getResponseMessage(), "R21"));
/* 412 */       setRefundRRN(parsingKeyword(getResponseMessage(), "R22"));
/* 413 */       setRefundDate(parsingKeyword(getResponseMessage(), "R23"));
/* 414 */       setToken(parsingKeyword(getResponseMessage(), "R24"));
/* 415 */       setEci(parsingKeyword(getResponseMessage(), "R25"));
/*     */ 
/* 420 */       setE28(parsingKeyword(getResponseMessage(), "E28"));
/* 421 */       setE29(parsingKeyword(getResponseMessage(), "E29"));
/*     */ 
/* 423 */       setRedemordernum(parsingKeyword(getResponseMessage(), "R28"));
/* 424 */       setRedem_discount_point(parsingKeyword(getResponseMessage(), "R29"));
/* 425 */       setRedem_discount_amount(parsingKeyword(getResponseMessage(), "R30"));
/* 426 */       setRedem_purchase_amount(parsingKeyword(getResponseMessage(), "R31"));
/* 427 */       setRedem_balance_point(parsingKeyword(getResponseMessage(), "R32"));
/*     */     }
/*     */ 
/* 430 */     this.log.info("@RC             = " + getRetCode());
/* 431 */     this.log.info("@Token          = " + getToken());
/* 432 */     this.log.info("@E06            = " + getE06());
/* 433 */     this.log.info("@E07            = " + getE07());
/* 434 */     this.log.info("@E08            = " + getE08());
/* 435 */     this.log.info("@E09            = " + getE09());
/* 436 */     this.log.info("@E10            = " + getE10());
/* 437 */     this.log.info("@AuthCode       = " + getAuthCode());
/* 438 */     this.log.info("@AuthRRN        = " + getAuthRRN());
/* 439 */     this.log.info("@CardType       = " + getCardType());
/* 440 */     this.log.info("@OrderStatus    = " + getOrderStatus());
/* 441 */     this.log.info("@Acquirer       = " + getAcquirer());
/* 442 */     this.log.info("@ApproveAmount  = " + getApproveAmount());
/* 443 */     this.log.info("@CaptureAmount  = " + getCaptureAmount());
/* 444 */     this.log.info("@RefundAmount   = " + getRefundAmount());
/* 445 */     this.log.info("@OrderDate      = " + getOrderDate());
/* 446 */     this.log.info("@PayBatchNum    = " + getPayBatchNum());
/* 447 */     this.log.info("@CaptureDate    = " + getCaptureDate());
/* 448 */     this.log.info("@RefundBatch    = " + getRefundBatch());
/* 449 */     this.log.info("@RefundCode     = " + getRefundCode());
/* 450 */     this.log.info("@RefundRRN      = " + getRefundRRN());
/* 451 */     this.log.info("@RefundDate     = " + getRefundDate());
/* 452 */     this.log.info("@ECI            = " + getEci());
/* 453 */     this.log.info("@E28            = " + getE28());
/* 454 */     this.log.info("@E29            = " + getE29());
/* 455 */     this.log.info("@Redemordernum         = " + getRedemordernum());
/* 456 */     this.log.info("@Redem_discount_point  = " + getRedem_discount_point());
/* 457 */     this.log.info("@Redem_discount_amount = " + getRedem_discount_amount());
/* 458 */     this.log.info("@Redem_purchase_amount = " + getRedem_purchase_amount());
/* 459 */     this.log.info("@Redem_balance_point   = " + getRedem_balance_point());
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.B2CPayAuthSSLTrxToken
 * JD-Core Version:    0.6.0
 */