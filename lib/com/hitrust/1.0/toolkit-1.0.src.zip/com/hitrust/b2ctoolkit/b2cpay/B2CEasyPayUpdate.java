/*    */ package com.hitrust.b2ctoolkit.b2cpay;
/*    */ 
/*    */ import com.hitrust.b2ctoolkit.util.HiServer;
/*    */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*    */ import java.util.HashMap;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class B2CEasyPayUpdate extends B2CBase
/*    */ {
/*    */   private String orderId;
/*    */   private String token;
/* 13 */   private int actionId = -1;
/*    */ 
/*    */   public B2CEasyPayUpdate(String storeId) {
/* 16 */     super(storeId, "31");
/*    */   }
/*    */ 
/*    */   public int getActionId() {
/* 20 */     return this.actionId;
/*    */   }
/*    */ 
/*    */   public String getOrderId() {
/* 24 */     return this.orderId;
/*    */   }
/*    */ 
/*    */   public String getToken() {
/* 28 */     return this.token;
/*    */   }
/*    */ 
/*    */   protected void handleResponse(HashMap tagsFromResponse)
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ 
/*    */   protected void prepareData(HashMap tagsForSend) throws ToolkitException
/*    */   {
/* 38 */     if (isEmpty(this.orderId)) {
/* 39 */       this.log.error("<Toolkit MSG> Input Parameter [ORDERNO] is null or empty.");
/* 40 */       throw new ToolkitException("-31");
/*    */     }
/*    */ 
/* 43 */     if (isEmpty(this.token)) {
/* 44 */       this.log.error("<Toolkit MSG> Input Parameter [TrxToken] is null or empty.");
/* 45 */       throw new ToolkitException("-76");
/*    */     }
/*    */ 
/* 48 */     if (isEmpty(getEmail())) {
/* 49 */       this.log.error("<Toolkit MSG> Input Parameter [EMAIL] is null or empty.");
/* 50 */       throw new ToolkitException("-48");
/*    */     }
/*    */ 
/* 53 */     if (this.actionId == -1) {
/* 54 */       this.log.error("action id is empty");
/* 55 */       throw new IllegalArgumentException("action id is empty");
/*    */     }
/*    */ 
/* 58 */     tagsForSend.put("T03", getStoreId());
/* 59 */     tagsForSend.put("T02", this.orderId);
/* 60 */     tagsForSend.put("T16", this.token);
/* 61 */     tagsForSend.put("E66", this.actionId + "");
/* 62 */     tagsForSend.put("E16", getEmail());
/*    */   }
/*    */ 
/*    */   public void changeStatusTo(int actionId)
/*    */   {
/* 67 */     if ((actionId != 5) && (actionId != 0))
/*    */     {
/* 69 */       throw new IllegalArgumentException("action id is invalid: " + actionId);
/*    */     }
/* 71 */     this.actionId = actionId;
/*    */   }
/*    */ 
/*    */   public void setOrderId(String orderId) {
/* 75 */     this.orderId = orderId;
/*    */   }
/*    */ 
/*    */   public void setToken(String token) {
/* 79 */     this.token = token;
/*    */   }
/*    */ 
/*    */   protected String getConnectTargetURL() throws ToolkitException {
/* 83 */     return HiServer.getOtherUrl();
/*    */   }
/*    */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.B2CEasyPayUpdate
 * JD-Core Version:    0.6.0
 */