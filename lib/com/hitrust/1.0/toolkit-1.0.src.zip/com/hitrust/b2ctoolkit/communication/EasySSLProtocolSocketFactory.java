/*     */ package com.hitrust.b2ctoolkit.communication;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import javax.net.ssl.TrustManager;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ import org.apache.commons.httpclient.protocol.SecureProtocolSocketFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class EasySSLProtocolSocketFactory
/*     */   implements SecureProtocolSocketFactory
/*     */ {
/*  42 */   private static final Log LOG = LogFactory.getLog(EasySSLProtocolSocketFactory.class);
/*  43 */   public static boolean isJdk17Up = false;
/*  44 */   static String currentTLSver = "TLSv1.2";
/*     */   private static TrustManager[] trustAllCerts;
/*     */ 
/*     */   public static SSLSocketFactory getEasySSLSocketFactory()
/*     */   {
/*  76 */     SSLContext context = null;
/*     */     try
/*     */     {
/*  83 */       LOG.info("Current TLS Version : " + currentTLSver);
/*  84 */       context = SSLContext.getInstance(currentTLSver);
/*  85 */       context.init(null, trustAllCerts, new SecureRandom());
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  94 */       LOG.error(e.getMessage(), e);
/*  95 */       e.printStackTrace();
/*  96 */       throw new RuntimeException(e.toString());
/*     */     }
/*  98 */     return context.getSocketFactory();
/*     */   }
/*     */ 
/*     */   public Socket createSocket(String host, int port, InetAddress clientHost, int clientPort)
/*     */     throws IOException, UnknownHostException
/*     */   {
/* 112 */     Socket socket = enableTLSOnSocket(getEasySSLSocketFactory().createSocket(host, port, clientHost, clientPort));
/*     */ 
/* 118 */     return socket;
/*     */   }
/*     */ 
/*     */   public Socket createSocket(String host, int port)
/*     */     throws IOException, UnknownHostException
/*     */   {
/* 126 */     return enableTLSOnSocket(getEasySSLSocketFactory().createSocket(host, port));
/*     */   }
/*     */ 
/*     */   public Socket createSocket(Socket socket, String host, int port, boolean autoClose)
/*     */     throws IOException, UnknownHostException
/*     */   {
/* 141 */     return enableTLSOnSocket(getEasySSLSocketFactory().createSocket(socket, host, port, autoClose));
/*     */   }
/*     */ 
/*     */   private Socket enableTLSOnSocket(Socket socket)
/*     */   {
/* 169 */     if ((socket != null) && ((socket instanceof SSLSocket))) {
/* 170 */       if (isJdk17Up)
/* 171 */         ((SSLSocket)socket).setEnabledProtocols(new String[] { "TLSv1", "TLSv1.1", "TLSv1.2" });
/*     */       else {
/* 173 */         ((SSLSocket)socket).setEnabledProtocols(new String[] { "TLS" });
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 178 */     return socket;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  46 */     LOG.info("Current Java Version : " + System.getProperty("java.version"));
/*  47 */     String verStr = System.getProperty("java.version").substring(0, 3);
/*  48 */     if (Double.parseDouble(verStr) >= 1.7D) {
/*  49 */       currentTLSver = "TLSv1.2";
/*  50 */       isJdk17Up = true;
/*     */     } else {
/*  52 */       currentTLSver = "TLS";
/*  53 */       isJdk17Up = false;
/*     */     }
/*     */ 
/* 148 */     trustAllCerts = new TrustManager[] { new X509TrustManager()
/*     */     {
/*     */       public X509Certificate[] getAcceptedIssuers()
/*     */       {
/* 152 */         return null;
/*     */       }
/*     */ 
/*     */       public void checkClientTrusted(X509Certificate[] arg0, String arg1)
/*     */         throws CertificateException
/*     */       {
/*     */       }
/*     */ 
/*     */       public void checkServerTrusted(X509Certificate[] arg0, String arg1)
/*     */         throws CertificateException
/*     */       {
/*     */       }
/*     */     }
/*     */      };
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.communication.EasySSLProtocolSocketFactory
 * JD-Core Version:    0.6.0
 */