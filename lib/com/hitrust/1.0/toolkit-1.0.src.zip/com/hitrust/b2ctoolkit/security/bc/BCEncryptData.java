/*    */ package com.hitrust.b2ctoolkit.security.bc;
/*    */ 
/*    */ import com.hitrust.b2ctoolkit.security.SecurityUtil;
/*    */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*    */ import com.hitrust.regional.tool.ByteUtil;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.security.MessageDigest;
/*    */ import java.security.SecureRandom;
/*    */ import java.security.Security;
/*    */ import javax.crypto.Cipher;
/*    */ import javax.crypto.CipherOutputStream;
/*    */ import javax.crypto.KeyGenerator;
/*    */ import javax.crypto.SecretKey;
/*    */ import org.bouncycastle.jce.provider.BouncyCastleProvider;
/*    */ 
/*    */ public class BCEncryptData
/*    */ {
/* 23 */   private SecretKey exportKey = null;
/*    */ 
/*    */   public BCEncryptData() {
/* 26 */     if (Security.getProvider("BC") == null)
/* 27 */       Security.addProvider(new BouncyCastleProvider());
/*    */   }
/*    */ 
/*    */   public String getCIPHER(String strData, int iKeyLen) throws ToolkitException
/*    */   {
/*    */     try {
/* 33 */       SecureRandom rand = new SecureRandom();
/* 34 */       KeyGenerator keyGenerator = KeyGenerator.getInstance("RC4", "BC");
/* 35 */       keyGenerator.init(iKeyLen, rand);
/* 36 */       this.exportKey = keyGenerator.generateKey();
/*    */ 
/* 38 */       Cipher cipher = Cipher.getInstance("RC4", "BC");
/* 39 */       cipher.init(1, this.exportKey);
/* 40 */       byte[] bytesCipher = cipher.doFinal(strData.getBytes());
/* 41 */       String strCipher = ByteUtil.bytes2HexStr(bytesCipher);
/*    */ 
/* 43 */       return strCipher;
/*    */     }
/*    */     catch (Exception e) {
/* 46 */       e.printStackTrace();
/* 47 */     }throw new ToolkitException("-16");
/*    */   }
/*    */ 
/*    */   public String getKEY(String strPubKeyName) throws ToolkitException
/*    */   {
/*    */     try {
/* 53 */       SecureRandom rand = new SecureRandom();
/* 54 */       rand.setSeed(System.currentTimeMillis());
/* 55 */       Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding", "BC");
/* 56 */       cipher.init(1, SecurityUtil.loadX509DERPublicKey(strPubKeyName), rand);
/*    */ 
/* 60 */       ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/*    */ 
/* 62 */       CipherOutputStream cipherOut = new CipherOutputStream(bytesOut, cipher);
/*    */ 
/* 64 */       cipherOut.write(this.exportKey.getEncoded());
/* 65 */       cipherOut.close();
/* 66 */       String strKey = ByteUtil.bytes2HexStr(bytesOut.toByteArray());
/*    */ 
/* 68 */       return strKey; } catch (Exception e) {
/*    */     }
/* 70 */     throw new ToolkitException("-23");
/*    */   }
/*    */ 
/*    */   public String getMAC(String strData, String strPrivateKeyFilename) throws ToolkitException
/*    */   {
/*    */     try {
/* 76 */       MessageDigest digest = MessageDigest.getInstance("MD5");
/* 77 */       digest.update(strData.getBytes());
/*    */ 
/* 79 */       Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding", "BC");
/*    */ 
/* 81 */       cipher.init(1, SecurityUtil.loadPKCS8DERPrivKey(strPrivateKeyFilename));
/* 82 */       byte[] cipherText = cipher.doFinal(digest.digest());
/*    */ 
/* 84 */       return ByteUtil.bytes2HexStr(cipherText); } catch (Exception e) {
/*    */     }
/* 86 */     throw new ToolkitException("-27");
/*    */   }
/*    */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.security.bc.BCEncryptData
 * JD-Core Version:    0.6.0
 */