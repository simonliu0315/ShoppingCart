/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.security.bc.BCDecryptData;
/*     */ import com.hitrust.b2ctoolkit.util.HiMerchant;
/*     */ import com.hitrust.b2ctoolkit.util.HiServer;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class B2CPayUpdate extends B2CPay
/*     */ {
/*     */   private String key;
/*     */   private String cipher;
/*     */   private String mac;
/*     */ 
/*     */   public void setKey(String key)
/*     */   {
/*  25 */     this.key = key;
/*     */   }
/*     */   public void setCipher(String cipher) {
/*  28 */     this.cipher = cipher;
/*     */   }
/*     */   public void setMac(String mac) {
/*  31 */     this.mac = mac;
/*     */   }
/*     */   public void transaction() {
/*  34 */     boolean logflag = false;
/*     */     try {
/*  36 */       if (isEmpty(getStoreId())) {
/*  37 */         throw new ToolkitException("-32");
/*     */       }
/*  39 */       getHiMerchant();
/*     */ 
/*  41 */       getLogger();
/*     */ 
/*  43 */       logflag = true;
/*     */ 
/*  45 */       this.log.info("----- New Update Start  -----");
/*  46 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*     */ 
/*  49 */       checkData();
/*  50 */       this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/*  53 */       setResponseMessage(BCDecryptData.decrypt(this.cipher, this.key, this.mac, this.hiMerchant.getRSAName(), HiServer.getRSAName()));
/*  54 */       this.log.info("Decrypt Message [ ok ].");
/*     */ 
/*  57 */       parserResult();
/*  58 */       this.log.info("parsing Message [ ok ].");
/*     */ 
/*  61 */       this.log.info("----- New Update End  -----\n");
/*     */     } catch (ToolkitException e) {
/*  63 */       setRetCode(e.getMessage());
/*  64 */       if (logflag) {
/*  65 */         this.log.info("Run Error! Code ==" + getRetCode());
/*  66 */         this.log.info("----- New Update End  -----\n");
/*     */       }
/*     */     } catch (Exception e) {
/*  69 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkData() throws ToolkitException
/*     */   {
/*  75 */     if (isEmpty(this.key)) {
/*  76 */       this.log.error("<Toolkit MSG> Input Parameter [KEY] is null or empty.");
/*  77 */       throw new ToolkitException("-42");
/*     */     }
/*  79 */     if (isEmpty(this.mac)) {
/*  80 */       this.log.error("<Toolkit MSG> Input Parameter [MAC] is null or empty.");
/*  81 */       throw new ToolkitException("-43");
/*     */     }
/*  83 */     if (isEmpty(this.cipher)) {
/*  84 */       this.log.error("<Toolkit MSG> Input Parameter [CIPHER] is null or empty.");
/*  85 */       throw new ToolkitException("-44");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void parserResult() {
/*  90 */     setType(parsingKeyword(getResponseMessage(), "T01"));
/*  91 */     setOrderNo(parsingKeyword(getResponseMessage(), "T02"));
/*  92 */     setStoreId(parsingKeyword(getResponseMessage(), "T03"));
/*  93 */     setOrderDesc(parsingKeyword(getResponseMessage(), "T04"));
/*  94 */     setCurrency(parsingKeyword(getResponseMessage(), "T05"));
/*  95 */     setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/*  96 */     setSecCode(parsingKeyword(getResponseMessage(), "R02"));
/*  97 */     setAuthCode(parsingKeyword(getResponseMessage(), "R03"));
/*  98 */     setAuthRRN(parsingKeyword(getResponseMessage(), "R04"));
/*  99 */     setOrderStatus(parsingKeyword(getResponseMessage(), "R05"));
/* 100 */     setCreditStatus(parsingKeyword(getResponseMessage(), "R06"));
/* 101 */     setAcquirer(parsingKeyword(getResponseMessage(), "R07"));
/* 102 */     setCardType(parsingKeyword(getResponseMessage(), "R08"));
/* 103 */     setApproveAmount(parsingKeyword(getResponseMessage(), "R09"));
/* 104 */     setCaptureAmount(parsingKeyword(getResponseMessage(), "R10"));
/* 105 */     setCaptureNum(parsingKeyword(getResponseMessage(), "R11"));
/* 106 */     setRefundAmount(parsingKeyword(getResponseMessage(), "R12"));
/* 107 */     setRefundNum(parsingKeyword(getResponseMessage(), "R13"));
/* 108 */     setOrderDate(parsingKeyword(getResponseMessage(), "R14"));
/* 109 */     setPayBatchNum(parsingKeyword(getResponseMessage(), "R15"));
/* 110 */     setCaptureCode(parsingKeyword(getResponseMessage(), "R16"));
/* 111 */     setCaptureDate(parsingKeyword(getResponseMessage(), "R17"));
/* 112 */     setPaymentNum(parsingKeyword(getResponseMessage(), "R18"));
/* 113 */     setRefundBatch(parsingKeyword(getResponseMessage(), "R20"));
/* 114 */     setRefundCode(parsingKeyword(getResponseMessage(), "R21"));
/* 115 */     setRefundRRN(parsingKeyword(getResponseMessage(), "R22"));
/* 116 */     setRefundDate(parsingKeyword(getResponseMessage(), "R23"));
/* 117 */     setToken(parsingKeyword(getResponseMessage(), "R24"));
/* 118 */     setEci(parsingKeyword(getResponseMessage(), "R25"));
/* 119 */     setE06(parsingKeyword(getResponseMessage(), "E06"));
/* 120 */     setE07(parsingKeyword(getResponseMessage(), "E07"));
/* 121 */     setE08(parsingKeyword(getResponseMessage(), "E08"));
/* 122 */     setE09(parsingKeyword(getResponseMessage(), "E09"));
/* 123 */     setE10(parsingKeyword(getResponseMessage(), "E10"));
/*     */ 
/* 126 */     setName(parsingKeyword(getResponseMessage(), "E15"));
/* 127 */     setEmail(parsingKeyword(getResponseMessage(), "E16"));
/* 128 */     setE17(parsingKeyword(getResponseMessage(), "E17"));
/* 129 */     setE18(parsingKeyword(getResponseMessage(), "E18"));
/* 130 */     setE19(parsingKeyword(getResponseMessage(), "E19"));
/* 131 */     setE20(parsingKeyword(getResponseMessage(), "E20"));
/* 132 */     setE21(parsingKeyword(getResponseMessage(), "E21"));
/* 133 */     setE25(parsingKeyword(getResponseMessage(), "E25"));
/* 134 */     setE26(parsingKeyword(getResponseMessage(), "E26"));
/* 135 */     setE27(parsingKeyword(getResponseMessage(), "E27"));
/*     */ 
/* 138 */     setAuthhostdate(parsingKeyword(getResponseMessage(), "R26"));
/* 139 */     setAuthhosttime(parsingKeyword(getResponseMessage(), "R27"));
/* 140 */     setRedemordernum(parsingKeyword(getResponseMessage(), "R28"));
/* 141 */     setRedem_discount_point(parsingKeyword(getResponseMessage(), "R29"));
/* 142 */     setRedem_discount_amount(parsingKeyword(getResponseMessage(), "R30"));
/* 143 */     setRedem_purchase_amount(parsingKeyword(getResponseMessage(), "R31"));
/* 144 */     setRedem_balance_point(parsingKeyword(getResponseMessage(), "R32"));
/* 145 */     setCavv(parsingKeyword(getResponseMessage(), "R33"));
/*     */ 
/* 148 */     setE28(parsingKeyword(getResponseMessage(), "E28"));
/* 149 */     setE29(parsingKeyword(getResponseMessage(), "E29"));
/*     */ 
/* 152 */     setPan(parsingKeyword(getResponseMessage(), "T13"));
/*     */ 
/* 155 */     setTrxToken(parsingKeyword(getResponseMessage(), "R34"));
/* 156 */     setExpiry(parsingKeyword(getResponseMessage(), "R35"));
/* 157 */     setPan(parsingKeyword(getResponseMessage(), "R37"));
/*     */ 
/* 160 */     setMerUpdateURL(parsingKeyword(getResponseMessage(), "T15"));
/*     */ 
/* 162 */     this.log.info("@OrderNo        = " + getOrderNo());
/* 163 */     this.log.info("@OrderDesc      = " + getOrderDesc());
/* 164 */     this.log.info("@RetCode        = " + getRetCode());
/* 165 */     this.log.info("@AuthCode       = " + getAuthCode());
/* 166 */     this.log.info("@AuthRRN        = " + getAuthRRN());
/* 167 */     this.log.info("@CardType       = " + getCardType());
/* 168 */     this.log.info("@OrderStatus    = " + getOrderStatus());
/* 169 */     this.log.info("@Acquirer       = " + getAcquirer());
/* 170 */     this.log.info("@ApproveAmount  = " + getApproveAmount());
/* 171 */     this.log.info("@CaptureAmount  = " + getCaptureAmount());
/* 172 */     this.log.info("@RefundAmount   = " + getRefundAmount());
/* 173 */     this.log.info("@OrderDate      = " + getOrderDate());
/* 174 */     this.log.info("@PayBatchNum    = " + getPayBatchNum());
/* 175 */     this.log.info("@CaptureDate    = " + getCaptureDate());
/* 176 */     this.log.info("@RefundBatch    = " + getRefundBatch());
/* 177 */     this.log.info("@RefundCode     = " + getRefundCode());
/* 178 */     this.log.info("@RefundRRN      = " + getRefundRRN());
/* 179 */     this.log.info("@RefundDate     = " + getRefundDate());
/* 180 */     this.log.info("@Currency       = " + getCurrency());
/* 181 */     this.log.info("@ECI            = " + getEci());
/* 182 */     this.log.info("@E06            = " + getE06());
/* 183 */     this.log.info("@E07            = " + getE07());
/* 184 */     this.log.info("@E08            = " + getE08());
/* 185 */     this.log.info("@E09            = " + getE09());
/* 186 */     this.log.info("@E10            = " + getE10());
/*     */ 
/* 188 */     this.log.info("@E15            = " + getName());
/* 189 */     this.log.info("@E16            = " + getEmail());
/* 190 */     this.log.info("@E17            = " + getE17());
/* 191 */     this.log.info("@E18            = " + getE18());
/* 192 */     this.log.info("@E19            = " + getE19());
/* 193 */     this.log.info("@E20            = " + getE20());
/* 194 */     this.log.info("@E21            = " + getE21());
/* 195 */     this.log.info("@E25            = " + getE25());
/* 196 */     this.log.info("@E26            = " + getE26());
/* 197 */     this.log.info("@E27            = " + getE27());
/* 198 */     this.log.info("@E28            = " + getE28());
/* 199 */     this.log.info("@E29            = " + getE29());
/*     */ 
/* 202 */     this.log.info("@Authhostdate          = " + getAuthhostdate());
/* 203 */     this.log.info("@Authhosttime          = " + getAuthhosttime());
/* 204 */     this.log.info("@Redemordernum         = " + getRedemordernum());
/* 205 */     this.log.info("@Redem_discount_point  = " + getRedem_discount_point());
/* 206 */     this.log.info("@Redem_discount_amount = " + getRedem_discount_amount());
/* 207 */     this.log.info("@Redem_purchase_amount = " + getRedem_purchase_amount());
/* 208 */     this.log.info("@Redem_balance_point   = " + getRedem_balance_point());
/* 209 */     this.log.info("@Cavv                  = " + getCavv());
/*     */ 
/* 212 */     this.log.info("@SN                    = " + getSN());
/* 213 */     this.log.info("@PAN                   = " + getPan());
/*     */ 
/* 216 */     this.log.info("@TrxToken              = " + getTrxToken());
/* 217 */     this.log.info("@Expiry                = " + getExpiry());
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.B2CPayUpdate
 * JD-Core Version:    0.6.0
 */