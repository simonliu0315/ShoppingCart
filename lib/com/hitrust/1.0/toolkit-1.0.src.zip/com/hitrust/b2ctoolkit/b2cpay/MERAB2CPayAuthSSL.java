/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.util.HiMerchant;
/*     */ import com.hitrust.b2ctoolkit.util.HiServer;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class MERAB2CPayAuthSSL extends B2CPay
/*     */ {
/*     */   public void transaction()
/*     */   {
/*  21 */     boolean logflag = false;
/*     */     try {
/*  23 */       if (isEmpty(getStoreId())) {
/*  24 */         throw new ToolkitException("-32");
/*     */       }
/*  26 */       getHiMerchant();
/*     */ 
/*  28 */       getLogger();
/*     */ 
/*  30 */       logflag = true;
/*     */ 
/*  32 */       this.log.info("----- New AuthSSL Start  -----");
/*  33 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*     */ 
/*  36 */       setType("20");
/*     */ 
/*  39 */       checkData();
/*  40 */       this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/*  43 */       organizeMessage();
/*  44 */       this.log.info("Organize Message [ ok ].");
/*     */ 
/*  47 */       this.log.info("Send Message......");
/*  48 */       connectTo(HiServer.getOtherUrl());
/*  49 */       this.log.info("Receive Response [ ok ].");
/*     */ 
/*  52 */       parserResult();
/*  53 */       this.log.info("parsing Message [ ok ].");
/*     */ 
/*  55 */       this.log.info("----- New AuthSSL End  -----\n");
/*     */     } catch (ToolkitException e) {
/*  57 */       setRetCode(e.getMessage());
/*  58 */       if (logflag) {
/*  59 */         this.log.info("Run Error! Code ==" + getRetCode());
/*  60 */         this.log.info("----- New AuthSSL End  -----\n");
/*     */       }
/*     */     } catch (Exception e) {
/*  63 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkData() throws ToolkitException, Exception
/*     */   {
/*  69 */     if (isEmpty(getType())) {
/*  70 */       this.log.error("<Toolkit MSG> Input Parameter [TrxType] is wrong.");
/*  71 */       throw new ToolkitException("-45");
/*     */     }
/*     */ 
/*  74 */     if (isEmpty(getPan())) {
/*  75 */       this.log.error("<Toolkit MSG> Input Parameter [Pan] is null or empty or format error.");
/*  76 */       throw new ToolkitException("-56");
/*     */     }
/*     */ 
/*  79 */     if (isEmpty(getPan2())) {
/*  80 */       this.log.error("<Toolkit MSG> Input Parameter [Pan2] is null or empty or format error.");
/*  81 */       throw new ToolkitException("-57");
/*     */     }
/*     */ 
/*  84 */     if (isEmpty(getExpiry())) {
/*  85 */       this.log.error("<Toolkit MSG> Input Parameter [Expiry] is null or empty or format error.");
/*  86 */       throw new ToolkitException("-58");
/*     */     }
/*     */ 
/*  89 */     if (isEmpty(getE01())) {
/*  90 */       this.log.error("<Toolkit MSG> Input Parameter [CVV2] is null or empty or format error.");
/*  91 */       throw new ToolkitException("-59");
/*     */     }
/*     */ 
/*  94 */     if (isEmpty(getOrderNo())) {
/*  95 */       this.log.error("<Toolkit MSG> Input Parameter [ORDERNO] is null or empty.");
/*  96 */       throw new ToolkitException("-31");
/*     */     }
/*  98 */     this.log.info("[P]OrderNo      = " + getOrderNo());
/*     */ 
/* 101 */     if (isEmpty(getOrderDesc())) {
/* 102 */       if (isEmpty(this.hiMerchant.getOrderDesc())) {
/* 103 */         this.log.error("<Toolkit MSG> Input Parameter [ORDERDESC] is null or empty.");
/* 104 */         throw new ToolkitException("-33");
/*     */       }
/* 106 */       setOrderDesc(this.hiMerchant.getOrderDesc());
/* 107 */       this.log.info("[C]OrderDesc    = " + getOrderDesc());
/*     */     }
/*     */     else {
/* 110 */       this.log.info("[P]OrderDesc    = " + getOrderDesc());
/*     */     }
/*     */ 
/* 113 */     if (isEmpty(getCurrency())) {
/* 114 */       if (isEmpty(this.hiMerchant.getCurrency())) {
/* 115 */         this.log.error("<Toolkit MSG> Input Parameter [CURRENCY] is null or empty.");
/* 116 */         throw new ToolkitException("-34");
/*     */       }
/* 118 */       setCurrency(this.hiMerchant.getCurrency());
/* 119 */       this.log.info("[C]Currency     = " + getCurrency());
/*     */     }
/*     */     else {
/* 122 */       this.log.info("[P]Currency     = " + getCurrency());
/*     */     }
/*     */ 
/* 125 */     if (isEmpty(getAmount())) {
/* 126 */       this.log.error("<Toolkit MSG> Input Parameter [AMOUNT] is null or empty.");
/* 127 */       throw new ToolkitException("-35");
/*     */     }
/* 129 */     this.log.info("[P]Amount       = " + getAmount());
/*     */ 
/* 132 */     if (isEmpty(getReturnURL())) {
/* 133 */       if (isEmpty(this.hiMerchant.getReturnURL())) {
/* 134 */         this.log.error("<Toolkit MSG> Input Parameter [RETURNURL] is null or empty.");
/* 135 */         throw new ToolkitException("-37");
/*     */       }
/* 137 */       setReturnURL(this.hiMerchant.getReturnURL());
/* 138 */       this.log.info("[C]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */     else {
/* 141 */       this.log.info("[P]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */ 
/* 144 */     if (isEmpty(getDepositFlag())) {
/* 145 */       if (isEmpty(this.hiMerchant.getDeposit())) {
/* 146 */         this.log.error("<Toolkit MSG> Input Parameter [DEPOSIT] is null or empty.");
/* 147 */         throw new ToolkitException("-38");
/*     */       }
/* 149 */       setDepositFlag(this.hiMerchant.getDeposit());
/* 150 */       this.log.info("[C]Deposit      = " + getDepositFlag());
/*     */     }
/*     */     else {
/* 153 */       this.log.info("[P]Deposit      = " + getDepositFlag());
/*     */     }
/*     */ 
/* 156 */     if (isEmpty(getQueryFlag())) {
/* 157 */       if (isEmpty(this.hiMerchant.getQueryFlag())) {
/* 158 */         this.log.error("<Toolkit MSG> Input Parameter [QUERYFLAG] is null or empty.");
/* 159 */         throw new ToolkitException("-39");
/*     */       }
/* 161 */       setQueryFlag(this.hiMerchant.getQueryFlag());
/* 162 */       this.log.info("[C]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */     else {
/* 165 */       this.log.info("[P]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */ 
/* 168 */     if (isEmpty(getUpdateURL())) {
/* 169 */       if (isEmpty(this.hiMerchant.getUpdateURL())) {
/* 170 */         this.log.error("<Toolkit MSG> Input Parameter [UPDATEURL] is null or empty.");
/* 171 */         throw new ToolkitException("-40");
/*     */       }
/* 173 */       setUpdateURL(this.hiMerchant.getUpdateURL());
/* 174 */       this.log.info("[C]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */     else {
/* 177 */       this.log.info("[P]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */ 
/* 193 */     if (getTicketNo() == null) setTicketNo("");
/* 194 */     if (getPan() == null) setPan("");
/* 195 */     if (getPan2() == null) setPan2("");
/* 196 */     if (getExpiry() == null) setExpiry("");
/* 197 */     if (getE01() == null) setE01("");
/* 198 */     if (getE02() == null) setE02("");
/* 199 */     if (getE03() == null) setE03("");
/* 200 */     if (getE04() == null) setE04("");
/* 201 */     if (getE05() == null) setE05("");
/* 202 */     if (getE12() == null) setE12("");
/* 203 */     if (getE13() == null) setE13("");
/* 204 */     if (getE14() == null) setE14("");
/*     */ 
/* 206 */     this.log.info("[P]TicketNo     = " + getTicketNo());
/* 207 */     this.log.info("[P]PAN          = " + getPan());
/* 208 */     this.log.info("[P]PAN2         = " + getExtendField());
/*     */ 
/* 211 */     this.log.info("[P]E02          = " + getE02());
/* 212 */     this.log.info("[P]E03          = " + getE03());
/* 213 */     this.log.info("[P]E04          = " + getE04());
/* 214 */     this.log.info("[P]E05          = " + getE05());
/* 215 */     this.log.info("[P]E12          = " + getE12());
/* 216 */     this.log.info("[P]E13          = " + getE13());
/* 217 */     this.log.info("[P]E14          = " + getE14());
/*     */   }
/*     */ 
/*     */   private void organizeMessage() throws ToolkitException, Exception
/*     */   {
/* 222 */     String message = "";
/* 223 */     message = "T01=" + getType() + "&" + "T02=" + getOrderNo() + "&" + "T03=" + getStoreId() + "&" + "T04=" + getOrderDesc() + "&" + "T05=" + getCurrency() + "&" + "T06=" + getAmount() + "&" + "T08=" + getReturnURL() + "&" + "T09=" + getDepositFlag() + "&" + "T10=" + getQueryFlag() + "&" + "T11=" + getExtendField() + "&" + "T12=" + getUpdateURL() + "&" + "T13=" + getPan() + "&" + "T14=" + getExpiry() + "&" + "T15=" + getMerUpdateURL() + "&" + "O01=" + getTicketNo() + "&" + "E01=" + getE01() + "&" + "E02=" + getE02() + "&" + "E03=" + getE03() + "&" + "E04=" + getE04() + "&" + "E05=" + getE05() + "&" + "E11=" + getE11() + "&" + "E12=" + getE12() + "&" + "E13=" + getE13() + "&" + "E14=" + getE14();
/*     */ 
/* 248 */     if (isEmpty(message)) {
/* 249 */       this.log.error("<Toolkit MSG> No Request Message.");
/* 250 */       throw new ToolkitException("-3");
/*     */     }
/* 252 */     setRequestMessage(message);
/*     */   }
/*     */ 
/*     */   private void parserResult() {
/* 256 */     setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/* 257 */     setOrderDesc(parsingKeyword(getResponseMessage(), "T04"));
/* 258 */     setCurrency(parsingKeyword(getResponseMessage(), "T05"));
/* 259 */     if (getQueryFlag().equals("1")) {
/* 260 */       setSecCode(parsingKeyword(getResponseMessage(), "R02"));
/* 261 */       setAuthCode(parsingKeyword(getResponseMessage(), "R03"));
/* 262 */       setAuthRRN(parsingKeyword(getResponseMessage(), "R04"));
/* 263 */       setOrderStatus(parsingKeyword(getResponseMessage(), "R05"));
/* 264 */       setCreditStatus(parsingKeyword(getResponseMessage(), "R06"));
/* 265 */       setAcquirer(parsingKeyword(getResponseMessage(), "R07"));
/* 266 */       setCardType(parsingKeyword(getResponseMessage(), "R08"));
/* 267 */       setApproveAmount(parsingKeyword(getResponseMessage(), "R09"));
/* 268 */       setCaptureAmount(parsingKeyword(getResponseMessage(), "R10"));
/* 269 */       setCaptureNum(parsingKeyword(getResponseMessage(), "R11"));
/* 270 */       setRefundAmount(parsingKeyword(getResponseMessage(), "R12"));
/* 271 */       setRefundNum(parsingKeyword(getResponseMessage(), "R13"));
/* 272 */       setOrderDate(parsingKeyword(getResponseMessage(), "R14"));
/* 273 */       setPayBatchNum(parsingKeyword(getResponseMessage(), "R15"));
/* 274 */       setCaptureCode(parsingKeyword(getResponseMessage(), "R16"));
/* 275 */       setCaptureDate(parsingKeyword(getResponseMessage(), "R17"));
/* 276 */       setPaymentNum(parsingKeyword(getResponseMessage(), "R18"));
/* 277 */       setRefundBatch(parsingKeyword(getResponseMessage(), "R20"));
/* 278 */       setRefundCode(parsingKeyword(getResponseMessage(), "R21"));
/* 279 */       setRefundRRN(parsingKeyword(getResponseMessage(), "R22"));
/* 280 */       setRefundDate(parsingKeyword(getResponseMessage(), "R23"));
/* 281 */       setToken(parsingKeyword(getResponseMessage(), "R24"));
/* 282 */       setEci(parsingKeyword(getResponseMessage(), "R25"));
/*     */     }
/*     */ 
/* 285 */     this.log.info("@RC             = " + getRetCode());
/* 286 */     this.log.info("@Token          = " + getToken());
/* 287 */     this.log.info("@E06            = " + getE06());
/* 288 */     this.log.info("@E07            = " + getE07());
/* 289 */     this.log.info("@E08            = " + getE08());
/* 290 */     this.log.info("@E09            = " + getE09());
/* 291 */     this.log.info("@E10            = " + getE10());
/* 292 */     this.log.info("@AuthCode       = " + getAuthCode());
/* 293 */     this.log.info("@AuthRRN        = " + getAuthRRN());
/* 294 */     this.log.info("@CardType       = " + getCardType());
/* 295 */     this.log.info("@OrderStatus    = " + getOrderStatus());
/* 296 */     this.log.info("@Acquirer       = " + getAcquirer());
/* 297 */     this.log.info("@ApproveAmount  = " + getApproveAmount());
/* 298 */     this.log.info("@CaptureAmount  = " + getCaptureAmount());
/* 299 */     this.log.info("@RefundAmount   = " + getRefundAmount());
/* 300 */     this.log.info("@OrderDate      = " + getOrderDate());
/* 301 */     this.log.info("@PayBatchNum    = " + getPayBatchNum());
/* 302 */     this.log.info("@CaptureDate    = " + getCaptureDate());
/* 303 */     this.log.info("@RefundBatch    = " + getRefundBatch());
/* 304 */     this.log.info("@RefundCode     = " + getRefundCode());
/* 305 */     this.log.info("@RefundRRN      = " + getRefundRRN());
/* 306 */     this.log.info("@RefundDate     = " + getRefundDate());
/* 307 */     this.log.info("@ECI            = " + getEci());
/*     */   }
/*     */ 
/*     */   public String getPan2() {
/* 311 */     return getExtendField();
/*     */   }
/*     */ 
/*     */   public void setPan2(String pan2) {
/* 315 */     setExtendField(pan2);
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.MERAB2CPayAuthSSL
 * JD-Core Version:    0.6.0
 */