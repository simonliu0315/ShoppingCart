/*      */ package com.hitrust.b2ctoolkit.b2cpay;
/*      */ 
/*      */ import com.hitrust.b2ctoolkit.communication.HttpComm;
/*      */ import com.hitrust.b2ctoolkit.security.bc.BCDecryptData;
/*      */ import com.hitrust.b2ctoolkit.security.bc.BCEncryptData;
/*      */ import com.hitrust.b2ctoolkit.util.HiMerchant;
/*      */ import com.hitrust.b2ctoolkit.util.HiServer;
/*      */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*      */ import java.io.PrintStream;
/*      */ import java.util.Properties;
/*      */ import org.apache.log4j.Logger;
/*      */ import org.apache.log4j.PropertyConfigurator;
/*      */ 
/*      */ public class B2CPay
/*      */ {
/*   31 */   public final String AUTH = "1";
/*   32 */   public final String CAPTURE = "3";
/*   33 */   public final String RE_CAPT = "4";
/*   34 */   public final String REFUND = "5";
/*   35 */   public final String RE_REFU = "6";
/*   36 */   public final String QUERY = "7";
/*   37 */   public final String RE_AUTH = "8";
/*   38 */   public final String AUTHSSL = "1";
/*   39 */   public final String APSE = "9";
/*   40 */   public final String VIRTUAL = "10";
/*   41 */   public final String POST = "11";
/*   42 */   public final String EMVSIGN = "12";
/*   43 */   public final String CARD_PAY = "13";
/*   44 */   public final String CARD_SALE = "14";
/*   45 */   public final String CARD_AUTH = "15";
/*   46 */   public final String CARD_PRE_AUTH = "16";
/*   47 */   public final String CARD_AUTH_REV = "17";
/*   48 */   public final String CARD_REFUND = "18";
/*   49 */   public final String MERA_ENCODE = "19";
/*   50 */   public final String MERA_AUTH = "20";
/*   51 */   public final String AUTHSSL_TRXTOKEN = "22";
/*   52 */   public final String Item_CREATE = "23";
/*   53 */   public final String Item_MODIFY = "24";
/*   54 */   public final String Item_QUERY = "25";
/*   55 */   public final String REFUND_Query = "26";
/*   56 */   public final String Item_DELETE = "27";
/*   57 */   public final String AUTHSSL_APPLEPAY = "28";
/*      */   public static final String REQ_EASY_PAY_AUTH = "29";
/*      */   public static final String REQ_EASY_PAY_QUERY = "30";
/*      */   public static final String REQ_EASY_PAY_UPDATE_STATUS = "31";
/*   61 */   public final String SIP_QUERY = "32";
/*   62 */   public final String SIP_CANCEL = "33";
/*   63 */   public final String TENPAY_AUTH = "1";
/*      */ 
/*   65 */   private String type = "";
/*   66 */   private String orderNo = "";
/*   67 */   private String storeId = "";
/*   68 */   private String orderDesc = "";
/*   69 */   private String currency = "";
/*   70 */   private String amount = "";
/*   71 */   private String returnURL = "";
/*   72 */   private String depositFlag = "";
/*   73 */   private String queryFlag = "";
/*   74 */   private String extendField = "17";
/*      */ 
/*   76 */   private String updateURL = "";
/*   77 */   private String pan = "";
/*   78 */   private String expiry = "";
/*   79 */   private String merUpdateURL = "";
/*   80 */   private String ticketNo = "";
/*   81 */   private String e01 = "";
/*   82 */   private String e02 = "";
/*   83 */   private String e03 = "";
/*   84 */   private String e04 = "";
/*   85 */   private String e05 = "";
/*      */ 
/*   87 */   private String retCode = "";
/*   88 */   private String secCode = "";
/*   89 */   private String authCode = "";
/*   90 */   private String authRRN = "";
/*   91 */   private String orderStatus = "";
/*   92 */   private String creditStatus = "";
/*   93 */   private String acquirer = "";
/*   94 */   private String cardType = "";
/*   95 */   private String approveAmount = "";
/*   96 */   private String captureAmount = "";
/*   97 */   private String captureNum = "";
/*   98 */   private String refundAmount = "";
/*   99 */   private String refundNum = "";
/*  100 */   private String orderDate = "";
/*  101 */   private String payBatchNum = "";
/*  102 */   private String captureCode = "";
/*  103 */   private String captureDate = "";
/*  104 */   private String paymentNum = "";
/*      */ 
/*  106 */   private String refundBatch = "";
/*  107 */   private String refundCode = "";
/*  108 */   private String refundRRN = "";
/*  109 */   private String refundDate = "";
/*  110 */   private String token = "";
/*  111 */   private String eci = "";
/*  112 */   private String e06 = "";
/*  113 */   private String e07 = "";
/*  114 */   private String e08 = "";
/*  115 */   private String e09 = "";
/*  116 */   private String e10 = "";
/*      */ 
/*  118 */   private String e11 = "";
/*  119 */   private String e12 = "";
/*  120 */   private String e13 = "";
/*  121 */   private String e14 = "";
/*      */ 
/*  123 */   private String authhostdate = "";
/*  124 */   private String authhosttime = "";
/*  125 */   private String redemordernum = "";
/*  126 */   private String redem_discount_point = "";
/*  127 */   private String redem_discount_amount = "";
/*  128 */   private String redem_purchase_amount = "";
/*  129 */   private String redem_balance_point = "";
/*  130 */   private String cavv = "";
/*      */ 
/*  132 */   private String sip_data = "";
/*      */ 
/*  134 */   private String name = "";
/*  135 */   private String email = "";
/*  136 */   private String e17 = "";
/*  137 */   private String e18 = "";
/*  138 */   private String e19 = "";
/*  139 */   private String e20 = "";
/*  140 */   private String e21 = "";
/*  141 */   private String e25 = "";
/*  142 */   private String e26 = "";
/*  143 */   private String e27 = "";
/*      */ 
/*  145 */   private String e22 = "";
/*  146 */   private String e23 = "";
/*  147 */   private String e24 = "";
/*      */ 
/*  149 */   private String e28 = "";
/*  150 */   private String e29 = "";
/*      */ 
/*  152 */   private String HTML = "";
/*      */   private String prodNo;
/*  156 */   private String prodName = "";
/*  157 */   private String ship_fee_mode = "";
/*  158 */   private String weight = "";
/*  159 */   private String length = "";
/*  160 */   private String width = "";
/*  161 */   private String height = "";
/*      */   private String[] itemNo;
/*      */   private String[] prodQty;
/*      */   private String Qty;
/*      */   private String refund_virtual_account;
/*  170 */   private String trxToken = "";
/*      */ 
/*  172 */   private String e35 = "";
/*  173 */   private String e36 = "";
/*  174 */   private String e37 = "";
/*  175 */   private String e38 = "";
/*  176 */   private String e39 = "";
/*  177 */   private String e40 = "";
/*  178 */   private String e41 = "";
/*  179 */   private String e42 = "";
/*      */ 
/*  182 */   private String e52 = "";
/*  183 */   private String e53 = "";
/*  184 */   private String e54 = "";
/*      */ 
/*  188 */   private String e55 = "";
/*      */ 
/*  192 */   private String e56 = "";
/*  193 */   private String e57 = "";
/*  194 */   private String e58 = "";
/*      */ 
/*  197 */   private String e59 = "";
/*  198 */   private String e60 = "";
/*  199 */   private String e61 = "";
/*      */ 
/*  201 */   private String requestMessage = "";
/*  202 */   private String responseMessage = "";
/*      */   protected HiMerchant hiMerchant;
/*      */   protected Logger log;
/*      */ 
/*      */   public void init()
/*      */   {
/*      */   }
/*      */ 
/*      */   public String getE35()
/*      */   {
/*  209 */     return this.e35;
/*      */   }
/*      */ 
/*      */   public void setE35(String e35) {
/*  213 */     this.e35 = e35;
/*      */   }
/*      */ 
/*      */   public String getE36()
/*      */   {
/*  218 */     return this.e36;
/*      */   }
/*      */ 
/*      */   public void setE36(String e36) {
/*  222 */     this.e36 = e36;
/*      */   }
/*      */ 
/*      */   public String getE37() {
/*  226 */     return this.e37;
/*      */   }
/*      */ 
/*      */   public void setE37(String e37) {
/*  230 */     this.e37 = e37;
/*      */   }
/*      */ 
/*      */   public String getE38() {
/*  234 */     return this.e38;
/*      */   }
/*      */ 
/*      */   public void setE38(String e38) {
/*  238 */     this.e38 = e38;
/*      */   }
/*      */ 
/*      */   public String getE39() {
/*  242 */     return this.e39;
/*      */   }
/*      */ 
/*      */   public void setE39(String e39) {
/*  246 */     this.e39 = e39;
/*      */   }
/*      */ 
/*      */   public String getE40() {
/*  250 */     return this.e40;
/*      */   }
/*      */ 
/*      */   public void setE40(String e40) {
/*  254 */     this.e40 = e40;
/*      */   }
/*      */ 
/*      */   public String getE41() {
/*  258 */     return this.e41;
/*      */   }
/*      */ 
/*      */   public void setE41(String e41) {
/*  262 */     this.e41 = e41;
/*      */   }
/*      */ 
/*      */   public String getE42() {
/*  266 */     return this.e42;
/*      */   }
/*      */ 
/*      */   public void setE42(String e42) {
/*  270 */     this.e42 = e42;
/*      */   }
/*      */ 
/*      */   public String getE52()
/*      */   {
/*  276 */     return this.e52;
/*      */   }
/*      */ 
/*      */   public void setE52(String e52) {
/*  280 */     this.e52 = e52;
/*      */   }
/*      */ 
/*      */   public String getE53() {
/*  284 */     return this.e53;
/*      */   }
/*      */ 
/*      */   public void setE53(String e53) {
/*  288 */     this.e53 = e53;
/*      */   }
/*      */ 
/*      */   public String getE54() {
/*  292 */     return this.e54;
/*      */   }
/*      */ 
/*      */   public void setE54(String e54) {
/*  296 */     this.e54 = e54;
/*      */   }
/*      */ 
/*      */   public String getE55()
/*      */   {
/*  301 */     return this.e55;
/*      */   }
/*      */ 
/*      */   public void setE55(String e55) {
/*  305 */     this.e55 = e55;
/*      */   }
/*      */ 
/*      */   public String getE56()
/*      */   {
/*  310 */     return this.e56;
/*      */   }
/*      */ 
/*      */   public void setE56(String e56) {
/*  314 */     this.e56 = e56;
/*      */   }
/*      */ 
/*      */   public String getE57() {
/*  318 */     return this.e57;
/*      */   }
/*      */ 
/*      */   public void setE57(String e57) {
/*  322 */     this.e57 = e57;
/*      */   }
/*      */ 
/*      */   public String getE58() {
/*  326 */     return this.e58;
/*      */   }
/*      */ 
/*      */   public void setE58(String e58) {
/*  330 */     this.e58 = e58;
/*      */   }
/*      */ 
/*      */   public String getE59()
/*      */   {
/*  337 */     return this.e59;
/*      */   }
/*      */ 
/*      */   public void setE59(String e59) {
/*  341 */     this.e59 = e59;
/*      */   }
/*      */ 
/*      */   public String getE60()
/*      */   {
/*  347 */     return this.e60;
/*      */   }
/*      */ 
/*      */   public void setE60(String e60) {
/*  351 */     this.e60 = e60;
/*      */   }
/*      */ 
/*      */   public String getE61() {
/*  355 */     return this.e61;
/*      */   }
/*      */ 
/*      */   public void setE61(String e61) {
/*  359 */     this.e61 = e61;
/*      */   }
/*      */ 
/*      */   public String getProdNo()
/*      */   {
/*  365 */     return this.prodNo;
/*      */   }
/*      */ 
/*      */   public void setProdNo(String prodNo) {
/*  369 */     this.prodNo = prodNo;
/*      */   }
/*      */ 
/*      */   public String getProdName() {
/*  373 */     return this.prodName;
/*      */   }
/*      */ 
/*      */   public void setProdName(String prodName) {
/*  377 */     this.prodName = prodName;
/*      */   }
/*      */ 
/*      */   public void setType(String type) {
/*  381 */     this.type = type;
/*      */   }
/*      */   public void setOrderNo(String orderNo) {
/*  384 */     this.orderNo = orderNo;
/*      */   }
/*      */   public void setStoreId(String storeId) {
/*  387 */     this.storeId = storeId;
/*      */   }
/*      */   public void setOrderDesc(String orderDesc) {
/*  390 */     this.orderDesc = orderDesc;
/*      */   }
/*      */   public void setCurrency(String currency) {
/*  393 */     this.currency = currency;
/*      */   }
/*      */   public void setAmount(String amount) {
/*  396 */     this.amount = amount;
/*      */   }
/*      */   public void setReturnURL(String returnURL) {
/*  399 */     this.returnURL = returnURL;
/*      */   }
/*      */   public void setDepositFlag(String depositFlag) {
/*  402 */     this.depositFlag = depositFlag;
/*      */   }
/*      */   public void setQueryFlag(String queryFlag) {
/*  405 */     this.queryFlag = queryFlag;
/*      */   }
/*      */   public void setExtendField(String extendField) {
/*  408 */     this.extendField = extendField;
/*      */   }
/*      */   public void setUpdateURL(String updateURL) {
/*  411 */     this.updateURL = updateURL;
/*      */   }
/*      */   public void setPan(String pan) {
/*  414 */     this.pan = pan;
/*      */   }
/*      */   public void setExpiry(String expiry) {
/*  417 */     this.expiry = expiry;
/*      */   }
/*      */   public void setMerUpdateURL(String merUpdateURL) {
/*  420 */     this.merUpdateURL = merUpdateURL;
/*      */   }
/*      */   public void setTicketNo(String ticketNo) {
/*  423 */     this.ticketNo = ticketNo;
/*      */   }
/*      */   public void setE01(String e01) {
/*  426 */     this.e01 = e01;
/*      */   }
/*      */   public void setE02(String e02) {
/*  429 */     this.e02 = e02;
/*      */   }
/*      */   public void setE03(String e03) {
/*  432 */     this.e03 = e03;
/*      */   }
/*      */   public void setE04(String e04) {
/*  435 */     this.e04 = e04;
/*      */   }
/*      */   public void setE05(String e05) {
/*  438 */     this.e05 = e05;
/*      */   }
/*      */ 
/*      */   public String getType() {
/*  442 */     return this.type;
/*      */   }
/*      */   public String getOrderNo() {
/*  445 */     return this.orderNo;
/*      */   }
/*      */   public String getStoreId() {
/*  448 */     return this.storeId;
/*      */   }
/*      */   public String getOrderDesc() {
/*  451 */     return this.orderDesc;
/*      */   }
/*      */   public String getCurrency() {
/*  454 */     return this.currency;
/*      */   }
/*      */   public String getAmount() {
/*  457 */     return this.amount;
/*      */   }
/*      */   public String getReturnURL() {
/*  460 */     return this.returnURL;
/*      */   }
/*      */   public String getDepositFlag() {
/*  463 */     return this.depositFlag;
/*      */   }
/*      */   public String getQueryFlag() {
/*  466 */     return this.queryFlag;
/*      */   }
/*      */   public String getExtendField() {
/*  469 */     return this.extendField;
/*      */   }
/*      */   public String getUpdateURL() {
/*  472 */     return this.updateURL;
/*      */   }
/*      */   public String getPan() {
/*  475 */     return this.pan;
/*      */   }
/*      */   public String getExpiry() {
/*  478 */     return this.expiry;
/*      */   }
/*      */   public String getMerUpdateURL() {
/*  481 */     return this.merUpdateURL;
/*      */   }
/*      */   public String getTicketNo() {
/*  484 */     return this.ticketNo;
/*      */   }
/*      */   public String getE01() {
/*  487 */     return this.e01;
/*      */   }
/*      */   public String getE02() {
/*  490 */     return this.e02;
/*      */   }
/*      */   public String getE03() {
/*  493 */     return this.e03;
/*      */   }
/*      */   public String getE04() {
/*  496 */     return this.e04;
/*      */   }
/*      */   public String getE05() {
/*  499 */     return this.e05;
/*      */   }
/*      */ 
/*      */   public void setRetCode(String retCode) {
/*  503 */     this.retCode = retCode;
/*      */   }
/*      */   public void setSecCode(String secCode) {
/*  506 */     this.secCode = secCode;
/*      */   }
/*      */   public void setAuthCode(String authCode) {
/*  509 */     this.authCode = authCode;
/*      */   }
/*      */   public void setAuthRRN(String authRRN) {
/*  512 */     this.authRRN = authRRN;
/*      */   }
/*      */   public void setOrderStatus(String orderStatus) {
/*  515 */     this.orderStatus = orderStatus;
/*      */   }
/*      */   public void setCreditStatus(String creditStatus) {
/*  518 */     this.creditStatus = creditStatus;
/*      */   }
/*      */   public void setAcquirer(String acquirer) {
/*  521 */     this.acquirer = acquirer;
/*      */   }
/*      */   public void setCardType(String cardType) {
/*  524 */     this.cardType = cardType;
/*      */   }
/*      */   public void setApproveAmount(String approveAmount) {
/*  527 */     this.approveAmount = approveAmount;
/*      */   }
/*      */   public void setCaptureAmount(String captureAmount) {
/*  530 */     this.captureAmount = captureAmount;
/*      */   }
/*      */   public void setCaptureNum(String captureNum) {
/*  533 */     this.captureNum = captureNum;
/*      */   }
/*      */   public void setRefundAmount(String refundAmount) {
/*  536 */     this.refundAmount = refundAmount;
/*      */   }
/*      */   public void setRefundNum(String refundNum) {
/*  539 */     this.refundNum = refundNum;
/*      */   }
/*      */   public void setOrderDate(String orderDate) {
/*  542 */     this.orderDate = orderDate;
/*      */   }
/*      */   public void setPayBatchNum(String payBatchNum) {
/*  545 */     this.payBatchNum = payBatchNum;
/*      */   }
/*      */   public void setCaptureCode(String captureCode) {
/*  548 */     this.captureCode = captureCode;
/*      */   }
/*      */   public void setCaptureDate(String captureDate) {
/*  551 */     this.captureDate = captureDate;
/*      */   }
/*      */   public void setPaymentNum(String paymentNum) {
/*  554 */     this.paymentNum = paymentNum;
/*      */   }
/*      */ 
/*      */   public void setRefundBatch(String refundBatch)
/*      */   {
/*  562 */     this.refundBatch = refundBatch;
/*      */   }
/*      */   public void setRefundCode(String refundCode) {
/*  565 */     this.refundCode = refundCode;
/*      */   }
/*      */   public void setRefundRRN(String refundRRN) {
/*  568 */     this.refundRRN = refundRRN;
/*      */   }
/*      */   public void setRefundDate(String refundDate) {
/*  571 */     this.refundDate = refundDate;
/*      */   }
/*      */   public void setToken(String token) {
/*  574 */     this.token = token;
/*      */   }
/*      */   public void setEci(String eci) {
/*  577 */     this.eci = eci;
/*      */   }
/*      */   public void setE06(String e06) {
/*  580 */     this.e06 = e06;
/*      */   }
/*      */   public void setE07(String e07) {
/*  583 */     this.e07 = e07;
/*      */   }
/*      */   public void setE08(String e08) {
/*  586 */     this.e08 = e08;
/*      */   }
/*      */   public void setE09(String e09) {
/*  589 */     this.e09 = e09;
/*      */   }
/*      */   public void setE10(String e10) {
/*  592 */     this.e10 = e10;
/*      */   }
/*      */   public void setE11(String e11) {
/*  595 */     this.e11 = e11;
/*      */   }
/*      */   public void setE12(String e12) {
/*  598 */     this.e12 = e12;
/*      */   }
/*      */   public void setE13(String e13) {
/*  601 */     this.e13 = e13;
/*      */   }
/*      */   public void setE14(String e14) {
/*  604 */     this.e14 = e14;
/*      */   }
/*      */ 
/*      */   public String getRetCode() {
/*  608 */     return this.retCode;
/*      */   }
/*      */   public String getSecCode() {
/*  611 */     return this.secCode;
/*      */   }
/*      */   public String getAuthCode() {
/*  614 */     return this.authCode;
/*      */   }
/*      */   public String getAuthRRN() {
/*  617 */     return this.authRRN;
/*      */   }
/*      */   public String getOrderStatus() {
/*  620 */     return this.orderStatus;
/*      */   }
/*      */   public String getCreditStatus() {
/*  623 */     return this.creditStatus;
/*      */   }
/*      */   public String getAcquirer() {
/*  626 */     return this.acquirer;
/*      */   }
/*      */   public String getCardType() {
/*  629 */     return this.cardType;
/*      */   }
/*      */   public String getApproveAmount() {
/*  632 */     return this.approveAmount;
/*      */   }
/*      */   public String getCaptureAmount() {
/*  635 */     return this.captureAmount;
/*      */   }
/*      */   public String getCaptureNum() {
/*  638 */     return this.captureNum;
/*      */   }
/*      */   public String getRefundAmount() {
/*  641 */     return this.refundAmount;
/*      */   }
/*      */   public String getRefundNum() {
/*  644 */     return this.refundNum;
/*      */   }
/*      */   public String getOrderDate() {
/*  647 */     return this.orderDate;
/*      */   }
/*      */   public String getPayBatchNum() {
/*  650 */     return this.payBatchNum;
/*      */   }
/*      */   public String getCaptureCode() {
/*  653 */     return this.captureCode;
/*      */   }
/*      */   public String getCaptureDate() {
/*  656 */     return this.captureDate;
/*      */   }
/*      */   public String getPaymentNum() {
/*  659 */     return this.paymentNum;
/*      */   }
/*      */ 
/*      */   public String getRefundBatch()
/*      */   {
/*  667 */     return this.refundBatch;
/*      */   }
/*      */   public String getRefundCode() {
/*  670 */     return this.refundCode;
/*      */   }
/*      */   public String getRefundRRN() {
/*  673 */     return this.refundRRN;
/*      */   }
/*      */   public String getRefundDate() {
/*  676 */     return this.refundDate;
/*      */   }
/*      */   public String getToken() {
/*  679 */     return this.token;
/*      */   }
/*      */   public String getEci() {
/*  682 */     return this.eci;
/*      */   }
/*      */   public String getE06() {
/*  685 */     return this.e06;
/*      */   }
/*      */   public String getE07() {
/*  688 */     return this.e07;
/*      */   }
/*      */   public String getE08() {
/*  691 */     return this.e08;
/*      */   }
/*      */   public String getE09() {
/*  694 */     return this.e09;
/*      */   }
/*      */   public String getE10() {
/*  697 */     return this.e10;
/*      */   }
/*      */   public String getE11() {
/*  700 */     return this.e11;
/*      */   }
/*      */   public String getE12() {
/*  703 */     return this.e12;
/*      */   }
/*      */   public String getE13() {
/*  706 */     return this.e13;
/*      */   }
/*      */   public String getE14() {
/*  709 */     return this.e14;
/*      */   }
/*      */ 
/*      */   public void setAuthhostdate(String authhostdate)
/*      */   {
/*  714 */     this.authhostdate = authhostdate;
/*      */   }
/*      */ 
/*      */   public void setAuthhosttime(String authhosttime) {
/*  718 */     this.authhosttime = authhosttime;
/*      */   }
/*      */ 
/*      */   public void setRedemordernum(String redemordernum) {
/*  722 */     this.redemordernum = redemordernum;
/*      */   }
/*      */ 
/*      */   public void setRedem_discount_point(String redem_discount_point) {
/*  726 */     this.redem_discount_point = redem_discount_point;
/*      */   }
/*      */ 
/*      */   public void setRedem_discount_amount(String redem_discount_amount) {
/*  730 */     this.redem_discount_amount = redem_discount_amount;
/*      */   }
/*      */ 
/*      */   public void setRedem_purchase_amount(String redem_purchase_amount) {
/*  734 */     this.redem_purchase_amount = redem_purchase_amount;
/*      */   }
/*      */ 
/*      */   public void setRedem_balance_point(String redem_balance_point) {
/*  738 */     this.redem_balance_point = redem_balance_point;
/*      */   }
/*      */ 
/*      */   public void setCavv(String cavv) {
/*  742 */     this.cavv = cavv;
/*      */   }
/*      */ 
/*      */   public void setSIP_Data(String sip_data)
/*      */   {
/*  747 */     this.sip_data = sip_data;
/*      */   }
/*      */ 
/*      */   public String getSIP_Data() {
/*  751 */     return this.sip_data;
/*      */   }
/*      */ 
/*      */   public String getAuthhostdate()
/*      */   {
/*  756 */     return this.authhostdate;
/*      */   }
/*      */ 
/*      */   public String getAuthhosttime() {
/*  760 */     return this.authhosttime;
/*      */   }
/*      */ 
/*      */   public String getRedemordernum() {
/*  764 */     return this.redemordernum;
/*      */   }
/*      */ 
/*      */   public String getRedem_discount_point() {
/*  768 */     return this.redem_discount_point;
/*      */   }
/*      */ 
/*      */   public String getRedem_discount_amount() {
/*  772 */     return this.redem_discount_amount;
/*      */   }
/*      */ 
/*      */   public String getRedem_purchase_amount() {
/*  776 */     return this.redem_purchase_amount;
/*      */   }
/*      */ 
/*      */   public String getRedem_balance_point() {
/*  780 */     return this.redem_balance_point;
/*      */   }
/*      */ 
/*      */   public String getCavv() {
/*  784 */     return this.cavv;
/*      */   }
/*      */ 
/*      */   public void setHTML(String HTML)
/*      */   {
/*  789 */     this.HTML = HTML;
/*      */   }
/*      */   public String getHTML() {
/*  792 */     return this.HTML;
/*      */   }
/*      */ 
/*      */   public void setRequestMessage(String requestMessage) {
/*  796 */     this.requestMessage = requestMessage;
/*      */   }
/*      */   public String getRequestMessage() {
/*  799 */     return this.requestMessage;
/*      */   }
/*      */ 
/*      */   public void setResponseMessage(String responseMessage) {
/*  803 */     this.responseMessage = responseMessage;
/*      */   }
/*      */   public String getResponseMessage() {
/*  806 */     return this.responseMessage;
/*      */   }
/*      */ 
/*      */   protected boolean isEmpty(String s)
/*      */   {
/*  840 */     return (s == null) || (s.length() == 0);
/*      */   }
/*      */ 
/*      */   protected void connectTo(String app) throws ToolkitException, Exception
/*      */   {
/*  845 */     BCEncryptData encryptData = new BCEncryptData();
/*  846 */     String cipher = encryptData.getCIPHER(getRequestMessage(), 128);
/*  847 */     String key = encryptData.getKEY(HiServer.getRSAName());
/*  848 */     String mac = encryptData.getMAC(getRequestMessage(), this.hiMerchant.getRSAName());
/*      */ 
/*  850 */     System.out.println("app = " + app);
/*  851 */     System.out.println("key = " + key);
/*  852 */     System.out.println("mac = " + mac);
/*  853 */     System.out.println("cipher = " + cipher);
/*      */ 
/*  855 */     if (isEmpty(cipher)) {
/*  856 */       this.log.error("<Toolkit MSG> Input Parameter [CIPHER] is null or empty.");
/*  857 */       throw new ToolkitException("-44");
/*      */     }
/*  859 */     if (isEmpty(key)) {
/*  860 */       this.log.error("<Toolkit MSG> Input Parameter [KEY] is null or empty.");
/*  861 */       throw new ToolkitException("-42");
/*      */     }
/*  863 */     if (isEmpty(mac)) {
/*  864 */       this.log.error("<Toolkit MSG> Input Parameter [MAC] is null or empty.");
/*  865 */       throw new ToolkitException("-43");
/*      */     }
/*  867 */     System.out.println("isEmpty ok ");
/*      */     try
/*      */     {
/*  870 */       System.out.println("HiServer  " + HiServer.getIP() + " getPort  " + HiServer.getPort());
/*  871 */       resMessage = HttpComm.connect(HiServer.getIP(), HiServer.getPort(), app, key, cipher, mac);
/*      */     }
/*      */     catch (ToolkitException e)
/*      */     {
/*      */       String resMessage;
/*  873 */       throw new ToolkitException(e.getMessage());
/*      */     }
/*      */     String resMessage;
/*  876 */     if (isEmpty(resMessage)) {
/*  877 */       this.log.error("<Toolkit MSG> Couldn't receive data.");
/*  878 */       throw new ToolkitException("-6");
/*      */     }
/*  880 */     System.out.println("resMessage ok ");
/*      */     String key_res;
/*      */     String mac_res;
/*  883 */     if (((cipher_res = parsingKeyword(resMessage, "CIPHER")) == null) || ((key_res = parsingKeyword(resMessage, "KEY")) == null) || ((mac_res = parsingKeyword(resMessage, "MAC")) == null))
/*      */     {
/*  886 */       this.log.error("<Toolkit MSG> Receive Broken message. :" + resMessage);
/*  887 */       throw new ToolkitException("-7");
/*      */     }
/*      */     String mac_res;
/*      */     String key_res;
/*  889 */     System.out.println("0 ok ");
/*      */ 
/*  891 */     String cipher_res = cipher_res.substring(0, cipher_res.length() - 1);
/*  892 */     System.out.println("0 ok ");
/*      */     try
/*      */     {
/*  895 */       setResponseMessage(BCDecryptData.decrypt(cipher_res, key_res, mac_res, this.hiMerchant.getRSAName(), HiServer.getRSAName()));
/*      */     } catch (ToolkitException e) {
/*  897 */       throw new ToolkitException(e.getMessage());
/*      */     }
/*  899 */     System.out.println("2 ok ");
/*  900 */     this.log.info("Decrypt Message [ ok ].");
/*      */   }
/*      */ 
/*      */   protected String parsingKeyword(String source, String key) {
/*  904 */     if (source.indexOf(key + "=") == -1) return null;
/*  905 */     return parsingKeyword(source, key, "&");
/*      */   }
/*      */ 
/*      */   private String parsingKeyword(String source, String keyValue, String keyWord) {
/*  909 */     keyValue = keyValue + "=";
/*      */ 
/*  912 */     if (source.indexOf(keyWord, source.indexOf(keyValue)) == -1) {
/*  913 */       return source.substring(source.indexOf(keyValue) + keyValue.length());
/*      */     }
/*  915 */     return source.substring(source.indexOf(keyValue) + keyValue.length(), source.indexOf(keyWord, source.indexOf(keyValue)));
/*      */   }
/*      */ 
/*      */   protected void getHiMerchant() throws ToolkitException
/*      */   {
/*  920 */     this.hiMerchant = new HiMerchant(this.storeId);
/*      */   }
/*      */ 
/*      */   protected void getLogger()
/*      */     throws ToolkitException
/*      */   {
/*      */     try
/*      */     {
/*  932 */       Properties pro = new Properties();
/*  933 */       pro.load(B2CPay.class.getClassLoader().getResourceAsStream("log4j.properties"));
/*  934 */       PropertyConfigurator.configure(pro);
/*  935 */       this.log = Logger.getLogger(getClass());
/*      */     } catch (IllegalArgumentException e) {
/*  937 */       throw new ToolkitException("-47");
/*      */     } catch (NullPointerException e) {
/*  939 */       throw new ToolkitException("-47");
/*      */     } catch (Exception e) {
/*  941 */       throw new ToolkitException(e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public String getEmail()
/*      */   {
/*  947 */     return this.email;
/*      */   }
/*      */ 
/*      */   public void setEmail(String email) {
/*  951 */     this.email = email;
/*      */   }
/*      */ 
/*      */   public String getName() {
/*  955 */     return this.name;
/*      */   }
/*      */ 
/*      */   public void setName(String name) {
/*  959 */     this.name = name;
/*      */   }
/*      */ 
/*      */   public String getE17() {
/*  963 */     return this.e17;
/*      */   }
/*      */ 
/*      */   public void setE17(String e17) {
/*  967 */     this.e17 = e17;
/*      */   }
/*      */ 
/*      */   public String getE18() {
/*  971 */     return this.e18;
/*      */   }
/*      */ 
/*      */   public void setE18(String e18) {
/*  975 */     this.e18 = e18;
/*      */   }
/*      */ 
/*      */   public String getE19() {
/*  979 */     return this.e19;
/*      */   }
/*      */ 
/*      */   public void setE19(String e19) {
/*  983 */     this.e19 = e19;
/*      */   }
/*      */ 
/*      */   public String getE20() {
/*  987 */     return this.e20;
/*      */   }
/*      */ 
/*      */   public void setE20(String e20) {
/*  991 */     this.e20 = e20;
/*      */   }
/*      */ 
/*      */   public String getE21() {
/*  995 */     return this.e21;
/*      */   }
/*      */ 
/*      */   public void setE21(String e21) {
/*  999 */     this.e21 = e21;
/*      */   }
/*      */ 
/*      */   public String getE22() {
/* 1003 */     return this.e22;
/*      */   }
/*      */ 
/*      */   public void setE22(String e22) {
/* 1007 */     this.e22 = e22;
/*      */   }
/*      */ 
/*      */   public String getE23() {
/* 1011 */     return this.e23;
/*      */   }
/*      */ 
/*      */   public void setE23(String e23) {
/* 1015 */     this.e23 = e23;
/*      */   }
/*      */ 
/*      */   public String getE24() {
/* 1019 */     return this.e24;
/*      */   }
/*      */ 
/*      */   public void setE24(String e24) {
/* 1023 */     this.e24 = e24;
/*      */   }
/*      */ 
/*      */   public String getE25() {
/* 1027 */     return this.e25;
/*      */   }
/*      */ 
/*      */   public void setE25(String e25) {
/* 1031 */     this.e25 = e25;
/*      */   }
/*      */ 
/*      */   public String getE26() {
/* 1035 */     return this.e26;
/*      */   }
/*      */ 
/*      */   public void setE26(String e26) {
/* 1039 */     this.e26 = e26;
/*      */   }
/*      */ 
/*      */   public String getE27() {
/* 1043 */     return this.e27;
/*      */   }
/*      */ 
/*      */   public void setE27(String e27) {
/* 1047 */     this.e27 = e27;
/*      */   }
/*      */ 
/*      */   public String getE28() {
/* 1051 */     return this.e28;
/*      */   }
/*      */ 
/*      */   public void setE28(String e28) {
/* 1055 */     this.e28 = e28;
/*      */   }
/*      */ 
/*      */   public String getE29() {
/* 1059 */     return this.e29;
/*      */   }
/*      */ 
/*      */   public void setE29(String e29) {
/* 1063 */     this.e29 = e29;
/*      */   }
/*      */ 
/*      */   public String getSN()
/*      */   {
/* 1068 */     return getOrderNo();
/*      */   }
/*      */ 
/*      */   public void setSN(String sn) {
/* 1072 */     setOrderNo(sn);
/*      */   }
/*      */ 
/*      */   public String getShip_fee_mode() {
/* 1076 */     return this.ship_fee_mode;
/*      */   }
/*      */ 
/*      */   public void setShip_fee_mode(String ship_fee_mode) {
/* 1080 */     this.ship_fee_mode = ship_fee_mode;
/*      */   }
/*      */ 
/*      */   public String getWeight() {
/* 1084 */     return this.weight;
/*      */   }
/*      */ 
/*      */   public void setWeight(String weight) {
/* 1088 */     this.weight = weight;
/*      */   }
/*      */ 
/*      */   public String[] getProdQty() {
/* 1092 */     return this.prodQty;
/*      */   }
/*      */ 
/*      */   public void setProdQty(String[] prodQty) {
/* 1096 */     this.prodQty = prodQty;
/*      */   }
/*      */ 
/*      */   public String[] getItemNo() {
/* 1100 */     return this.itemNo;
/*      */   }
/*      */ 
/*      */   public void setItemNo(String[] itemNo) {
/* 1104 */     this.itemNo = itemNo;
/*      */   }
/*      */ 
/*      */   public String getQty() {
/* 1108 */     return this.Qty;
/*      */   }
/*      */ 
/*      */   public void setQty(String qty) {
/* 1112 */     this.Qty = qty;
/*      */   }
/*      */ 
/*      */   public String getRefund_virtual_account() {
/* 1116 */     return this.refund_virtual_account;
/*      */   }
/*      */ 
/*      */   public void setRefund_virtual_account(String refund_virtual_account) {
/* 1120 */     this.refund_virtual_account = refund_virtual_account;
/*      */   }
/*      */ 
/*      */   public String getTrxToken() {
/* 1124 */     return this.trxToken;
/*      */   }
/*      */ 
/*      */   public void setTrxToken(String trxToken) {
/* 1128 */     this.trxToken = trxToken;
/*      */   }
/*      */ 
/*      */   public String getLength() {
/* 1132 */     return this.length;
/*      */   }
/*      */ 
/*      */   public void setLength(String length) {
/* 1136 */     this.length = length;
/*      */   }
/*      */ 
/*      */   public String getWidth() {
/* 1140 */     return this.width;
/*      */   }
/*      */ 
/*      */   public void setWidth(String width) {
/* 1144 */     this.width = width;
/*      */   }
/*      */ 
/*      */   public String getHeight() {
/* 1148 */     return this.height;
/*      */   }
/*      */ 
/*      */   public void setHeight(String height) {
/* 1152 */     this.height = height;
/*      */   }
/*      */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.B2CPay
 * JD-Core Version:    0.6.0
 */