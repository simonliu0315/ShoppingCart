/*    */ package com.hitrust.b2ctoolkit.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.InputStream;
/*    */ import java.util.Properties;
/*    */ 
/*    */ public class HiMerchant
/*    */ {
/*    */   private Properties pro;
/*    */   private String rsaName;
/*    */   private String deposit;
/*    */   private String queryFlag;
/*    */   private String currency;
/*    */   private String orderDesc;
/*    */   private String returnURL;
/*    */   private String updateURL;
/*    */ 
/*    */   public HiMerchant(String storeId)
/*    */     throws ToolkitException
/*    */   {
/* 29 */     String path = storeId + ".conf";
/* 30 */     this.pro = new Properties();
/*    */     try
/*    */     {
/* 33 */       InputStream is = HiMerchant.class.getClassLoader().getResourceAsStream(path);
/* 34 */       this.pro.load(is);
/*    */ 
/* 37 */       this.rsaName = this.pro.getProperty("RSAName");
/* 38 */       this.deposit = this.pro.getProperty("Deposit");
/* 39 */       this.queryFlag = this.pro.getProperty("QueryFlag");
/* 40 */       this.currency = this.pro.getProperty("Currency");
/* 41 */       this.orderDesc = this.pro.getProperty("OrderDesc");
/* 42 */       this.returnURL = this.pro.getProperty("ReturnURL");
/* 43 */       this.updateURL = this.pro.getProperty("UpdateURL");
/*    */ 
/* 45 */       if (is != null) {
/* 46 */         is.close();
/*    */       }
/*    */ 
/* 49 */       if ((this.rsaName == null) || (this.currency == null))
/* 50 */         throw new ToolkitException("-28");
/*    */     }
/*    */     catch (Exception e) {
/* 53 */       throw new ToolkitException("-25");
/*    */     }
/*    */   }
/*    */ 
/*    */   public String getRSAName() throws ToolkitException {
/* 58 */     File RSAFile = new File(this.rsaName);
/* 59 */     if (!RSAFile.exists()) {
/* 60 */       throw new ToolkitException("-26");
/*    */     }
/* 62 */     return this.rsaName;
/*    */   }
/*    */ 
/*    */   public String getDeposit() throws ToolkitException {
/* 66 */     return this.deposit;
/*    */   }
/*    */ 
/*    */   public String getQueryFlag() throws ToolkitException {
/* 70 */     return this.queryFlag;
/*    */   }
/*    */ 
/*    */   public String getCurrency() throws ToolkitException {
/* 74 */     return this.currency;
/*    */   }
/*    */ 
/*    */   public String getOrderDesc() throws ToolkitException {
/* 78 */     return this.orderDesc;
/*    */   }
/*    */ 
/*    */   public String getReturnURL() throws ToolkitException {
/* 82 */     return this.returnURL;
/*    */   }
/*    */ 
/*    */   public String getUpdateURL() throws ToolkitException {
/* 86 */     return this.updateURL;
/*    */   }
/*    */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.util.HiMerchant
 * JD-Core Version:    0.6.0
 */