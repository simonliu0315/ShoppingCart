/*     */ package com.hitrust.b2ctoolkit.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class HiServer
/*     */ {
/*  22 */   private static boolean file_Err_Flag = false;
/*  23 */   private static boolean element_Err_Flag = false;
/*     */   private static String IP;
/*     */   private static String Port;
/*     */   private static String RSAName;
/*     */   private static String AuthUrl;
/*     */   private static String OtherUrl;
/*     */   private static String UPOPAuthUrl;
/*     */   private static String UPOPOtherUrl;
/*     */   private static String ConnectionTimeout;
/*     */   private static String readTimeout;
/*     */   private static String TenpayAuthUrl;
/*     */   private static String TenpayOtherUrl;
/*     */   private static String TenpayItemUrl;
/*     */   private static Properties pro;
/*     */ 
/*     */   private static void checkData()
/*     */     throws ToolkitException
/*     */   {
/*  26 */     if (file_Err_Flag)
/*  27 */       throw new ToolkitException("-21");
/*  28 */     if (element_Err_Flag)
/*  29 */       throw new ToolkitException("-24");
/*     */   }
/*     */ 
/*     */   public static String getIP()
/*     */     throws ToolkitException
/*     */   {
/*  37 */     checkData();
/*  38 */     return IP;
/*     */   }
/*     */ 
/*     */   public static int getPort()
/*     */     throws ToolkitException
/*     */   {
/*  48 */     checkData();
/*     */     try
/*     */     {
/*  51 */       port = Integer.parseInt(Port);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       int port;
/*  53 */       throw new ToolkitException("-24");
/*     */     }
/*     */     int port;
/*  55 */     return port;
/*     */   }
/*     */ 
/*     */   public static String getRSAName()
/*     */     throws ToolkitException
/*     */   {
/*  62 */     checkData();
/*  63 */     File RSAFile = new File(RSAName);
/*  64 */     if (!RSAFile.exists()) {
/*  65 */       throw new ToolkitException("-22");
/*     */     }
/*  67 */     return RSAName;
/*     */   }
/*     */ 
/*     */   public static String getAuthUrl()
/*     */     throws ToolkitException
/*     */   {
/*  74 */     checkData();
/*  75 */     return AuthUrl;
/*     */   }
/*     */ 
/*     */   public static String getOtherUrl()
/*     */     throws ToolkitException
/*     */   {
/*  83 */     checkData();
/*  84 */     return OtherUrl;
/*     */   }
/*     */ 
/*     */   public static String getUPOPAuthUrl()
/*     */     throws ToolkitException
/*     */   {
/*  91 */     checkData();
/*  92 */     return UPOPAuthUrl;
/*     */   }
/*     */ 
/*     */   public static String getUPOPOtherUrl()
/*     */     throws ToolkitException
/*     */   {
/* 100 */     checkData();
/* 101 */     return UPOPOtherUrl;
/*     */   }
/*     */ 
/*     */   public static String getConnectionTimeout()
/*     */     throws ToolkitException
/*     */   {
/* 107 */     checkData();
/* 108 */     return ConnectionTimeout;
/*     */   }
/*     */ 
/*     */   public static String getReadTimeout() throws ToolkitException {
/* 112 */     checkData();
/* 113 */     return ConnectionTimeout;
/*     */   }
/*     */ 
/*     */   public static String getTenpayItemUrl()
/*     */     throws ToolkitException
/*     */   {
/* 121 */     checkData();
/* 122 */     return TenpayItemUrl;
/*     */   }
/*     */   public static String getTenpayAuthUrl() throws ToolkitException {
/* 125 */     checkData();
/* 126 */     return TenpayAuthUrl;
/*     */   }
/*     */   public static String getTenpayOtherUrl() throws ToolkitException {
/* 129 */     checkData();
/* 130 */     return TenpayOtherUrl;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/* 137 */       String path = "HiServer.conf";
/* 138 */       pro = new Properties();
/* 139 */       pro.load(HiServer.class.getClassLoader().getResourceAsStream(path));
/* 140 */       IP = pro.getProperty("IP");
/* 141 */       Port = pro.getProperty("Port");
/* 142 */       RSAName = pro.getProperty("RSAName");
/* 143 */       AuthUrl = pro.getProperty("AuthUrl");
/* 144 */       OtherUrl = pro.getProperty("OtherUrl");
/* 145 */       UPOPAuthUrl = pro.getProperty("UPOPAuthUrl");
/* 146 */       UPOPOtherUrl = pro.getProperty("UPOPOtherUrl");
/* 147 */       ConnectionTimeout = pro.getProperty("ConnectionTimeout");
/* 148 */       readTimeout = pro.getProperty("readTimeout");
/* 149 */       if ((IP == null) || (Port == null) || (RSAName == null) || (AuthUrl == null) || (OtherUrl == null) || (UPOPAuthUrl == null) || (UPOPOtherUrl == null))
/*     */       {
/* 151 */         element_Err_Flag = true;
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 163 */       file_Err_Flag = true;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.util.HiServer
 * JD-Core Version:    0.6.0
 */