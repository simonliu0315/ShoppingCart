/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.util.HiMerchant;
/*     */ import com.hitrust.b2ctoolkit.util.HiServer;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class B2CPayAuthTrxToken extends B2CPay
/*     */ {
/*     */   public void transaction()
/*     */   {
/*  34 */     boolean logflag = false;
/*     */     try {
/*  36 */       if (isEmpty(getStoreId())) {
/*  37 */         throw new ToolkitException("-32");
/*     */       }
/*  39 */       getHiMerchant();
/*  40 */       getLogger();
/*     */ 
/*  42 */       logflag = true;
/*  43 */       this.log.info("----- New Auth(TrxToken) Start  -----");
/*  44 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*  45 */       this.log.info("[C]StoreID      = " + getStoreId());
/*     */ 
/*  48 */       setType("1");
/*     */ 
/*  51 */       checkData();
/*  52 */       this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/*  55 */       organizeMessage();
/*  56 */       this.log.info("Organize Message [ ok ].");
/*     */ 
/*  59 */       this.log.info("Send Message......");
/*  60 */       connectTo(HiServer.getAuthUrl());
/*  61 */       this.log.info("Receive Response [ ok ].");
/*     */ 
/*  64 */       parserResult();
/*  65 */       this.log.info("parsing Message [ ok ].");
/*     */ 
/*  67 */       this.log.info("----- New Auth(TrxToken) End  -----\n");
/*     */     } catch (ToolkitException e) {
/*  69 */       setRetCode(e.getMessage());
/*  70 */       if (logflag) {
/*  71 */         this.log.info("Run Error! Code ==" + getRetCode());
/*  72 */         this.log.info("----- New Auth(TrxToken) End  -----\n");
/*     */       }
/*     */     } catch (Exception e) {
/*  75 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkData() throws ToolkitException, Exception
/*     */   {
/*  81 */     if (isEmpty(getType())) {
/*  82 */       this.log.error("<Toolkit MSG> Input Parameter [TrxType] is wrong.");
/*  83 */       throw new ToolkitException("-45");
/*     */     }
/*     */ 
/*  86 */     if (isEmpty(getOrderNo())) {
/*  87 */       this.log.error("<Toolkit MSG> Input Parameter [ORDERNO] is null or empty.");
/*  88 */       throw new ToolkitException("-31");
/*     */     }
/*  90 */     this.log.info("[P]OrderNo      = " + getOrderNo());
/*     */ 
/*  93 */     if (isEmpty(getOrderDesc())) {
/*  94 */       if (isEmpty(this.hiMerchant.getOrderDesc())) {
/*  95 */         this.log.error("<Toolkit MSG> Input Parameter [ORDERDESC] is null or empty.");
/*  96 */         throw new ToolkitException("-33");
/*     */       }
/*  98 */       setOrderDesc(this.hiMerchant.getOrderDesc());
/*  99 */       this.log.info("[C]OrderDesc    = " + getOrderDesc());
/*     */     }
/*     */     else {
/* 102 */       this.log.info("[P]OrderDesc    = " + getOrderDesc());
/*     */     }
/*     */ 
/* 105 */     if (isEmpty(getCurrency())) {
/* 106 */       if (isEmpty(this.hiMerchant.getCurrency())) {
/* 107 */         this.log.error("<Toolkit MSG> Input Parameter [CURRENCY] is null or empty.");
/* 108 */         throw new ToolkitException("-34");
/*     */       }
/* 110 */       setCurrency(this.hiMerchant.getCurrency());
/* 111 */       this.log.info("[C]Currency     = " + getCurrency());
/*     */     }
/*     */     else {
/* 114 */       this.log.info("[P]Currency     = " + getCurrency());
/*     */     }
/*     */ 
/* 117 */     if (isEmpty(getAmount())) {
/* 118 */       this.log.error("<Toolkit MSG> Input Parameter [AMOUNT] is null or empty.");
/* 119 */       throw new ToolkitException("-35");
/*     */     }
/* 121 */     this.log.info("[P]Amount       = " + getAmount());
/*     */ 
/* 124 */     if ((!"".equals(getE59())) && (getE59() != null) && ("1".equals(getE59())) && 
/* 125 */       (!"000".equals(getAmount()))) {
/* 126 */       this.log.error("<Toolkit MSG> Input account verify amount error.");
/* 127 */       throw new ToolkitException("-80");
/*     */     }
/*     */ 
/* 131 */     if (isEmpty(getReturnURL())) {
/* 132 */       if (isEmpty(this.hiMerchant.getReturnURL())) {
/* 133 */         this.log.error("<Toolkit MSG> Input Parameter [RETURNURL] is null or empty.");
/* 134 */         throw new ToolkitException("-37");
/*     */       }
/* 136 */       setReturnURL(this.hiMerchant.getReturnURL());
/* 137 */       this.log.info("[C]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */     else {
/* 140 */       this.log.info("[P]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */ 
/* 143 */     if (isEmpty(getDepositFlag())) {
/* 144 */       if (isEmpty(this.hiMerchant.getDeposit())) {
/* 145 */         this.log.error("<Toolkit MSG> Input Parameter [DEPOSIT] is null or empty.");
/* 146 */         throw new ToolkitException("-38");
/*     */       }
/* 148 */       setDepositFlag(this.hiMerchant.getDeposit());
/* 149 */       this.log.info("[C]Deposit      = " + getDepositFlag());
/*     */     }
/*     */     else {
/* 152 */       this.log.info("[P]Deposit      = " + getDepositFlag());
/*     */     }
/*     */ 
/* 155 */     if (isEmpty(getQueryFlag())) {
/* 156 */       if (isEmpty(this.hiMerchant.getQueryFlag())) {
/* 157 */         this.log.error("<Toolkit MSG> Input Parameter [QUERYFLAG] is null or empty.");
/* 158 */         throw new ToolkitException("-39");
/*     */       }
/* 160 */       setQueryFlag(this.hiMerchant.getQueryFlag());
/* 161 */       this.log.info("[C]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */     else {
/* 164 */       this.log.info("[P]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */ 
/* 167 */     if (isEmpty(getUpdateURL())) {
/* 168 */       if (isEmpty(this.hiMerchant.getUpdateURL())) {
/* 169 */         this.log.error("<Toolkit MSG> Input Parameter [UPDATEURL] is null or empty.");
/* 170 */         throw new ToolkitException("-40");
/*     */       }
/* 172 */       setUpdateURL(this.hiMerchant.getUpdateURL());
/* 173 */       this.log.info("[C]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */     else {
/* 176 */       this.log.info("[P]UpdateURL    = " + getUpdateURL());
/*     */     }
/* 178 */     if (getTicketNo() == null)
/* 179 */       setTicketNo("");
/* 180 */     if (getPan() == null)
/* 181 */       setPan("");
/* 182 */     if (getExpiry() == null)
/* 183 */       setExpiry("");
/* 184 */     if (getE01() == null)
/* 185 */       setE01("");
/* 186 */     if (getE02() == null)
/* 187 */       setE02("");
/* 188 */     if (getE03() == null)
/* 189 */       setE03("");
/* 190 */     if (getE04() == null)
/* 191 */       setE04("");
/* 192 */     if (getE05() == null)
/* 193 */       setE05("");
/* 194 */     if (getE11() == null)
/* 195 */       setE11("");
/* 196 */     if (getE12() == null)
/* 197 */       setE12("");
/* 198 */     if (getE13() == null)
/* 199 */       setE13("");
/* 200 */     if (getE14() == null) {
/* 201 */       setE14("");
/*     */     }
/* 203 */     if (getE35() == null)
/* 204 */       setE35("");
/* 205 */     if (getE36() == null)
/* 206 */       setE36("");
/* 207 */     if (getE37() == null)
/* 208 */       setE37("");
/* 209 */     if (getE38() == null)
/* 210 */       setE38("");
/* 211 */     if (getE39() == null)
/* 212 */       setE39("");
/* 213 */     if (getE40() == null)
/* 214 */       setE40("");
/* 215 */     if (getE41() == null)
/* 216 */       setE41("");
/* 217 */     if (getE42() == null)
/* 218 */       setE42("");
/* 219 */     if (getE52() == null)
/* 220 */       setE52("");
/* 221 */     if (getE53() == null)
/* 222 */       setE53("");
/* 223 */     if (getE54() == null)
/* 224 */       setE54("");
/* 225 */     if (getE56() == null)
/* 226 */       setE56("");
/* 227 */     if (getE57() == null)
/* 228 */       setE57("");
/* 229 */     if (getE58() == null)
/* 230 */       setE58("");
/* 231 */     if (getE59() == null) {
/* 232 */       setE59("");
/*     */     }
/* 234 */     this.log.info("[P]TicketNo     = " + getTicketNo());
/*     */     try {
/* 236 */       if ((getPan().equals("")) || (getPan().length() < 13))
/* 237 */         this.log.info("[P]PAN          = " + getPan());
/*     */       else
/* 239 */         this.log.info("[P]PAN          = " + getPan().substring(0, 6) + "******" + getPan().substring(getPan().length() - 4));
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 243 */       this.log.error(ex.getMessage());
/*     */     }
/*     */ 
/* 247 */     if (isEmpty(getTrxToken())) {
/* 248 */       this.log.error("-76");
/* 249 */       throw new ToolkitException("<Toolkit MSG> Input Parameter [TrxToken] is null or empty.");
/*     */     }
/* 251 */     this.log.info("[P]TrxToken     = " + getTrxToken());
/*     */ 
/* 254 */     if ((!isEmpty(getE36())) && 
/* 255 */       (getE36().length() > 10)) {
/* 256 */       this.log.error("<Toolkit MSG> Input Parameter [ID] is null or empty or format error.");
/* 257 */       throw new ToolkitException("-60");
/*     */     }
/*     */ 
/* 260 */     if ((!isEmpty(getE37())) && 
/* 261 */       (getE37().length() > 15)) {
/* 262 */       this.log.error("<Toolkit MSG> Input Parameter [CELLPHONE] is null or empty or length error.");
/* 263 */       throw new ToolkitException("-61");
/*     */     }
/*     */ 
/* 267 */     if (!isEmpty(getE38())) {
/* 268 */       if (getE38().length() != 4) {
/* 269 */         this.log.error("<Toolkit MSG> Input Parameter [YEAR_OF_BIRTH] is null or empty or length error.");
/* 270 */         throw new ToolkitException("-62");
/*     */       }
/* 272 */       if (getE39().length() == 0) {
/* 273 */         this.log.error("<Toolkit MSG> Input Parameter [MMDD_OF_BIRTH] is null or empty or length error.");
/* 274 */         throw new ToolkitException("-63");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 279 */     if (!isEmpty(getE39())) {
/* 280 */       if (getE39().length() != 4) {
/* 281 */         this.log.error("<Toolkit MSG> Input Parameter [MMDD_OF_BIRTH] is null or empty or length error.");
/* 282 */         throw new ToolkitException("-63");
/*     */       }
/* 284 */       if (getE38().length() == 0) {
/* 285 */         this.log.error("<Toolkit MSG> Input Parameter [YEAR_OF_BIRTH] is null or empty or length error.");
/* 286 */         throw new ToolkitException("-62");
/*     */       }
/*     */     }
/* 289 */     if ((!"".equals(getE40())) && (null != getE40()) && 
/* 290 */       (getE40().length() > 15)) {
/* 291 */       this.log.error("<Toolkit MSG> Input Parameter [HomePHONE] is null or empty or length error.");
/* 292 */       throw new ToolkitException("-64");
/*     */     }
/*     */ 
/* 295 */     if ((!"".equals(getE41())) && (null != getE41()) && 
/* 296 */       (getE41().length() > 15)) {
/* 297 */       this.log.error("<Toolkit MSG> Input Parameter [OfficePHONE] is null or empty or length error.");
/* 298 */       throw new ToolkitException("-65");
/*     */     }
/*     */ 
/* 301 */     if ("Y".equalsIgnoreCase(getE42()))
/*     */     {
/* 303 */       if (("".equals(getE36().trim())) && ("".equals(getE37().trim())) && ("".equals(getE38().trim())) && ("".equals(getE39().trim())) && ("".equals(getE40().trim())) && ("".equals(getE41().trim())))
/*     */       {
/* 305 */         this.log.error("<Toolkit MSG> Input Parameter all is blank for identifying.");
/* 306 */         throw new ToolkitException("-66");
/*     */       }
/* 308 */       if ("1".equals(getDepositFlag())) {
/* 309 */         this.log.error("<Toolkit MSG> Input Parameter only for identifying cannot with depositeflag.");
/* 310 */         throw new ToolkitException("-67");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 318 */     if (!isEmpty(getE52()))
/*     */     {
/* 320 */       if (getE52().matches("[0-9]{8}"))
/*     */       {
/* 322 */         if (!isEmpty(getE53())) {
/* 323 */           if (!getE53().matches("[0-9]{4}")) {
/* 324 */             this.log.error("<Toolkit MSG> Input Parameter [E54] format error.");
/* 325 */             throw new ToolkitException("-74");
/*     */           }
/*     */         } else {
/* 328 */           this.log.error("<Toolkit MSG> Input Parameter [E53] is null or empty.");
/* 329 */           throw new ToolkitException("-73");
/*     */         }
/*     */ 
/* 333 */         if (!isEmpty(getE54())) {
/* 334 */           if (getE54().length() > 10) {
/* 335 */             this.log.error("<Toolkit MSG> Input Parameter [E54] format error.");
/* 336 */             throw new ToolkitException("-74");
/*     */           }
/*     */         } else {
/* 339 */           this.log.error("<Toolkit MSG> Input Parameter [E54] is null or empty.");
/* 340 */           throw new ToolkitException("-75");
/*     */         }
/*     */       } else {
/* 343 */         this.log.error("<Toolkit MSG> Input Parameter [E52] format error.");
/* 344 */         throw new ToolkitException("-72");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 351 */     if ((!isEmpty(getE56())) && (isInteger(getE56()))) {
/* 352 */       if ((isEmpty(getE57())) || (getE57().length() > 6)) {
/* 353 */         this.log.error("<Toolkit MSG> Input Parameter [E57] format error.,E57=" + getE57());
/* 354 */         throw new ToolkitException("-78");
/*     */       }
/* 356 */       if ((isEmpty(getE58())) || ((!"D".equals(getE58())) && (!"W".equals(getE58())) && (!"M".equals(getE58())) && (!"Y".equals(getE58()))))
/*     */       {
/* 358 */         this.log.error("<Toolkit MSG> Input Parameter [E58] format error.,E58=" + getE58());
/* 359 */         throw new ToolkitException("-79");
/*     */       }
/* 361 */     } else if ((!isEmpty(getE56())) && (!isInteger(getE56()))) {
/* 362 */       this.log.error("-77,E56=" + getE56());
/* 363 */       throw new ToolkitException("<Toolkit MSG> Input Parameter [E56] format error.");
/*     */     }
/*     */ 
/* 366 */     this.log.info("[P]E02          = " + getE02());
/* 367 */     this.log.info("[P]E03          = " + getE03());
/* 368 */     this.log.info("[P]E04          = " + getE04());
/* 369 */     this.log.info("[P]E05          = " + getE05());
/* 370 */     this.log.info("[P]E11          = " + getE11());
/* 371 */     this.log.info("[P]E12          = " + getE12());
/* 372 */     this.log.info("[P]E13          = " + getE13());
/* 373 */     this.log.info("[P]E14          = " + getE14());
/* 374 */     this.log.info("[P]E15          = " + getName());
/* 375 */     this.log.info("[P]E16          = " + getEmail());
/* 376 */     this.log.info("[P]E17          = " + getE17());
/* 377 */     this.log.info("[P]E36          = " + getE36());
/* 378 */     this.log.info("[P]E37          = " + getE37());
/* 379 */     this.log.info("[P]E38          = " + getE38());
/* 380 */     this.log.info("[P]E39          = " + getE39());
/* 381 */     this.log.info("[P]E40          = " + getE40());
/* 382 */     this.log.info("[P]E41          = " + getE41());
/* 383 */     this.log.info("[P]E42          = " + getE42());
/* 384 */     this.log.info("[P]E52          = " + getE52());
/* 385 */     this.log.info("[P]E53          = " + getE53());
/* 386 */     this.log.info("[P]E54          = " + getE54());
/* 387 */     this.log.info("[P]E55          = " + getE55());
/* 388 */     this.log.info("[P]E56          = " + getE56());
/* 389 */     this.log.info("[P]E57          = " + getE57());
/* 390 */     this.log.info("[P]E58          = " + getE58());
/*     */   }
/*     */ 
/*     */   private void organizeMessage() throws ToolkitException, Exception {
/* 394 */     String message = "";
/* 395 */     StringBuffer sbMsg = new StringBuffer("");
/* 396 */     sbMsg.append("T01=").append(getType()).append("&");
/* 397 */     sbMsg.append("T02=").append(getOrderNo()).append("&");
/* 398 */     sbMsg.append("T03=").append(getStoreId()).append("&");
/* 399 */     sbMsg.append("T04=").append(getOrderDesc()).append("&");
/* 400 */     sbMsg.append("T05=").append(getCurrency()).append("&");
/* 401 */     sbMsg.append("T06=").append(getAmount()).append("&");
/* 402 */     sbMsg.append("T08=").append(getReturnURL()).append("&");
/* 403 */     sbMsg.append("T09=").append(getDepositFlag()).append("&");
/* 404 */     sbMsg.append("T10=").append(getQueryFlag()).append("&");
/* 405 */     sbMsg.append("T11=").append(getExtendField()).append("&");
/* 406 */     sbMsg.append("T12=").append(getUpdateURL()).append("&");
/* 407 */     sbMsg.append("T13=").append(getPan()).append("&");
/* 408 */     sbMsg.append("T14=").append(getExpiry()).append("&");
/* 409 */     sbMsg.append("T15=").append(getMerUpdateURL()).append("&");
/* 410 */     sbMsg.append("T16=").append(getTrxToken()).append("&");
/* 411 */     sbMsg.append("O01=").append(getTicketNo()).append("&");
/* 412 */     sbMsg.append("E01=").append(getE01()).append("&");
/* 413 */     sbMsg.append("E02=").append(getE02()).append("&");
/* 414 */     sbMsg.append("E03=").append(getE03()).append("&");
/* 415 */     sbMsg.append("E04=").append(getE04()).append("&");
/* 416 */     sbMsg.append("E05=").append(getE05()).append("&");
/* 417 */     sbMsg.append("E11=").append(getE11()).append("&");
/* 418 */     sbMsg.append("E12=").append(getE12()).append("&");
/* 419 */     sbMsg.append("E13=").append(getE13()).append("&");
/* 420 */     sbMsg.append("E14=").append(getE14()).append("&");
/* 421 */     sbMsg.append("E15=").append(getName()).append("&");
/* 422 */     sbMsg.append("E16=").append(getEmail()).append("&");
/* 423 */     sbMsg.append("E17=").append(getE17()).append("&");
/* 424 */     sbMsg.append("E35=").append(getE35()).append("&");
/* 425 */     sbMsg.append("E36=").append(getE36()).append("&");
/* 426 */     sbMsg.append("E37=").append(getE37()).append("&");
/* 427 */     sbMsg.append("E38=").append(getE38()).append("&");
/* 428 */     sbMsg.append("E39=").append(getE39()).append("&");
/* 429 */     sbMsg.append("E40=").append(getE40()).append("&");
/* 430 */     sbMsg.append("E41=").append(getE41()).append("&");
/* 431 */     sbMsg.append("E42=").append(getE42()).append("&");
/* 432 */     sbMsg.append("E52=").append(getE52()).append("&");
/* 433 */     sbMsg.append("E53=").append(getE53()).append("&");
/* 434 */     sbMsg.append("E54=").append(getE54()).append("&");
/* 435 */     sbMsg.append("E55=").append(getE55()).append("&");
/* 436 */     sbMsg.append("E56=").append(getE56()).append("&");
/* 437 */     sbMsg.append("E57=").append(getE57()).append("&");
/* 438 */     sbMsg.append("E58=").append(getE58()).append("&");
/* 439 */     sbMsg.append("E59=").append(getE59()).append("&");
/*     */ 
/* 442 */     message = sbMsg.toString();
/* 443 */     if (isEmpty(message)) {
/* 444 */       this.log.error("<Toolkit MSG> No Request Message.");
/* 445 */       throw new ToolkitException("-3");
/*     */     }
/* 447 */     setRequestMessage(message);
/*     */   }
/*     */ 
/*     */   private void parserResult() {
/* 451 */     setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/* 452 */     setAuthCode(parsingKeyword(getResponseMessage(), "R03"));
/* 453 */     setAuthRRN(parsingKeyword(getResponseMessage(), "R04"));
/* 454 */     setEci(parsingKeyword(getResponseMessage(), "R25"));
/* 455 */     setToken(parsingKeyword(getResponseMessage(), "R24"));
/*     */ 
/* 457 */     setE28(parsingKeyword(getResponseMessage(), "E28"));
/* 458 */     setE29(parsingKeyword(getResponseMessage(), "E29"));
/* 459 */     this.log.info("@RC             = " + getRetCode());
/* 460 */     this.log.info("@Token          = " + getToken());
/*     */   }
/*     */ 
/*     */   private static boolean isInteger(String str) {
/* 464 */     Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
/* 465 */     return pattern.matcher(str).matches();
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.B2CPayAuthTrxToken
 * JD-Core Version:    0.6.0
 */