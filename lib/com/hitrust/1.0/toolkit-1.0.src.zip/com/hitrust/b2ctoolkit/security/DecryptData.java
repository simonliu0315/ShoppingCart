/*    */ package com.hitrust.b2ctoolkit.security;
/*    */ 
/*    */ import au.net.aba.crypto.provider.RC4Key;
/*    */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*    */ import com.hitrust.regional.security.RC4;
/*    */ import com.hitrust.regional.security.RSA;
/*    */ import com.hitrust.regional.security.RegionalSecurityException;
/*    */ import com.hitrust.regional.tool.ByteUtil;
/*    */ import javax.crypto.SecretKey;
/*    */ 
/*    */ public class DecryptData
/*    */ {
/*    */   public static String decrypt(String strCipher, String strEncKey, String strMAC, String strPriKeyFile, String strPubKeyFile)
/*    */     throws Exception
/*    */   {
/* 25 */     byte[] bytesEncKey = null;
/* 26 */     byte[] bytesRC4Key = null;
/* 27 */     byte[] bytesCIPHER = null;
/* 28 */     byte[] bytesOriginalData = null;
/* 29 */     byte[] bytesMAC = null;
/*    */ 
/* 31 */     bytesEncKey = ByteUtil.hexStr2Bytes(strEncKey);
/*    */     try
/*    */     {
/* 34 */       bytesRC4Key = RSA.rsaDec(bytesEncKey, strPriKeyFile, 16);
/*    */     }
/*    */     catch (RegionalSecurityException e) {
/* 37 */       throw new ToolkitException("-27");
/*    */     }
/*    */ 
/* 40 */     SecretKey rc4Key = new RC4Key(bytesRC4Key);
/*    */ 
/* 42 */     bytesCIPHER = ByteUtil.hexStr2Bytes(strCipher);
/*    */     try {
/* 44 */       bytesOriginalData = RC4.rc4Dec(bytesCIPHER, rc4Key);
/*    */     }
/*    */     catch (RegionalSecurityException e) {
/* 47 */       throw new ToolkitException("-17");
/*    */     }
/*    */ 
/* 51 */     String strData = new String(bytesOriginalData);
/* 52 */     bytesMAC = ByteUtil.hexStr2Bytes(strMAC);
/*    */     try
/*    */     {
/* 55 */       if (RSA.rsaVerify(bytesMAC, bytesOriginalData, strPubKeyFile, 1)) {
/* 56 */         return strData;
/*    */       }
/*    */ 
/* 59 */       throw new ToolkitException("-17");
/*    */     }
/*    */     catch (RegionalSecurityException e) {
/*    */     }
/* 63 */     throw new ToolkitException("-23");
/*    */   }
/*    */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.security.DecryptData
 * JD-Core Version:    0.6.0
 */