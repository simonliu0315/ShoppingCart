/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.util.HiMerchant;
/*     */ import com.hitrust.b2ctoolkit.util.HiServer;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class MERAB2CEncode extends B2CPay
/*     */ {
/*     */   public void transaction()
/*     */   {
/*  21 */     boolean logflag = false;
/*     */     try {
/*  23 */       if (isEmpty(getStoreId())) {
/*  24 */         throw new ToolkitException("-32");
/*     */       }
/*  26 */       getHiMerchant();
/*  27 */       getLogger();
/*     */ 
/*  29 */       logflag = true;
/*     */ 
/*  31 */       this.log.info("----- New Encode Start  -----");
/*  32 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*  33 */       this.log.info("[C]StoreID      = " + getStoreId());
/*     */ 
/*  36 */       setType("19");
/*     */ 
/*  39 */       checkData();
/*  40 */       this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/*  43 */       organizeMessage();
/*  44 */       this.log.info("Organize Message [ ok ].");
/*     */ 
/*  47 */       this.log.info("Send Message......");
/*  48 */       connectTo(HiServer.getAuthUrl());
/*     */ 
/*  50 */       this.log.info("Receive Response [ ok ].");
/*     */ 
/*  53 */       parserResult();
/*  54 */       this.log.info("parsing Message [ ok ].");
/*     */ 
/*  56 */       this.log.info("----- New Encode End  -----\n");
/*     */     } catch (ToolkitException e) {
/*  58 */       setRetCode(e.getMessage());
/*  59 */       if (logflag) {
/*  60 */         this.log.info("Run Error! Code ==" + getRetCode());
/*  61 */         this.log.info("----- New Encode End  -----\n");
/*     */       }
/*     */     } catch (Exception e) {
/*  64 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkData() throws ToolkitException, Exception
/*     */   {
/*  70 */     if (isEmpty(getType())) {
/*  71 */       this.log.error("<Toolkit MSG> Input Parameter [TrxType] is wrong.");
/*  72 */       throw new ToolkitException("-45");
/*     */     }
/*     */ 
/*  75 */     if (isEmpty(getSN())) {
/*  76 */       this.log.error("<Toolkit MSG> Input Parameter [SN] is null or empty or format error.");
/*  77 */       throw new ToolkitException("-55");
/*     */     }
/*  79 */     this.log.info("[P]SN    = " + getSN());
/*     */ 
/*  82 */     if (isEmpty(getReturnURL())) {
/*  83 */       if (isEmpty(this.hiMerchant.getReturnURL())) {
/*  84 */         this.log.error("<Toolkit MSG> Input Parameter [RETURNURL] is null or empty.");
/*  85 */         throw new ToolkitException("-37");
/*     */       }
/*  87 */       setReturnURL(this.hiMerchant.getReturnURL());
/*  88 */       this.log.info("[C]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */     else {
/*  91 */       this.log.info("[P]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */ 
/*  94 */     if (isEmpty(getUpdateURL())) {
/*  95 */       if (isEmpty(this.hiMerchant.getUpdateURL())) {
/*  96 */         this.log.error("<Toolkit MSG> Input Parameter [UPDATEURL] is null or empty.");
/*  97 */         throw new ToolkitException("-40");
/*     */       }
/*  99 */       setUpdateURL(this.hiMerchant.getUpdateURL());
/* 100 */       this.log.info("[C]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */     else {
/* 103 */       this.log.info("[P]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void organizeMessage() throws ToolkitException, Exception
/*     */   {
/* 109 */     String message = "";
/* 110 */     message = "T01=" + getType() + "&" + "T02=" + getOrderNo() + "&" + "T03=" + getStoreId() + "&" + "T08=" + getReturnURL() + "&" + "T12=" + getUpdateURL();
/*     */ 
/* 116 */     if (isEmpty(message)) {
/* 117 */       this.log.error("<Toolkit MSG> No Request Message.");
/* 118 */       throw new ToolkitException("-3");
/*     */     }
/* 120 */     setRequestMessage(message);
/*     */   }
/*     */ 
/*     */   private void parserResult() {
/* 124 */     setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/* 125 */     setToken(parsingKeyword(getResponseMessage(), "R24"));
/*     */ 
/* 127 */     this.log.info("@RC             = " + getRetCode());
/* 128 */     this.log.info("@Token          = " + getToken());
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.MERAB2CEncode
 * JD-Core Version:    0.6.0
 */