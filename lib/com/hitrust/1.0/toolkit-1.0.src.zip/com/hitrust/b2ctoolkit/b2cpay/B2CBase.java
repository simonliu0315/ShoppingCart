/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.bouncycastle.util.encoders.Hex;
/*     */ 
/*     */ public abstract class B2CBase extends B2CPay
/*     */ {
/*  24 */   private static String toEncoding = "Big5";
/*     */ 
/*  28 */   String msgToBeSent = null;
/*  29 */   String strT01 = null;
/*     */ 
/*  31 */   HashMap hmTagsForSend = new HashMap();
/*  32 */   HashMap hmTagsFromResponse = new HashMap();
/*     */ 
/*  34 */   String fromEncoding = null;
/*     */ 
/*     */   public static String getToEncoding()
/*     */   {
/*  26 */     return toEncoding;
/*     */   }
/*     */ 
/*     */   public B2CBase(String storeId, String strT01)
/*     */   {
/*  42 */     super.setStoreId(storeId);
/*  43 */     this.strT01 = strT01;
/*     */   }
/*     */ 
/*     */   protected String changeEncodingAndConvertToHex(String str) throws UnsupportedEncodingException
/*     */   {
/*  48 */     byte[] b = null;
/*  49 */     if (this.fromEncoding != null)
/*  50 */       b = new String(str.getBytes(this.fromEncoding), toEncoding).getBytes(toEncoding);
/*     */     else {
/*  52 */       b = str.getBytes(toEncoding);
/*     */     }
/*     */ 
/*  55 */     return new String(Hex.encode(b));
/*     */   }
/*     */   protected abstract String getConnectTargetURL() throws ToolkitException;
/*     */ 
/*     */   public String getFromEncoding() {
/*  61 */     return this.fromEncoding;
/*     */   }
/*     */ 
/*     */   protected String getMessage() {
/*  65 */     String rtn = "";
/*  66 */     Iterator it = this.hmTagsForSend.keySet().iterator();
/*     */ 
/*  68 */     while (it.hasNext()) {
/*  69 */       String tag = (String)it.next();
/*  70 */       String value = (String)this.hmTagsForSend.get(tag);
/*  71 */       rtn = rtn + tag + "=" + value + "&";
/*     */     }
/*  73 */     return rtn;
/*     */   }
/*     */ 
/*     */   protected abstract void handleResponse(HashMap paramHashMap)
/*     */     throws Exception;
/*     */ 
/*     */   protected abstract void prepareData(HashMap paramHashMap)
/*     */     throws ToolkitException;
/*     */ 
/*     */   public void setFromEncoding(String fromEncoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/*  95 */     if ((fromEncoding == null) || (fromEncoding.trim().length() == 0)) {
/*  96 */       this.fromEncoding = null;
/*  97 */       return;
/*     */     }
/*     */ 
/* 101 */     new String("").getBytes(fromEncoding);
/*     */ 
/* 103 */     this.fromEncoding = fromEncoding;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void setStoreId(String storeId)
/*     */   {
/* 111 */     super.setStoreId(storeId);
/*     */   }
/*     */ 
/*     */   private void settleResponse()
/*     */   {
/* 119 */     this.log.info("----- B2CBase settleResponse -----");
/* 120 */     String tmp = getResponseMessage();
/* 121 */     String[] taglines = tmp.split("&");
/*     */ 
/* 123 */     if (taglines == null) {
/* 124 */       this.log.debug("settleResponse ... taglines is null");
/*     */     }
/* 126 */     for (int i = 0; i < taglines.length; i++)
/*     */     {
/* 128 */       if (taglines[i] == null) {
/* 129 */         this.log.debug("settleResponse ... tags[" + i + "] is null");
/*     */       }
/*     */       else
/*     */       {
/* 133 */         String[] tag = taglines[i].split("=");
/*     */ 
/* 135 */         if ((tag == null) || (tag.length == 0)) {
/* 136 */           this.log.debug("settleResponse ... tag is null");
/*     */         }
/* 140 */         else if (tag[0] == null) {
/* 141 */           this.log.debug("settleResponse ... tag key is null");
/*     */         }
/* 145 */         else if (tag.length == 1)
/* 146 */           this.hmTagsFromResponse.put(tag[0], "");
/*     */         else
/* 148 */           this.hmTagsFromResponse.put(tag[0], tag[1]);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void transaction()
/*     */   {
/*     */     try
/*     */     {
/* 158 */       getLogger();
/* 159 */       this.log.info("----- B2CBase submit start -----");
/* 160 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*     */ 
/* 162 */       if (isEmpty(getStoreId())) {
/* 163 */         throw new ToolkitException("-32");
/*     */       }
/*     */ 
/* 166 */       getHiMerchant();
/*     */ 
/* 169 */       this.hmTagsForSend.put("T01", this.strT01);
/*     */       try {
/* 171 */         prepareData(this.hmTagsForSend);
/*     */       } catch (ToolkitException tkex) {
/* 173 */         throw tkex;
/*     */       } catch (Exception e1) {
/* 175 */         this.log.error("prepareData() failed: " + e1.getMessage());
/* 176 */         throw new ToolkitException("-3");
/*     */       }
/*     */ 
/* 180 */       Iterator it = this.hmTagsForSend.keySet().iterator();
/* 181 */       while (it.hasNext()) {
/* 182 */         String k = (String)it.next();
/* 183 */         String v = (String)this.hmTagsForSend.get(k);
/* 184 */         this.log.info("[SEND]" + k + "\t = " + v);
/*     */       }
/*     */ 
/* 188 */       setRequestMessage(getMessage());
/* 189 */       this.log.debug("REQ: " + getRequestMessage());
/* 190 */       this.log.info("Organize Message [ ok ].");
/*     */ 
/* 193 */       this.log.info("Send Message......");
/*     */       try {
/* 195 */         connectTo(getConnectTargetURL());
/*     */       } catch (ToolkitException tkex) {
/* 197 */         throw tkex;
/*     */       } catch (Exception e) {
/* 199 */         this.log.error("connectTo() failed: " + e.getMessage());
/* 200 */         throw new ToolkitException("-4");
/*     */       }
/* 202 */       this.log.info("Receive Response [ ok ].");
/*     */ 
/* 205 */       this.log.debug("RESP: " + getResponseMessage());
/*     */ 
/* 208 */       setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/*     */ 
/* 211 */       settleResponse();
/*     */ 
/* 214 */       it = this.hmTagsFromResponse.keySet().iterator();
/* 215 */       while (it.hasNext()) {
/* 216 */         String k = (String)it.next();
/* 217 */         String v = (String)this.hmTagsFromResponse.get(k);
/* 218 */         this.log.info("[RECV]" + k + "\t = " + v);
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 223 */         handleResponse(this.hmTagsFromResponse);
/*     */       } catch (ToolkitException tkex) {
/* 225 */         throw tkex;
/*     */       } catch (Exception e) {
/* 227 */         this.log.error("handleResponse() failed: " + e.getMessage());
/* 228 */         this.log.debug("handleResponse() failed: ", e);
/* 229 */         throw new ToolkitException("-7");
/*     */       }
/*     */     }
/*     */     catch (ToolkitException e) {
/* 233 */       setRetCode(e.getMessage());
/* 234 */       this.log.info("Run Error! Code ==" + getRetCode());
/* 235 */       this.log.debug("Run Error! Code ==" + getRetCode(), e);
/*     */     }
/* 237 */     this.log.info("----- B2CBase submit end -----");
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.B2CBase
 * JD-Core Version:    0.6.0
 */