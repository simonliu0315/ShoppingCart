/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.util.HiMerchant;
/*     */ import com.hitrust.b2ctoolkit.util.HiServer;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class B2CPayEMVSign extends B2CPay
/*     */ {
/*     */   public void transaction()
/*     */   {
/*  21 */     boolean logflag = false;
/*     */     try {
/*  23 */       if (isEmpty(getStoreId())) {
/*  24 */         throw new ToolkitException("-32");
/*     */       }
/*  26 */       getHiMerchant();
/*     */ 
/*  28 */       getLogger();
/*     */ 
/*  30 */       logflag = true;
/*     */ 
/*  32 */       this.log.info("----- New EMVSIGN Start  -----");
/*  33 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*     */ 
/*  36 */       setType("12");
/*     */ 
/*  39 */       checkData();
/*  40 */       this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/*  43 */       organizeMessage();
/*  44 */       this.log.info("Organize Message [ ok ].");
/*     */ 
/*  47 */       this.log.info("Send Message......");
/*  48 */       connectTo(HiServer.getOtherUrl());
/*  49 */       this.log.info("Receive Response [ ok ].");
/*     */ 
/*  52 */       parserResult();
/*  53 */       this.log.info("parsing Message [ ok ].");
/*     */ 
/*  55 */       this.log.info("----- New AuthSSL End  -----\n");
/*     */     } catch (ToolkitException e) {
/*  57 */       setRetCode(e.getMessage());
/*  58 */       if (logflag) {
/*  59 */         this.log.info("Run Error! Code ==" + getRetCode());
/*  60 */         this.log.info("----- New EMVSIGN End  -----\n");
/*     */       }
/*     */     } catch (Exception e) {
/*  63 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkData() throws ToolkitException, Exception
/*     */   {
/*  69 */     if (isEmpty(getType())) {
/*  70 */       this.log.error("<Toolkit MSG> Input Parameter [TrxType] is wrong.");
/*  71 */       throw new ToolkitException("-45");
/*     */     }
/*     */ 
/*  74 */     if (isEmpty(getOrderNo())) {
/*  75 */       this.log.error("<Toolkit MSG> Input Parameter [ORDERNO] is null or empty.");
/*  76 */       throw new ToolkitException("-31");
/*     */     }
/*  78 */     this.log.info("[P]OrderNo      = " + getOrderNo());
/*     */ 
/*  81 */     if (isEmpty(getOrderDesc())) {
/*  82 */       if (isEmpty(this.hiMerchant.getOrderDesc())) {
/*  83 */         this.log.error("<Toolkit MSG> Input Parameter [ORDERDESC] is null or empty.");
/*  84 */         throw new ToolkitException("-33");
/*     */       }
/*  86 */       setOrderDesc(this.hiMerchant.getOrderDesc());
/*  87 */       this.log.info("[C]OrderDesc    = " + getOrderDesc());
/*     */     }
/*     */     else {
/*  90 */       this.log.info("[P]OrderDesc    = " + getOrderDesc());
/*     */     }
/*     */ 
/*  93 */     if (isEmpty(getCurrency())) {
/*  94 */       if (isEmpty(this.hiMerchant.getCurrency())) {
/*  95 */         this.log.error("<Toolkit MSG> Input Parameter [CURRENCY] is null or empty.");
/*  96 */         throw new ToolkitException("-34");
/*     */       }
/*  98 */       setCurrency(this.hiMerchant.getCurrency());
/*  99 */       this.log.info("[C]Currency     = " + getCurrency());
/*     */     }
/*     */     else {
/* 102 */       this.log.info("[P]Currency     = " + getCurrency());
/*     */     }
/*     */ 
/* 105 */     if (isEmpty(getAmount())) {
/* 106 */       this.log.error("<Toolkit MSG> Input Parameter [AMOUNT] is null or empty.");
/* 107 */       throw new ToolkitException("-35");
/*     */     }
/* 109 */     this.log.info("[P]Amount       = " + getAmount());
/*     */ 
/* 112 */     if (isEmpty(getReturnURL())) {
/* 113 */       if (isEmpty(this.hiMerchant.getReturnURL())) {
/* 114 */         this.log.error("<Toolkit MSG> Input Parameter [RETURNURL] is null or empty.");
/* 115 */         throw new ToolkitException("-37");
/*     */       }
/* 117 */       setReturnURL(this.hiMerchant.getReturnURL());
/* 118 */       this.log.info("[C]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */     else {
/* 121 */       this.log.info("[P]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */ 
/* 124 */     if (isEmpty(getDepositFlag())) {
/* 125 */       if (isEmpty(this.hiMerchant.getDeposit())) {
/* 126 */         this.log.error("<Toolkit MSG> Input Parameter [DEPOSIT] is null or empty.");
/* 127 */         throw new ToolkitException("-38");
/*     */       }
/* 129 */       setDepositFlag(this.hiMerchant.getDeposit());
/* 130 */       this.log.info("[C]Deposit      = " + getDepositFlag());
/*     */     }
/*     */     else {
/* 133 */       this.log.info("[P]Deposit      = " + getDepositFlag());
/*     */     }
/*     */ 
/* 136 */     if (isEmpty(getQueryFlag())) {
/* 137 */       if (isEmpty(this.hiMerchant.getQueryFlag())) {
/* 138 */         this.log.error("<Toolkit MSG> Input Parameter [QUERYFLAG] is null or empty.");
/* 139 */         throw new ToolkitException("-39");
/*     */       }
/* 141 */       setQueryFlag(this.hiMerchant.getQueryFlag());
/* 142 */       this.log.info("[C]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */     else {
/* 145 */       this.log.info("[P]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */ 
/* 148 */     if (isEmpty(getUpdateURL())) {
/* 149 */       if (isEmpty(this.hiMerchant.getUpdateURL())) {
/* 150 */         this.log.error("<Toolkit MSG> Input Parameter [UPDATEURL] is null or empty.");
/* 151 */         throw new ToolkitException("-40");
/*     */       }
/* 153 */       setUpdateURL(this.hiMerchant.getUpdateURL());
/* 154 */       this.log.info("[C]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */     else {
/* 157 */       this.log.info("[P]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */ 
/* 174 */     if (isEmpty(getE22())) {
/* 175 */       this.log.error("<Toolkit MSG> Input Parameter [E22] is null or empty.");
/* 176 */       throw new ToolkitException("-50");
/*     */     }
/* 178 */     this.log.info("[P]E22       = " + getE22());
/*     */ 
/* 180 */     if (isEmpty(getE23())) {
/* 181 */       this.log.error("<Toolkit MSG> Input Parameter [E23] is null or empty.");
/* 182 */       throw new ToolkitException("-51");
/*     */     }
/* 184 */     this.log.info("[P]E23       = " + getE23());
/*     */ 
/* 186 */     if (isEmpty(getE24())) {
/* 187 */       this.log.error("<Toolkit MSG> Input Parameter [E24] is null or empty.");
/* 188 */       throw new ToolkitException("-52");
/*     */     }
/* 190 */     this.log.info("[P]E24       = " + getE24());
/*     */ 
/* 194 */     if (getTicketNo() == null) setTicketNo("");
/* 195 */     if (getPan() == null) setPan("");
/* 196 */     if (getExpiry() == null) setExpiry("");
/* 197 */     if (getE01() == null) setE01("");
/* 198 */     if (getE02() == null) setE02("");
/* 199 */     if (getE03() == null) setE03("");
/* 200 */     if (getE04() == null) setE04("");
/* 201 */     if (getE05() == null) setE05("");
/* 202 */     if (getE11() == null) setE11("");
/* 203 */     if (getE12() == null) setE12("");
/* 204 */     if (getE13() == null) setE13("");
/* 205 */     if (getE14() == null) setE14("");
/*     */ 
/* 207 */     this.log.info("[P]TicketNo     = " + getTicketNo());
/* 208 */     this.log.info("[P]PAN          = " + getPan());
/* 209 */     this.log.info("[P]Expiry       = " + getExpiry());
/* 210 */     this.log.info("[P]E01          = " + getE01());
/* 211 */     this.log.info("[P]E02          = " + getE02());
/* 212 */     this.log.info("[P]E03          = " + getE03());
/* 213 */     this.log.info("[P]E04          = " + getE04());
/* 214 */     this.log.info("[P]E05          = " + getE05());
/*     */ 
/* 216 */     this.log.info("[P]E11          = " + getE11());
/* 217 */     this.log.info("[P]E12          = " + getE12());
/* 218 */     this.log.info("[P]E13          = " + getE13());
/* 219 */     this.log.info("[P]E14          = " + getE14());
/*     */   }
/*     */ 
/*     */   private void organizeMessage() throws ToolkitException, Exception {
/* 223 */     String message = "";
/* 224 */     message = "T01=" + getType() + "&" + "T02=" + getOrderNo() + "&" + "T03=" + getStoreId() + "&" + "T04=" + getOrderDesc() + "&" + "T05=" + getCurrency() + "&" + "T06=" + getAmount() + "&" + "T08=" + getReturnURL() + "&" + "T09=" + getDepositFlag() + "&" + "T10=" + getQueryFlag() + "&" + "T11=" + getExtendField() + "&" + "T12=" + getUpdateURL() + "&" + "T13=" + getPan() + "&" + "T14=" + getExpiry() + "&" + "O01=" + getTicketNo() + "&" + "E01=" + getE01() + "&" + "E02=" + getE02() + "&" + "E03=" + getE03() + "&" + "E04=" + getE04() + "&" + "E05=" + getE05() + "&" + "E11=" + getE11() + "&" + "E12=" + getE12() + "&" + "E13=" + getE13() + "&" + "E14=" + getE14() + "&" + "E22=" + getE22() + "&" + "E23=" + getE23() + "&" + "E24=" + getE24();
/*     */ 
/* 252 */     if (isEmpty(message)) {
/* 253 */       this.log.error("<Toolkit MSG> No Request Message.");
/* 254 */       throw new ToolkitException("-3");
/*     */     }
/* 256 */     setRequestMessage(message);
/*     */   }
/*     */ 
/*     */   private void parserResult() {
/* 260 */     setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/* 261 */     setOrderDesc(parsingKeyword(getResponseMessage(), "T04"));
/* 262 */     setCurrency(parsingKeyword(getResponseMessage(), "T05"));
/* 263 */     if (getQueryFlag().equals("1")) {
/* 264 */       setSecCode(parsingKeyword(getResponseMessage(), "R02"));
/* 265 */       setAuthCode(parsingKeyword(getResponseMessage(), "R03"));
/* 266 */       setAuthRRN(parsingKeyword(getResponseMessage(), "R04"));
/* 267 */       setOrderStatus(parsingKeyword(getResponseMessage(), "R05"));
/* 268 */       setCreditStatus(parsingKeyword(getResponseMessage(), "R06"));
/* 269 */       setAcquirer(parsingKeyword(getResponseMessage(), "R07"));
/* 270 */       setCardType(parsingKeyword(getResponseMessage(), "R08"));
/* 271 */       setApproveAmount(parsingKeyword(getResponseMessage(), "R09"));
/* 272 */       setCaptureAmount(parsingKeyword(getResponseMessage(), "R10"));
/* 273 */       setCaptureNum(parsingKeyword(getResponseMessage(), "R11"));
/* 274 */       setRefundAmount(parsingKeyword(getResponseMessage(), "R12"));
/* 275 */       setRefundNum(parsingKeyword(getResponseMessage(), "R13"));
/* 276 */       setOrderDate(parsingKeyword(getResponseMessage(), "R14"));
/* 277 */       setPayBatchNum(parsingKeyword(getResponseMessage(), "R15"));
/* 278 */       setCaptureCode(parsingKeyword(getResponseMessage(), "R16"));
/* 279 */       setCaptureDate(parsingKeyword(getResponseMessage(), "R17"));
/* 280 */       setPaymentNum(parsingKeyword(getResponseMessage(), "R18"));
/* 281 */       setRefundBatch(parsingKeyword(getResponseMessage(), "R20"));
/* 282 */       setRefundCode(parsingKeyword(getResponseMessage(), "R21"));
/* 283 */       setRefundRRN(parsingKeyword(getResponseMessage(), "R22"));
/* 284 */       setRefundDate(parsingKeyword(getResponseMessage(), "R23"));
/* 285 */       setToken(parsingKeyword(getResponseMessage(), "R24"));
/* 286 */       setEci(parsingKeyword(getResponseMessage(), "R25"));
/*     */     }
/*     */ 
/* 289 */     setE06(parsingKeyword(getResponseMessage(), "E06"));
/* 290 */     setE07(parsingKeyword(getResponseMessage(), "E07"));
/* 291 */     setE08(parsingKeyword(getResponseMessage(), "E08"));
/* 292 */     setE09(parsingKeyword(getResponseMessage(), "E09"));
/* 293 */     setE10(parsingKeyword(getResponseMessage(), "E10"));
/*     */ 
/* 295 */     this.log.info("@RC             = " + getRetCode());
/* 296 */     this.log.info("@Token          = " + getToken());
/* 297 */     this.log.info("@E06            = " + getE06());
/* 298 */     this.log.info("@E07            = " + getE07());
/* 299 */     this.log.info("@E08            = " + getE08());
/* 300 */     this.log.info("@E09            = " + getE09());
/* 301 */     this.log.info("@E10            = " + getE10());
/* 302 */     this.log.info("@AuthCode       = " + getAuthCode());
/* 303 */     this.log.info("@AuthRRN        = " + getAuthRRN());
/* 304 */     this.log.info("@CardType       = " + getCardType());
/* 305 */     this.log.info("@OrderStatus    = " + getOrderStatus());
/* 306 */     this.log.info("@Acquirer       = " + getAcquirer());
/* 307 */     this.log.info("@ApproveAmount  = " + getApproveAmount());
/* 308 */     this.log.info("@CaptureAmount  = " + getCaptureAmount());
/* 309 */     this.log.info("@RefundAmount   = " + getRefundAmount());
/* 310 */     this.log.info("@OrderDate      = " + getOrderDate());
/* 311 */     this.log.info("@PayBatchNum    = " + getPayBatchNum());
/* 312 */     this.log.info("@CaptureDate    = " + getCaptureDate());
/* 313 */     this.log.info("@RefundBatch    = " + getRefundBatch());
/* 314 */     this.log.info("@RefundCode     = " + getRefundCode());
/* 315 */     this.log.info("@RefundRRN      = " + getRefundRRN());
/* 316 */     this.log.info("@RefundDate     = " + getRefundDate());
/* 317 */     this.log.info("@ECI            = " + getEci());
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.B2CPayEMVSign
 * JD-Core Version:    0.6.0
 */