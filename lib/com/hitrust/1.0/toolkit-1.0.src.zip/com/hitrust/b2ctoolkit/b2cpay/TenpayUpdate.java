/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.security.bc.BCDecryptData;
/*     */ import com.hitrust.b2ctoolkit.util.HiMerchant;
/*     */ import com.hitrust.b2ctoolkit.util.HiServer3;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class TenpayUpdate extends B2CPay
/*     */ {
/*     */   private String key;
/*     */   private String cipher;
/*     */   private String mac;
/*     */ 
/*     */   public void setKey(String key)
/*     */   {
/*  23 */     this.key = key;
/*     */   }
/*     */   public void setCipher(String cipher) {
/*  26 */     this.cipher = cipher;
/*     */   }
/*     */   public void setMac(String mac) {
/*  29 */     this.mac = mac;
/*     */   }
/*     */   public void transaction() {
/*  32 */     boolean logflag = false;
/*     */     try {
/*  34 */       if (isEmpty(getStoreId())) {
/*  35 */         throw new ToolkitException("-32");
/*     */       }
/*  37 */       getHiMerchant();
/*     */ 
/*  39 */       getLogger();
/*     */ 
/*  41 */       logflag = true;
/*     */ 
/*  43 */       this.log.info("----- New Update Start  -----");
/*  44 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*     */ 
/*  47 */       checkData();
/*  48 */       this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/*  51 */       setResponseMessage(BCDecryptData.decrypt(this.cipher, this.key, this.mac, this.hiMerchant.getRSAName(), HiServer3.getRSAName()));
/*  52 */       this.log.info("Decrypt Message [ ok ].");
/*     */ 
/*  55 */       parserResult();
/*  56 */       this.log.info("parsing Message [ ok ].");
/*     */ 
/*  59 */       this.log.info("----- New Update End  -----\n");
/*     */     } catch (ToolkitException e) {
/*  61 */       setRetCode(e.getMessage());
/*  62 */       if (logflag) {
/*  63 */         this.log.info("Run Error! Code ==" + getRetCode());
/*  64 */         this.log.info("----- New Update End  -----\n");
/*     */       }
/*     */     } catch (Exception e) {
/*  67 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkData() throws ToolkitException {
/*  72 */     if (isEmpty(this.key)) {
/*  73 */       this.log.error("<Toolkit MSG> Input Parameter [KEY] is null or empty.");
/*  74 */       throw new ToolkitException("-42");
/*     */     }
/*  76 */     if (isEmpty(this.mac)) {
/*  77 */       this.log.error("<Toolkit MSG> Input Parameter [MAC] is null or empty.");
/*  78 */       throw new ToolkitException("-43");
/*     */     }
/*  80 */     if (isEmpty(this.cipher)) {
/*  81 */       this.log.error("<Toolkit MSG> Input Parameter [CIPHER] is null or empty.");
/*  82 */       throw new ToolkitException("-44");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void parserResult() {
/*  87 */     setType(parsingKeyword(getResponseMessage(), "T01"));
/*  88 */     setOrderNo(parsingKeyword(getResponseMessage(), "T02"));
/*  89 */     setStoreId(parsingKeyword(getResponseMessage(), "T03"));
/*  90 */     setOrderDesc(parsingKeyword(getResponseMessage(), "T04"));
/*  91 */     setCurrency(parsingKeyword(getResponseMessage(), "T05"));
/*  92 */     setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/*  93 */     setSecCode(parsingKeyword(getResponseMessage(), "R02"));
/*  94 */     setOrderStatus(parsingKeyword(getResponseMessage(), "R05"));
/*  95 */     setCardType(parsingKeyword(getResponseMessage(), "R08"));
/*  96 */     setApproveAmount(parsingKeyword(getResponseMessage(), "R09"));
/*  97 */     setRefundAmount(parsingKeyword(getResponseMessage(), "R12"));
/*  98 */     setRefundNum(parsingKeyword(getResponseMessage(), "R13"));
/*  99 */     setRefundCode(parsingKeyword(getResponseMessage(), "R21"));
/* 100 */     setRefundRRN(parsingKeyword(getResponseMessage(), "R22"));
/* 101 */     setRefundDate(parsingKeyword(getResponseMessage(), "R23"));
/* 102 */     setToken(parsingKeyword(getResponseMessage(), "R24"));
/* 103 */     setEci(parsingKeyword(getResponseMessage(), "R25"));
/* 104 */     setE06(parsingKeyword(getResponseMessage(), "E06"));
/* 105 */     setE07(parsingKeyword(getResponseMessage(), "E07"));
/* 106 */     setE08(parsingKeyword(getResponseMessage(), "E08"));
/* 107 */     setE09(parsingKeyword(getResponseMessage(), "E09"));
/* 108 */     setE10(parsingKeyword(getResponseMessage(), "E10"));
/* 109 */     setProdName(parsingKeyword(getResponseMessage(), "E44"));
/*     */ 
/* 113 */     setMerUpdateURL(parsingKeyword(getResponseMessage(), "T15"));
/*     */ 
/* 115 */     this.log.info("@OrderNo        = " + getOrderNo());
/* 116 */     this.log.info("@OrderDesc      = " + getOrderDesc());
/* 117 */     this.log.info("@RetCode        = " + getRetCode());
/* 118 */     this.log.info("@AuthCode       = " + getAuthCode());
/* 119 */     this.log.info("@OrderStatus    = " + getOrderStatus());
/* 120 */     this.log.info("@RefundAmount   = " + getRefundAmount());
/* 121 */     this.log.info("@OrderDate      = " + getOrderDate());
/* 122 */     this.log.info("@RefundCode     = " + getRefundCode());
/* 123 */     this.log.info("@Currency       = " + getCurrency());
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.TenpayUpdate
 * JD-Core Version:    0.6.0
 */