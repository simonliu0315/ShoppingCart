/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.util.HiMerchant;
/*     */ import com.hitrust.b2ctoolkit.util.HiServer;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import java.io.PrintStream;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class TenpayOther extends B2CPay
/*     */ {
/*     */   public void transaction()
/*     */   {
/*  21 */     boolean logflag = false;
/*     */     try {
/*  23 */       if (isEmpty(getStoreId())) {
/*  24 */         throw new ToolkitException("-32");
/*     */       }
/*  26 */       getHiMerchant();
/*     */ 
/*  28 */       getLogger();
/*     */ 
/*  30 */       logflag = true;
/*     */ 
/*  32 */       this.log.info("----- New TENPAY Other-Trx Start -----");
/*  33 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*     */ 
/*  35 */       checkData();
/*  36 */       this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/*  39 */       organizeMessage();
/*  40 */       this.log.info("Organize Message [ ok ].");
/*     */ 
/*  43 */       this.log.info("Send Message......");
/*  44 */       connectTo(HiServer.getTenpayOtherUrl());
/*  45 */       this.log.info("Receive Response [ ok ].");
/*     */ 
/*  48 */       parserResult();
/*  49 */       this.log.info("parsing Message [ ok ].");
/*     */ 
/*  51 */       this.log.info("----- New TENPAY Other-Trx End -----\n");
/*     */     } catch (ToolkitException e) {
/*  53 */       setRetCode(e.getMessage());
/*  54 */       if (logflag) {
/*  55 */         this.log.info("Run Error! Code ==" + getRetCode());
/*  56 */         this.log.info("----- New TENPAY Other-Trx End -----\n");
/*     */       }
/*     */     } catch (Exception e) {
/*  59 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkData() throws ToolkitException, Exception
/*     */   {
/*  65 */     int type = Integer.parseInt(getType());
/*     */ 
/*  67 */     if ((isEmpty(getType())) || (type < 3) || (type > 26)) {
/*  68 */       this.log.error("<Toolkit MSG> Input Parameter [TrxType] is wrong.");
/*  69 */       throw new ToolkitException("-45");
/*     */     }
/*  71 */     if (type == 26) {
/*  72 */       this.log.info("[P]TrxType      = RefundQuery");
/*     */     }
/*     */     else {
/*  75 */       String[] trxType = { "Capture", "CaptureRe", "Refund", "RefundRe", "Query", "AuthRe", "APSE", "VIRTUAL", "POST", "EMVSIGN", "CARD_PAY", "CARD_SALE", "CARD_AUTH", "CARD_PRE_AUTH", "CARD_AUTH_REV", "CARD_REFUND" };
/*  76 */       this.log.info("[P]TrxType      = " + trxType[(Integer.parseInt(getType()) - 3)]);
/*     */     }
/*     */ 
/*  79 */     if (isEmpty(getOrderNo())) {
/*  80 */       this.log.error("<Toolkit MSG> Input Parameter [ORDERNO] is null or empty.");
/*  81 */       throw new ToolkitException("-31");
/*     */     }
/*  83 */     this.log.info("[P]OrderNo      = " + getOrderNo());
/*     */ 
/*  86 */     if ((getType().equals("5")) && (isEmpty(getAmount()))) {
/*  87 */       this.log.error("<Toolkit MSG> Input Parameter [AMOUNT] is null or empty.");
/*  88 */       throw new ToolkitException("-35");
/*     */     }
/*  90 */     this.log.info("[P]Amount       = " + getAmount());
/*     */ 
/*  93 */     if ((getType().equals("5")) && (isEmpty(getCurrency()))) {
/*  94 */       if (isEmpty(this.hiMerchant.getCurrency())) {
/*  95 */         this.log.error("<Toolkit MSG> Input Parameter [CURRENCY] is null or empty.");
/*  96 */         throw new ToolkitException("-34");
/*     */       }
/*  98 */       setCurrency(this.hiMerchant.getCurrency());
/*  99 */       this.log.info("[C]Currency     = " + getCurrency());
/*     */     }
/*     */     else {
/* 102 */       this.log.info("[P]Currency     = " + getCurrency());
/*     */     }
/*     */ 
/* 105 */     if ((getType().equals("5")) && (!"NTD".equals(getCurrency()))) {
/* 106 */       this.log.error("<Toolkit MSG> Input Parameter [CURRENCY] is null or empty.");
/* 107 */       throw new ToolkitException("-34");
/*     */     }
/*     */ 
/* 110 */     setCurrency("TWD");
/*     */   }
/*     */ 
/*     */   private void organizeMessage()
/*     */     throws ToolkitException, Exception
/*     */   {
/* 117 */     String message = "";
/* 118 */     message = "T01=" + getType() + "&" + "T02=" + getOrderNo() + "&" + "T03=" + getStoreId() + "&" + "T06=" + getAmount() + "&" + "T05=" + getCurrency();
/*     */ 
/* 123 */     if (isEmpty(message)) {
/* 124 */       this.log.error("<Toolkit MSG> No Request Message.");
/* 125 */       throw new ToolkitException("-3");
/*     */     }
/* 127 */     setRequestMessage(message);
/*     */   }
/*     */ 
/*     */   private void parserResult() {
/* 131 */     System.out.println(getResponseMessage());
/* 132 */     setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/* 133 */     setCurrency(parsingKeyword(getResponseMessage(), "T05"));
/* 134 */     setOrderDesc(parsingKeyword(getResponseMessage(), "T04"));
/* 135 */     setOrderStatus(parsingKeyword(getResponseMessage(), "R05"));
/* 136 */     setRefund_virtual_account(parsingKeyword(getResponseMessage(), "R41"));
/* 137 */     this.log.info("@RetCode        = " + getRetCode());
/* 138 */     this.log.info("@OrderStatus    = " + getOrderStatus());
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.TenpayOther
 * JD-Core Version:    0.6.0
 */