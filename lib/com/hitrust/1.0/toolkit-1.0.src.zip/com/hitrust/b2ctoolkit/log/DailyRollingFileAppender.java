/*     */ package com.hitrust.b2ctoolkit.log;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import org.apache.log4j.FileAppender;
/*     */ import org.apache.log4j.Layout;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ import org.apache.log4j.spi.ErrorHandler;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ public class DailyRollingFileAppender extends FileAppender
/*     */ {
/*     */   static final int TOP_OF_TROUBLE = -1;
/*     */   static final int TOP_OF_MINUTE = 0;
/*     */   static final int TOP_OF_HOUR = 1;
/*     */   static final int HALF_DAY = 2;
/*     */   static final int TOP_OF_DAY = 3;
/*     */   static final int TOP_OF_WEEK = 4;
/*     */   static final int TOP_OF_MONTH = 5;
/*     */   private String filename;
/*  41 */   private String datePattern = "'.'yyyy-MM-dd";
/*     */   private String scheduledFilename;
/*  47 */   private long nextCheck = System.currentTimeMillis() - 1L;
/*     */ 
/*  49 */   Date now = new Date();
/*     */   SimpleDateFormat sdf;
/*  53 */   RollingCalendar rc = new RollingCalendar();
/*     */ 
/*  55 */   int checkPeriod = -1;
/*     */ 
/*  58 */   static final TimeZone gmtTimeZone = TimeZone.getTimeZone("GMT");
/*     */ 
/*     */   public DailyRollingFileAppender()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DailyRollingFileAppender(Layout layout, String filename, String datePattern)
/*     */     throws IOException
/*     */   {
/*  76 */     super(layout, filename + new SimpleDateFormat(datePattern).format(new Date()), true);
/*  77 */     this.filename = filename;
/*  78 */     this.datePattern = datePattern;
/*  79 */     activateOptions();
/*     */   }
/*     */ 
/*     */   public void setDatePattern(String pattern)
/*     */   {
/*  88 */     this.datePattern = pattern;
/*     */   }
/*     */ 
/*     */   public String getDatePattern()
/*     */   {
/*  93 */     return this.datePattern;
/*     */   }
/*     */ 
/*     */   public void activateOptions() {
/*  97 */     super.activateOptions();
/*     */     File file;
/*  98 */     if ((this.datePattern != null) && (this.fileName != null)) {
/*  99 */       this.now.setTime(System.currentTimeMillis());
/* 100 */       this.sdf = new SimpleDateFormat(this.datePattern);
/* 101 */       int type = computeCheckPeriod();
/* 102 */       printPeriodicity(type);
/* 103 */       this.rc.setType(type);
/* 104 */       this.scheduledFilename = (this.fileName + this.sdf.format(new Date()));
/*     */ 
/* 106 */       file = new File(this.scheduledFilename);
/*     */     }
/*     */     else {
/* 109 */       LogLog.error("Either File or DatePattern options are not set for appender [" + this.name + "].");
/*     */     }
/*     */   }
/*     */ 
/*     */   void printPeriodicity(int type)
/*     */   {
/* 117 */     switch (type) {
/*     */     case 0:
/* 119 */       LogLog.debug("Appender [" + this.name + "] to be rolled every minute.");
/*     */ 
/* 121 */       break;
/*     */     case 1:
/* 123 */       LogLog.debug("Appender [" + this.name + "] to be rolled on top of every hour.");
/*     */ 
/* 127 */       break;
/*     */     case 2:
/* 129 */       LogLog.debug("Appender [" + this.name + "] to be rolled at midday and midnight.");
/*     */ 
/* 133 */       break;
/*     */     case 3:
/* 135 */       LogLog.debug("Appender [" + this.name + "] to be rolled at midnight.");
/*     */ 
/* 137 */       break;
/*     */     case 4:
/* 139 */       LogLog.debug("Appender [" + this.name + "] to be rolled at start of week.");
/*     */ 
/* 141 */       break;
/*     */     case 5:
/* 143 */       LogLog.debug("Appender [" + this.name + "] to be rolled at start of every month.");
/*     */ 
/* 147 */       break;
/*     */     default:
/* 149 */       LogLog.warn("Unknown periodicity for appender [" + this.name + "].");
/*     */     }
/*     */   }
/*     */ 
/*     */   int computeCheckPeriod()
/*     */   {
/* 163 */     RollingCalendar rollingCalendar = new RollingCalendar(gmtTimeZone, Locale.ENGLISH);
/*     */ 
/* 166 */     Date epoch = new Date(0L);
/* 167 */     if (this.datePattern != null) {
/* 168 */       for (int i = 0; i <= 5; i++) {
/* 169 */         SimpleDateFormat simpleDateFormat = new SimpleDateFormat(this.datePattern);
/*     */ 
/* 171 */         simpleDateFormat.setTimeZone(gmtTimeZone);
/*     */ 
/* 173 */         String r0 = simpleDateFormat.format(epoch);
/* 174 */         rollingCalendar.setType(i);
/* 175 */         Date next = new Date(rollingCalendar.getNextCheckMillis(epoch));
/* 176 */         String r1 = simpleDateFormat.format(next);
/*     */ 
/* 178 */         if ((r0 != null) && (r1 != null) && (!r0.equals(r1))) {
/* 179 */           return i;
/*     */         }
/*     */       }
/*     */     }
/* 183 */     return -1;
/*     */   }
/*     */ 
/*     */   void rollOver()
/*     */     throws IOException
/*     */   {
/* 192 */     if (this.datePattern == null) {
/* 193 */       this.errorHandler.error("Missing DatePattern option in rollOver().");
/* 194 */       return;
/*     */     }
/*     */ 
/* 197 */     String datedFilename = this.filename + this.sdf.format(this.now);
/*     */ 
/* 201 */     if (this.scheduledFilename.equals(datedFilename)) {
/* 202 */       return;
/*     */     }
/*     */ 
/* 206 */     closeFile();
/*     */     try
/*     */     {
/* 211 */       setFile(datedFilename, false, this.bufferedIO, this.bufferSize);
/*     */     } catch (IOException e) {
/* 213 */       this.errorHandler.error("setFile(" + this.fileName + ", false) call failed.");
/*     */     }
/* 215 */     this.scheduledFilename = datedFilename;
/*     */   }
/*     */ 
/*     */   protected void subAppend(LoggingEvent event)
/*     */   {
/* 227 */     long n = System.currentTimeMillis();
/* 228 */     if (n >= this.nextCheck) {
/* 229 */       this.now.setTime(n);
/* 230 */       this.nextCheck = this.rc.getNextCheckMillis(this.now);
/*     */       try {
/* 232 */         rollOver();
/*     */       } catch (IOException ioe) {
/* 234 */         LogLog.error("rollOver() failed.", ioe);
/*     */       }
/*     */     }
/* 237 */     super.subAppend(event);
/*     */   }
/*     */ 
/*     */   public synchronized void setFile(String fileName, boolean append, boolean bufferedIO, int bufferSize)
/*     */     throws IOException
/*     */   {
/* 248 */     if (this.filename == null)
/* 249 */       this.filename = fileName;
/* 250 */     super.setFile(fileName, true, bufferedIO, bufferSize);
/*     */   }
/*     */ 
/*     */   public void setFile(String file)
/*     */   {
/* 257 */     if (this.filename == null)
/* 258 */       this.filename = file;
/* 259 */     if (this.datePattern != null)
/* 260 */       file = file + new SimpleDateFormat(this.datePattern).format(new Date());
/* 261 */     super.setFile(file);
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.log.DailyRollingFileAppender
 * JD-Core Version:    0.6.0
 */