/*    */ package com.hitrust.b2ctoolkit.b2cpay;
/*    */ 
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.ArrayList;
/*    */ import org.bouncycastle.util.encoders.Hex;
/*    */ 
/*    */ public class B2CEasyPayUtility
/*    */ {
/*    */   protected static void parseOrderLinesTo(String orderline, ArrayList epRTN)
/*    */     throws UnsupportedEncodingException, ParseException
/*    */   {
/* 13 */     SimpleDateFormat sdfForReceive = new SimpleDateFormat("yyyyMMddHHmmss");
/*    */ 
/* 17 */     String[] orders = orderline.split(";");
/*    */ 
/* 19 */     if ((orders == null) || (orders.length == 0))
/*    */     {
/* 21 */       return;
/*    */     }
/*    */ 
/* 24 */     for (int i = 0; i < orders.length; i++) {
/* 25 */       if ((orders[i] == null) || (orders[i].trim().length() == 0))
/*    */       {
/*    */         continue;
/*    */       }
/*    */ 
/* 30 */       String[] fields = orders[i].trim().split(",");
/*    */ 
/* 32 */       if ((fields == null) || (fields.length != 15)) {
/* 33 */         throw new IllegalArgumentException("field size incorrect: " + fields.length);
/*    */       }
/*    */ 
/* 37 */       B2CEasyPayDetail ep = new B2CEasyPayDetail();
/*    */ 
/* 43 */       ep.storeId = fields[0];
/* 44 */       ep.orderName = new String(Hex.decode(fields[1]), B2CBase.getToEncoding());
/*    */ 
/* 46 */       ep.startDate = sdfForReceive.parse(fields[2]);
/* 47 */       ep.endDate = sdfForReceive.parse(fields[3]);
/* 48 */       ep.createDate = sdfForReceive.parse(fields[4]);
/* 49 */       ep.amount = Integer.parseInt(fields[5]);
/* 50 */       ep.mail = fields[6];
/* 51 */       ep.orderId = fields[7];
/*    */ 
/* 53 */       ep.status = Integer.parseInt(fields[9]);
/* 54 */       ep.token = fields[10];
/* 55 */       ep.payDate = ("null".equals(fields[11]) ? null : sdfForReceive.parse(fields[11]));
/*    */ 
/* 59 */       if ((fields[12] == null) || (fields[12].length() <= 0) || ("null".equals(fields[12])))
/* 60 */         ep.installm_plan = null;
/*    */       else {
/* 62 */         ep.installm_plan = new String(Hex.decode(fields[12]), B2CBase.getToEncoding());
/*    */       }
/* 64 */       ep.notice_mail = fields[13];
/* 65 */       ep.paytype = fields[14];
/*    */ 
/* 67 */       epRTN.add(ep);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.B2CEasyPayUtility
 * JD-Core Version:    0.6.0
 */