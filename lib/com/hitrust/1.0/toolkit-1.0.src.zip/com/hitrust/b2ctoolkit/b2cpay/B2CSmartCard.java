/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.util.HiMerchant;
/*     */ import com.hitrust.b2ctoolkit.util.HiServer;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class B2CSmartCard extends B2CPay
/*     */ {
/*     */   public void transaction()
/*     */   {
/*  21 */     boolean logflag = false;
/*     */     try {
/*  23 */       if (isEmpty(getStoreId())) {
/*  24 */         throw new ToolkitException("-32");
/*     */       }
/*  26 */       getHiMerchant();
/*  27 */       getLogger();
/*     */ 
/*  29 */       logflag = true;
/*     */ 
/*  31 */       this.log.info("----- New SmartCard Start  -----");
/*  32 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*  33 */       this.log.info("[C]StoreID      = " + getStoreId());
/*     */ 
/*  35 */       this.log.info("Trx Type = " + getType());
/*     */ 
/*  38 */       checkData();
/*  39 */       this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/*  42 */       organizeMessage();
/*  43 */       this.log.info("Organize Message [ ok ].");
/*     */ 
/*  46 */       this.log.info("Send Message......");
/*  47 */       connectTo(HiServer.getAuthUrl());
/*  48 */       this.log.info("Receive Response [ ok ].");
/*     */ 
/*  51 */       parserResult();
/*  52 */       this.log.info("parsing Message [ ok ].");
/*     */ 
/*  54 */       this.log.info("----- New SmartCard End  -----\n");
/*     */     } catch (ToolkitException e) {
/*  56 */       setRetCode(e.getMessage());
/*  57 */       if (logflag) {
/*  58 */         this.log.info("Run Error! Code ==" + getRetCode());
/*  59 */         this.log.info("----- New SmartCard End  -----\n");
/*     */       }
/*     */     } catch (Exception e) {
/*  62 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkData() throws ToolkitException, Exception
/*     */   {
/*  68 */     if (isEmpty(getType())) {
/*  69 */       this.log.error("<Toolkit MSG> Input Parameter [TrxType] is wrong.");
/*  70 */       throw new ToolkitException("-45");
/*     */     }
/*     */ 
/*  73 */     if (isEmpty(getOrderNo())) {
/*  74 */       this.log.error("<Toolkit MSG> Input Parameter [ORDERNO] is null or empty.");
/*  75 */       throw new ToolkitException("-31");
/*     */     }
/*  77 */     this.log.info("[P]OrderNo      = " + getOrderNo());
/*     */ 
/*  80 */     if (isEmpty(getOrderDesc())) {
/*  81 */       if (isEmpty(this.hiMerchant.getOrderDesc())) {
/*  82 */         this.log.error("<Toolkit MSG> Input Parameter [ORDERDESC] is null or empty.");
/*  83 */         throw new ToolkitException("-33");
/*     */       }
/*  85 */       setOrderDesc(this.hiMerchant.getOrderDesc());
/*  86 */       this.log.info("[C]OrderDesc    = " + getOrderDesc());
/*     */     }
/*     */     else {
/*  89 */       this.log.info("[P]OrderDesc    = " + getOrderDesc());
/*     */     }
/*     */ 
/*  92 */     if (isEmpty(getCurrency())) {
/*  93 */       if (isEmpty(this.hiMerchant.getCurrency())) {
/*  94 */         this.log.error("<Toolkit MSG> Input Parameter [CURRENCY] is null or empty.");
/*  95 */         throw new ToolkitException("-34");
/*     */       }
/*  97 */       setCurrency(this.hiMerchant.getCurrency());
/*  98 */       this.log.info("[C]Currency     = " + getCurrency());
/*     */     }
/*     */     else {
/* 101 */       this.log.info("[P]Currency     = " + getCurrency());
/*     */     }
/*     */ 
/* 104 */     if (isEmpty(getAmount())) {
/* 105 */       this.log.error("<Toolkit MSG> Input Parameter [AMOUNT] is null or empty.");
/* 106 */       throw new ToolkitException("-35");
/*     */     }
/* 108 */     this.log.info("[P]Amount       = " + getAmount());
/*     */ 
/* 111 */     if (isEmpty(getReturnURL())) {
/* 112 */       if (isEmpty(this.hiMerchant.getReturnURL())) {
/* 113 */         this.log.error("<Toolkit MSG> Input Parameter [RETURNURL] is null or empty.");
/* 114 */         throw new ToolkitException("-37");
/*     */       }
/* 116 */       setReturnURL(this.hiMerchant.getReturnURL());
/* 117 */       this.log.info("[C]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */     else {
/* 120 */       this.log.info("[P]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */ 
/* 123 */     if (isEmpty(getDepositFlag())) {
/* 124 */       if (isEmpty(this.hiMerchant.getDeposit())) {
/* 125 */         this.log.error("<Toolkit MSG> Input Parameter [DEPOSIT] is null or empty.");
/* 126 */         throw new ToolkitException("-38");
/*     */       }
/* 128 */       setDepositFlag(this.hiMerchant.getDeposit());
/* 129 */       this.log.info("[C]Deposit      = " + getDepositFlag());
/*     */     }
/*     */     else {
/* 132 */       this.log.info("[P]Deposit      = " + getDepositFlag());
/*     */     }
/*     */ 
/* 135 */     if (isEmpty(getQueryFlag())) {
/* 136 */       if (isEmpty(this.hiMerchant.getQueryFlag())) {
/* 137 */         this.log.error("<Toolkit MSG> Input Parameter [QUERYFLAG] is null or empty.");
/* 138 */         throw new ToolkitException("-39");
/*     */       }
/* 140 */       setQueryFlag(this.hiMerchant.getQueryFlag());
/* 141 */       this.log.info("[C]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */     else {
/* 144 */       this.log.info("[P]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */ 
/* 147 */     if (isEmpty(getUpdateURL())) {
/* 148 */       if (isEmpty(this.hiMerchant.getUpdateURL())) {
/* 149 */         this.log.error("<Toolkit MSG> Input Parameter [UPDATEURL] is null or empty.");
/* 150 */         throw new ToolkitException("-40");
/*     */       }
/* 152 */       setUpdateURL(this.hiMerchant.getUpdateURL());
/* 153 */       this.log.info("[C]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */     else {
/* 156 */       this.log.info("[P]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */ 
/* 171 */     if (getTicketNo() == null) setTicketNo("");
/* 172 */     if (getPan() == null) setPan("");
/* 173 */     if (getExpiry() == null) setExpiry("");
/* 174 */     if (getE01() == null) setE01("");
/* 175 */     if (getE02() == null) setE02("");
/* 176 */     if (getE03() == null) setE03("");
/* 177 */     if (getE04() == null) setE04("");
/* 178 */     if (getE05() == null) setE05("");
/* 179 */     if (getE11() == null) setE11("");
/* 180 */     if (getE12() == null) setE12("");
/* 181 */     if (getE13() == null) setE13("");
/* 182 */     if (getE14() == null) setE14("");
/*     */ 
/* 184 */     this.log.info("[P]TicketNo     = " + getTicketNo());
/* 185 */     this.log.info("[P]PAN          = " + getPan());
/* 186 */     this.log.info("[P]Expiry       = " + getExpiry());
/* 187 */     this.log.info("[P]E01          = " + getE01());
/* 188 */     this.log.info("[P]E02          = " + getE02());
/* 189 */     this.log.info("[P]E03          = " + getE03());
/* 190 */     this.log.info("[P]E04          = " + getE04());
/* 191 */     this.log.info("[P]E05          = " + getE05());
/*     */ 
/* 193 */     this.log.info("[P]E11          = " + getE11());
/* 194 */     this.log.info("[P]E12          = " + getE12());
/* 195 */     this.log.info("[P]E13          = " + getE13());
/* 196 */     this.log.info("[P]E14          = " + getE14());
/*     */   }
/*     */ 
/*     */   private void organizeMessage() throws ToolkitException, Exception
/*     */   {
/* 201 */     String message = "";
/* 202 */     message = "T01=" + getType() + "&" + "T02=" + getOrderNo() + "&" + "T03=" + getStoreId() + "&" + "T04=" + getOrderDesc() + "&" + "T05=" + getCurrency() + "&" + "T06=" + getAmount() + "&" + "T08=" + getReturnURL() + "&" + "T09=" + getDepositFlag() + "&" + "T10=" + getQueryFlag() + "&" + "T11=" + getExtendField() + "&" + "T12=" + getUpdateURL() + "&" + "T13=" + getPan() + "&" + "T14=" + getExpiry() + "&" + "T15=" + getMerUpdateURL() + "&" + "O01=" + getTicketNo() + "&" + "E01=" + getE01() + "&" + "E02=" + getE02() + "&" + "E03=" + getE03() + "&" + "E04=" + getE04() + "&" + "E05=" + getE05() + "&" + "E11=" + getE11() + "&" + "E12=" + getE12() + "&" + "E13=" + getE13() + "&" + "E14=" + getE14();
/*     */ 
/* 227 */     if (isEmpty(message)) {
/* 228 */       this.log.error("<Toolkit MSG> No Request Message.");
/* 229 */       throw new ToolkitException("-3");
/*     */     }
/* 231 */     setRequestMessage(message);
/*     */   }
/*     */ 
/*     */   private void parserResult() {
/* 235 */     setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/* 236 */     setAuthCode(parsingKeyword(getResponseMessage(), "R03"));
/* 237 */     setAuthRRN(parsingKeyword(getResponseMessage(), "R04"));
/* 238 */     setEci(parsingKeyword(getResponseMessage(), "R25"));
/* 239 */     setToken(parsingKeyword(getResponseMessage(), "R24"));
/* 240 */     this.log.info("@RC             = " + getRetCode());
/* 241 */     this.log.info("@Token          = " + getToken());
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.B2CSmartCard
 * JD-Core Version:    0.6.0
 */