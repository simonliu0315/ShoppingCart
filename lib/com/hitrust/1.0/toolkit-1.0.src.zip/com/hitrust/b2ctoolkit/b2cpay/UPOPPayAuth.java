/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.util.HiMerchant;
/*     */ import com.hitrust.b2ctoolkit.util.HiServer;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import java.net.URLDecoder;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class UPOPPayAuth extends B2CPay
/*     */ {
/*     */   public void transaction()
/*     */   {
/*  21 */     boolean logflag = false;
/*     */     try {
/*  23 */       if (isEmpty(getStoreId())) {
/*  24 */         throw new ToolkitException("-32");
/*     */       }
/*  26 */       getHiMerchant();
/*  27 */       getLogger();
/*     */ 
/*  29 */       logflag = true;
/*     */ 
/*  31 */       this.log.info("----- New UPOP Auth Start  -----");
/*  32 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*  33 */       this.log.info("[C]StoreID      = " + getStoreId());
/*     */ 
/*  36 */       setType("1");
/*     */ 
/*  39 */       checkData();
/*  40 */       this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/*  43 */       organizeMessage();
/*  44 */       this.log.info("Organize Message [ ok ].");
/*     */ 
/*  47 */       this.log.info("Send Message......");
/*  48 */       connectTo(HiServer.getUPOPAuthUrl());
/*  49 */       this.log.info("Receive Response [ ok ].");
/*     */ 
/*  52 */       parserResult();
/*  53 */       this.log.info("parsing Message [ ok ].");
/*     */ 
/*  55 */       this.log.info("----- New UPOP Auth End  -----\n");
/*     */     } catch (ToolkitException e) {
/*  57 */       setRetCode(e.getMessage());
/*  58 */       if (logflag) {
/*  59 */         this.log.info("Run Error! Code ==" + getRetCode());
/*  60 */         this.log.info("----- New UPOP Auth End  -----\n");
/*     */       }
/*     */     } catch (Exception e) {
/*  63 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkData() throws ToolkitException, Exception
/*     */   {
/*  69 */     if (isEmpty(getType())) {
/*  70 */       this.log.error("<Toolkit MSG> Input Parameter [TrxType] is wrong.");
/*  71 */       throw new ToolkitException("-45");
/*     */     }
/*     */ 
/*  74 */     if (isEmpty(getOrderNo())) {
/*  75 */       this.log.error("<Toolkit MSG> Input Parameter [ORDERNO] is null or empty.");
/*  76 */       throw new ToolkitException("-31");
/*     */     }
/*  78 */     this.log.info("[P]OrderNo      = " + getOrderNo());
/*     */ 
/*  81 */     if (isEmpty(getCurrency())) {
/*  82 */       if (isEmpty(this.hiMerchant.getCurrency())) {
/*  83 */         this.log.error("<Toolkit MSG> Input Parameter [CURRENCY] is null or empty.");
/*  84 */         throw new ToolkitException("-34");
/*     */       }
/*  86 */       setCurrency(this.hiMerchant.getCurrency());
/*  87 */       this.log.info("[C]Currency     = " + getCurrency());
/*     */     }
/*     */     else {
/*  90 */       this.log.info("[P]Currency     = " + getCurrency());
/*     */     }
/*     */ 
/*  93 */     if (isEmpty(getAmount())) {
/*  94 */       this.log.error("<Toolkit MSG> Input Parameter [AMOUNT] is null or empty.");
/*  95 */       throw new ToolkitException("-35");
/*     */     }
/*  97 */     this.log.info("[P]Amount       = " + getAmount());
/*     */ 
/* 100 */     if (isEmpty(getReturnURL())) {
/* 101 */       if (isEmpty(this.hiMerchant.getReturnURL())) {
/* 102 */         this.log.error("<Toolkit MSG> Input Parameter [RETURNURL] is null or empty.");
/* 103 */         throw new ToolkitException("-37");
/*     */       }
/* 105 */       setReturnURL(this.hiMerchant.getReturnURL());
/* 106 */       this.log.info("[C]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */     else {
/* 109 */       this.log.info("[P]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */ 
/* 112 */     if (isEmpty(getDepositFlag())) {
/* 113 */       if (isEmpty(this.hiMerchant.getDeposit())) {
/* 114 */         this.log.error("<Toolkit MSG> Input Parameter [DEPOSIT] is null or empty.");
/* 115 */         throw new ToolkitException("-38");
/*     */       }
/* 117 */       setDepositFlag(this.hiMerchant.getDeposit());
/* 118 */       this.log.info("[C]Deposit      = " + getDepositFlag());
/*     */     }
/*     */     else {
/* 121 */       this.log.info("[P]Deposit      = " + getDepositFlag());
/*     */     }
/*     */ 
/* 124 */     if (isEmpty(getUpdateURL())) {
/* 125 */       if (isEmpty(this.hiMerchant.getUpdateURL())) {
/* 126 */         this.log.error("<Toolkit MSG> Input Parameter [UPDATEURL] is null or empty.");
/* 127 */         throw new ToolkitException("-40");
/*     */       }
/* 129 */       setUpdateURL(this.hiMerchant.getUpdateURL());
/* 130 */       this.log.info("[C]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */     else {
/* 133 */       this.log.info("[P]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void organizeMessage() throws ToolkitException, Exception {
/* 138 */     String message = "";
/* 139 */     message = "T01=" + getType() + "&" + "T02=" + getOrderNo() + "&" + "T03=" + getStoreId() + "&" + "T05=" + getCurrency() + "&" + "T06=" + getAmount() + "&" + "T08=" + getReturnURL() + "&" + "T09=" + getDepositFlag() + "&" + "T11=" + getExtendField() + "&" + "T12=" + getUpdateURL() + "&" + "T15=" + getMerUpdateURL();
/*     */ 
/* 151 */     if (isEmpty(message)) {
/* 152 */       this.log.error("<Toolkit MSG> No Request Message.");
/* 153 */       throw new ToolkitException("-3");
/*     */     }
/* 155 */     setRequestMessage(message);
/*     */   }
/*     */ 
/*     */   private void parserResult() {
/* 159 */     setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/* 160 */     setToken(parsingKeyword(getResponseMessage(), "R24"));
/* 161 */     setHTML(URLDecoder.decode(parsingKeyword(getResponseMessage(), "R24")));
/* 162 */     this.log.info("@RC             = " + getRetCode());
/* 163 */     this.log.info("@Token          = " + getToken());
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.UPOPPayAuth
 * JD-Core Version:    0.6.0
 */