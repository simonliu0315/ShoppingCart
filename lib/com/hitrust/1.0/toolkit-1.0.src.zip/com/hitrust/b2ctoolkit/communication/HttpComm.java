/*    */ package com.hitrust.b2ctoolkit.communication;
/*    */ 
/*    */ import com.hitrust.b2ctoolkit.util.HiServer;
/*    */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.httpclient.HostConfiguration;
/*    */ import org.apache.commons.httpclient.HttpClient;
/*    */ import org.apache.commons.httpclient.HttpException;
/*    */ import org.apache.commons.httpclient.HttpState;
/*    */ import org.apache.commons.httpclient.NameValuePair;
/*    */ import org.apache.commons.httpclient.methods.PostMethod;
/*    */ import org.apache.commons.httpclient.protocol.Protocol;
/*    */ 
/*    */ public class HttpComm
/*    */ {
/* 32 */   static int connTimeoutMS = 5000;
/* 33 */   static int readTimeoutMS = 65000;
/*    */ 
/*    */   public static String connect(String host, int port, String app, String key, String cipher, String mac)
/*    */     throws Exception
/*    */   {
/* 50 */     HttpClient client = new HttpClient();
/*    */     try
/*    */     {
/* 54 */       client.setConnectionTimeout(connTimeoutMS);
/* 55 */       client.setTimeout(readTimeoutMS);
/*    */ 
/* 57 */       if ((port == 80) || (port == 9080)) {
/* 58 */         client.getHostConfiguration().setHost(host, port);
/* 59 */       } else if ((port == 443) || (port == 9443))
/*    */       {
/* 61 */         Protocol myhttps = new Protocol("https", new EasySSLProtocolSocketFactory(), port);
/* 62 */         client.getHostConfiguration().setHost(host, port, myhttps);
/*    */       } else {
/* 64 */         client.getHostConfiguration().setHost(host, port);
/*    */       }
/*    */     } catch (Exception ex) {
/* 67 */       throw new ToolkitException("-19");
/*    */     }
/*    */ 
/* 70 */     client.getState().setCookiePolicy(0);
/*    */ 
/* 72 */     PostMethod method = new PostMethod(app);
/*    */     try {
/* 74 */       NameValuePair[] data = new NameValuePair[3];
/* 75 */       data[0] = new NameValuePair("KEY", key);
/* 76 */       data[1] = new NameValuePair("CIPHER", cipher);
/* 77 */       data[2] = new NameValuePair("MAC", mac);
/*    */ 
/* 79 */       method.setRequestBody(data);
/*    */ 
/* 81 */       int statusCode = client.executeMethod(method);
/* 82 */       if ((statusCode != 100) && (statusCode != 200)) {
/* 83 */         throw new ToolkitException("-11");
/*    */       }
/* 85 */       String res = new String(method.getResponseBody(), method.getResponseCharSet());
/* 86 */       String str1 = res;
/*    */       return str1;
/*    */     }
/*    */     catch (HttpException ex)
/*    */     {
/*    */       throw new ToolkitException("-15");
/*    */     }
/*    */     catch (IOException e)
/*    */     {
/*    */       throw new ToolkitException("-4");
/*    */     } catch (IllegalArgumentException e) {
/* 94 */       throw new ToolkitException("-19");
/*    */     } finally {
/* 96 */       method.releaseConnection(); } throw localObject;
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 37 */       connTimeoutMS = Integer.parseInt(HiServer.getConnectionTimeout());
/*    */     } catch (Exception e) {
/* 39 */       connTimeoutMS = 5000;
/*    */     }
/*    */     try {
/* 42 */       readTimeoutMS = Integer.parseInt(HiServer.getReadTimeout());
/*    */     } catch (Exception e) {
/* 44 */       readTimeoutMS = 65000;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.communication.HttpComm
 * JD-Core Version:    0.6.0
 */