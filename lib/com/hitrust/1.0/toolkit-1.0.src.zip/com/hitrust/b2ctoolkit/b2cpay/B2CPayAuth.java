/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.util.HiMerchant;
/*     */ import com.hitrust.b2ctoolkit.util.HiServer;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class B2CPayAuth extends B2CPay
/*     */ {
/*     */   public void transaction()
/*     */   {
/*  25 */     boolean logflag = false;
/*     */     try {
/*  27 */       if (isEmpty(getStoreId())) {
/*  28 */         throw new ToolkitException("-32");
/*     */       }
/*  30 */       getHiMerchant();
/*  31 */       getLogger();
/*     */ 
/*  33 */       logflag = true;
/*  34 */       this.log.info("----- New Auth Start  -----");
/*  35 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*  36 */       this.log.info("[C]StoreID      = " + getStoreId());
/*     */ 
/*  39 */       setType("1");
/*     */ 
/*  42 */       checkData();
/*  43 */       this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/*  46 */       organizeMessage();
/*  47 */       this.log.info("Organize Message [ ok ].");
/*     */ 
/*  50 */       this.log.info("Send Message......");
/*  51 */       connectTo(HiServer.getAuthUrl());
/*  52 */       this.log.info("Receive Response [ ok ].");
/*     */ 
/*  55 */       parserResult();
/*  56 */       this.log.info("parsing Message [ ok ].");
/*     */ 
/*  58 */       this.log.info("----- New Auth End  -----\n");
/*     */     } catch (ToolkitException e) {
/*  60 */       setRetCode(e.getMessage());
/*  61 */       if (logflag) {
/*  62 */         this.log.info("Run Error! Code ==" + getRetCode());
/*  63 */         this.log.info("----- New Auth End  -----\n");
/*     */       }
/*     */     } catch (Exception e) {
/*  66 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkData() throws ToolkitException, Exception
/*     */   {
/*  72 */     if (isEmpty(getType())) {
/*  73 */       this.log.error("<Toolkit MSG> Input Parameter [TrxType] is wrong.");
/*  74 */       throw new ToolkitException("-45");
/*     */     }
/*     */ 
/*  77 */     if (isEmpty(getOrderNo())) {
/*  78 */       this.log.error("<Toolkit MSG> Input Parameter [ORDERNO] is null or empty.");
/*  79 */       throw new ToolkitException("-31");
/*     */     }
/*  81 */     this.log.info("[P]OrderNo      = " + getOrderNo());
/*     */ 
/*  84 */     if (isEmpty(getOrderDesc())) {
/*  85 */       if (isEmpty(this.hiMerchant.getOrderDesc())) {
/*  86 */         this.log.error("<Toolkit MSG> Input Parameter [ORDERDESC] is null or empty.");
/*  87 */         throw new ToolkitException("-33");
/*     */       }
/*  89 */       setOrderDesc(this.hiMerchant.getOrderDesc());
/*  90 */       this.log.info("[C]OrderDesc    = " + getOrderDesc());
/*     */     }
/*     */     else {
/*  93 */       this.log.info("[P]OrderDesc    = " + getOrderDesc());
/*     */     }
/*     */ 
/*  96 */     if (isEmpty(getCurrency())) {
/*  97 */       if (isEmpty(this.hiMerchant.getCurrency())) {
/*  98 */         this.log.error("<Toolkit MSG> Input Parameter [CURRENCY] is null or empty.");
/*  99 */         throw new ToolkitException("-34");
/*     */       }
/* 101 */       setCurrency(this.hiMerchant.getCurrency());
/* 102 */       this.log.info("[C]Currency     = " + getCurrency());
/*     */     }
/*     */     else {
/* 105 */       this.log.info("[P]Currency     = " + getCurrency());
/*     */     }
/*     */ 
/* 108 */     if (isEmpty(getAmount())) {
/* 109 */       this.log.error("<Toolkit MSG> Input Parameter [AMOUNT] is null or empty.");
/* 110 */       throw new ToolkitException("-35");
/*     */     }
/* 112 */     this.log.info("[P]Amount       = " + getAmount());
/*     */ 
/* 115 */     if ((!"".equals(getE59())) && (getE59() != null) && ("1".equals(getE59())) && 
/* 116 */       (!"000".equals(getAmount()))) {
/* 117 */       this.log.error("<Toolkit MSG> Input account verify amount error.");
/* 118 */       throw new ToolkitException("-80");
/*     */     }
/*     */ 
/* 122 */     if (isEmpty(getReturnURL())) {
/* 123 */       if (isEmpty(this.hiMerchant.getReturnURL())) {
/* 124 */         this.log.error("<Toolkit MSG> Input Parameter [RETURNURL] is null or empty.");
/* 125 */         throw new ToolkitException("-37");
/*     */       }
/* 127 */       setReturnURL(this.hiMerchant.getReturnURL());
/* 128 */       this.log.info("[C]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */     else {
/* 131 */       this.log.info("[P]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */ 
/* 134 */     if (isEmpty(getDepositFlag())) {
/* 135 */       if (isEmpty(this.hiMerchant.getDeposit())) {
/* 136 */         this.log.error("<Toolkit MSG> Input Parameter [DEPOSIT] is null or empty.");
/* 137 */         throw new ToolkitException("-38");
/*     */       }
/* 139 */       setDepositFlag(this.hiMerchant.getDeposit());
/* 140 */       this.log.info("[C]Deposit      = " + getDepositFlag());
/*     */     }
/*     */     else {
/* 143 */       this.log.info("[P]Deposit      = " + getDepositFlag());
/*     */     }
/*     */ 
/* 146 */     if (isEmpty(getQueryFlag())) {
/* 147 */       if (isEmpty(this.hiMerchant.getQueryFlag())) {
/* 148 */         this.log.error("<Toolkit MSG> Input Parameter [QUERYFLAG] is null or empty.");
/* 149 */         throw new ToolkitException("-39");
/*     */       }
/* 151 */       setQueryFlag(this.hiMerchant.getQueryFlag());
/* 152 */       this.log.info("[C]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */     else {
/* 155 */       this.log.info("[P]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */ 
/* 158 */     if (isEmpty(getUpdateURL())) {
/* 159 */       if (isEmpty(this.hiMerchant.getUpdateURL())) {
/* 160 */         this.log.error("<Toolkit MSG> Input Parameter [UPDATEURL] is null or empty.");
/* 161 */         throw new ToolkitException("-40");
/*     */       }
/* 163 */       setUpdateURL(this.hiMerchant.getUpdateURL());
/* 164 */       this.log.info("[C]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */     else {
/* 167 */       this.log.info("[P]UpdateURL    = " + getUpdateURL());
/*     */     }
/* 169 */     if (getTicketNo() == null) setTicketNo("");
/* 170 */     if (getPan() == null) setPan("");
/* 171 */     if (getExpiry() == null) setExpiry("");
/* 172 */     if (getE01() == null) setE01("");
/* 173 */     if (getE02() == null) setE02("");
/* 174 */     if (getE03() == null) setE03("");
/* 175 */     if (getE04() == null) setE04("");
/* 176 */     if (getE05() == null) setE05("");
/* 177 */     if (getE11() == null) setE11("");
/* 178 */     if (getE12() == null) setE12("");
/* 179 */     if (getE13() == null) setE13("");
/* 180 */     if (getE14() == null) setE14("");
/*     */ 
/* 182 */     if (getE35() == null) setE35("");
/* 183 */     if (getE36() == null) setE36("");
/* 184 */     if (getE37() == null) setE37("");
/* 185 */     if (getE38() == null) setE38("");
/* 186 */     if (getE39() == null) setE39("");
/* 187 */     if (getE40() == null) setE40("");
/* 188 */     if (getE41() == null) setE41("");
/* 189 */     if (getE42() == null) setE42("");
/* 190 */     if (getE52() == null) setE52("");
/* 191 */     if (getE53() == null) setE53("");
/* 192 */     if (getE54() == null) setE54("");
/* 193 */     if (getE56() == null) setE56("");
/* 194 */     if (getE57() == null) setE57("");
/* 195 */     if (getE58() == null) setE58("");
/* 196 */     if (getE59() == null) setE59("");
/*     */ 
/* 198 */     this.log.info("[P]TicketNo     = " + getTicketNo());
/*     */     try
/*     */     {
/* 203 */       if ((getPan().equals("")) || (getPan().length() < 13))
/* 204 */         this.log.info("[P]PAN          = " + getPan());
/*     */       else
/* 206 */         this.log.info("[P]PAN          = " + getPan().substring(0, 6) + "******" + getPan().substring(getPan().length() - 4));
/*     */     }
/*     */     catch (Exception ex) {
/* 209 */       this.log.error(ex.getMessage());
/*     */     }
/*     */ 
/* 213 */     if (getTrxToken() == null) {
/* 214 */       setTrxToken("");
/*     */     }
/*     */ 
/* 217 */     if ((!isEmpty(getE36())) && 
/* 218 */       (getE36().length() > 10)) {
/* 219 */       this.log.error("<Toolkit MSG> Input Parameter [ID] is null or empty or format error.");
/* 220 */       throw new ToolkitException("-60");
/*     */     }
/* 222 */     if ((!isEmpty(getE37())) && 
/* 223 */       (getE37().length() > 15)) {
/* 224 */       this.log.error("<Toolkit MSG> Input Parameter [CELLPHONE] is null or empty or length error.");
/* 225 */       throw new ToolkitException("-61");
/*     */     }
/*     */ 
/* 228 */     if (!isEmpty(getE38())) {
/* 229 */       if (getE38().length() != 4) {
/* 230 */         this.log.error("<Toolkit MSG> Input Parameter [YEAR_OF_BIRTH] is null or empty or length error.");
/* 231 */         throw new ToolkitException("-62");
/* 232 */       }if (getE39().length() == 0) {
/* 233 */         this.log.error("<Toolkit MSG> Input Parameter [MMDD_OF_BIRTH] is null or empty or length error.");
/* 234 */         throw new ToolkitException("-63");
/*     */       }
/*     */     }
/*     */ 
/* 238 */     if (!isEmpty(getE39())) {
/* 239 */       if (getE39().length() != 4) {
/* 240 */         this.log.error("<Toolkit MSG> Input Parameter [MMDD_OF_BIRTH] is null or empty or length error.");
/* 241 */         throw new ToolkitException("-63");
/* 242 */       }if (getE38().length() == 0) {
/* 243 */         this.log.error("<Toolkit MSG> Input Parameter [YEAR_OF_BIRTH] is null or empty or length error.");
/* 244 */         throw new ToolkitException("-62");
/*     */       }
/*     */     }
/* 246 */     if ((!"".equals(getE40())) && (null != getE40()) && 
/* 247 */       (getE40().length() > 15)) {
/* 248 */       this.log.error("<Toolkit MSG> Input Parameter [HomePHONE] is null or empty or length error.");
/* 249 */       throw new ToolkitException("-64");
/*     */     }
/*     */ 
/* 252 */     if ((!"".equals(getE41())) && (null != getE41()) && 
/* 253 */       (getE41().length() > 15)) {
/* 254 */       this.log.error("<Toolkit MSG> Input Parameter [OfficePHONE] is null or empty or length error.");
/* 255 */       throw new ToolkitException("-65");
/*     */     }
/*     */ 
/* 258 */     if ("Y".equalsIgnoreCase(getE42()))
/*     */     {
/* 260 */       if (("".equals(getE36().trim())) && ("".equals(getE37().trim())) && ("".equals(getE38().trim())) && ("".equals(getE39().trim())) && ("".equals(getE40().trim())) && ("".equals(getE41().trim()))) {
/* 261 */         this.log.error("<Toolkit MSG> Input Parameter all is blank for identifying.");
/* 262 */         throw new ToolkitException("-66");
/*     */       }
/* 264 */       if ("1".equals(getDepositFlag())) {
/* 265 */         this.log.error("<Toolkit MSG> Input Parameter only for identifying cannot with depositeflag.");
/* 266 */         throw new ToolkitException("-67");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 274 */     if (!isEmpty(getE52()))
/*     */     {
/* 277 */       if (getE52().matches("[0-9]{8}"))
/*     */       {
/* 280 */         if (!isEmpty(getE53()))
/*     */         {
/* 282 */           if (!getE53().matches("[0-9]{4}"))
/*     */           {
/* 284 */             this.log.error("<Toolkit MSG> Input Parameter [E54] format error.");
/* 285 */             throw new ToolkitException("-74");
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 290 */           this.log.error("<Toolkit MSG> Input Parameter [E53] is null or empty.");
/* 291 */           throw new ToolkitException("-73");
/*     */         }
/*     */ 
/* 295 */         if (!isEmpty(getE54()))
/*     */         {
/* 297 */           if (getE54().length() > 10)
/*     */           {
/* 299 */             this.log.error("<Toolkit MSG> Input Parameter [E54] format error.");
/* 300 */             throw new ToolkitException("-74");
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 305 */           this.log.error("<Toolkit MSG> Input Parameter [E54] is null or empty.");
/* 306 */           throw new ToolkitException("-75");
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 311 */         this.log.error("<Toolkit MSG> Input Parameter [E52] format error.");
/* 312 */         throw new ToolkitException("-72");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 319 */     if ((!isEmpty(getE56())) && (isInteger(getE56()))) {
/* 320 */       if ((isEmpty(getE57())) || (getE57().length() > 6)) {
/* 321 */         this.log.error("<Toolkit MSG> Input Parameter [E57] format error.,E57=" + getE57());
/* 322 */         throw new ToolkitException("-78");
/*     */       }
/* 324 */       if ((isEmpty(getE58())) || ((!"D".equals(getE58())) && (!"W".equals(getE58())) && (!"M".equals(getE58())) && (!"Y".equals(getE58())))) {
/* 325 */         this.log.error("<Toolkit MSG> Input Parameter [E58] format error.,E58=" + getE58());
/* 326 */         throw new ToolkitException("-79");
/*     */       }
/* 328 */     } else if ((!isEmpty(getE56())) && (!isInteger(getE56()))) {
/* 329 */       this.log.error("-77,E56=" + getE56());
/* 330 */       throw new ToolkitException("<Toolkit MSG> Input Parameter [E56] format error.");
/*     */     }
/*     */ 
/* 335 */     this.log.info("[P]E02          = " + getE02());
/* 336 */     this.log.info("[P]E03          = " + getE03());
/* 337 */     this.log.info("[P]E04          = " + getE04());
/* 338 */     this.log.info("[P]E05          = " + getE05());
/*     */ 
/* 340 */     this.log.info("[P]E11          = " + getE11());
/* 341 */     this.log.info("[P]E12          = " + getE12());
/* 342 */     this.log.info("[P]E13          = " + getE13());
/* 343 */     this.log.info("[P]E14          = " + getE14());
/*     */ 
/* 345 */     this.log.info("[P]E15          = " + getName());
/* 346 */     this.log.info("[P]E16          = " + getEmail());
/* 347 */     this.log.info("[P]E17          = " + getE17());
/*     */ 
/* 350 */     this.log.info("[P]E36          = " + getE36());
/* 351 */     this.log.info("[P]E37          = " + getE37());
/* 352 */     this.log.info("[P]E38          = " + getE38());
/* 353 */     this.log.info("[P]E39          = " + getE39());
/* 354 */     this.log.info("[P]E40          = " + getE40());
/* 355 */     this.log.info("[P]E41          = " + getE41());
/* 356 */     this.log.info("[P]E42          = " + getE42());
/* 357 */     this.log.info("[P]E52          = " + getE52());
/* 358 */     this.log.info("[P]E53          = " + getE53());
/* 359 */     this.log.info("[P]E54          = " + getE54());
/* 360 */     this.log.info("[P]E55          = " + getE55());
/* 361 */     this.log.info("[P]E56          = " + getE56());
/* 362 */     this.log.info("[P]E57          = " + getE57());
/* 363 */     this.log.info("[P]E58          = " + getE58());
/*     */   }
/*     */ 
/*     */   private void organizeMessage() throws ToolkitException, Exception {
/* 367 */     String message = "";
/* 368 */     message = "T01=" + getType() + "&" + "T02=" + getOrderNo() + "&" + "T03=" + getStoreId() + "&" + "T04=" + getOrderDesc() + "&" + "T05=" + getCurrency() + "&" + "T06=" + getAmount() + "&" + "T08=" + getReturnURL() + "&" + "T09=" + getDepositFlag() + "&" + "T10=" + getQueryFlag() + "&" + "T11=" + getExtendField() + "&" + "T12=" + getUpdateURL() + "&" + "T13=" + getPan() + "&" + "T14=" + getExpiry() + "&" + "T15=" + getMerUpdateURL() + "&" + "T16=" + getTrxToken() + "&" + "O01=" + getTicketNo() + "&" + "E01=" + getE01() + "&" + "E02=" + getE02() + "&" + "E03=" + getE03() + "&" + "E04=" + getE04() + "&" + "E05=" + getE05() + "&" + "E11=" + getE11() + "&" + "E12=" + getE12() + "&" + "E13=" + getE13() + "&" + "E14=" + getE14() + "&" + "E15=" + getName() + "&" + "E16=" + getEmail() + "&" + "E17=" + getE17() + "&" + "E35=" + getE35() + "&" + "E36=" + getE36() + "&" + "E37=" + getE37() + "&" + "E38=" + getE38() + "&" + "E39=" + getE39() + "&" + "E40=" + getE40() + "&" + "E41=" + getE41() + "&" + "E42=" + getE42() + "&" + "E52=" + getE52() + "&" + "E53=" + getE53() + "&" + "E54=" + getE54() + "&" + "E55=" + getE55() + "&" + "E56=" + getE56() + "&" + "E57=" + getE57() + "&" + "E58=" + getE58() + "&" + "E59=" + getE59();
/*     */ 
/* 414 */     if (isEmpty(message)) {
/* 415 */       this.log.error("<Toolkit MSG> No Request Message.");
/* 416 */       throw new ToolkitException("-3");
/*     */     }
/* 418 */     setRequestMessage(message);
/*     */   }
/*     */ 
/*     */   private void parserResult() {
/* 422 */     setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/* 423 */     setAuthCode(parsingKeyword(getResponseMessage(), "R03"));
/* 424 */     setAuthRRN(parsingKeyword(getResponseMessage(), "R04"));
/* 425 */     setEci(parsingKeyword(getResponseMessage(), "R25"));
/* 426 */     setToken(parsingKeyword(getResponseMessage(), "R24"));
/*     */ 
/* 428 */     setE28(parsingKeyword(getResponseMessage(), "E28"));
/* 429 */     setE29(parsingKeyword(getResponseMessage(), "E29"));
/* 430 */     this.log.info("@RC             = " + getRetCode());
/* 431 */     this.log.info("@Token          = " + getToken());
/*     */   }
/*     */ 
/*     */   private static boolean isInteger(String str) {
/* 435 */     Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
/* 436 */     return pattern.matcher(str).matches();
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.B2CPayAuth
 * JD-Core Version:    0.6.0
 */