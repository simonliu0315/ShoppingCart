/*    */ package com.hitrust.b2ctoolkit.security;
/*    */ 
/*    */ import java.io.FileInputStream;
/*    */ import java.security.KeyFactory;
/*    */ import java.security.PrivateKey;
/*    */ import java.security.PublicKey;
/*    */ import java.security.spec.PKCS8EncodedKeySpec;
/*    */ import java.security.spec.X509EncodedKeySpec;
/*    */ 
/*    */ public class SecurityUtil
/*    */ {
/*    */   public static PublicKey loadX509DERPublicKey(String strPublicKeyFilename)
/*    */     throws Exception
/*    */   {
/* 21 */     FileInputStream fileInput = new FileInputStream(strPublicKeyFilename);
/* 22 */     byte[] bytes = new byte[fileInput.available()];
/* 23 */     int intRead = fileInput.read(bytes);
/*    */ 
/* 25 */     KeyFactory rsaKeyFactory = KeyFactory.getInstance("RSA");
/* 26 */     X509EncodedKeySpec rsaPublicKeySpec = new X509EncodedKeySpec(bytes);
/* 27 */     PublicKey rsaPublicKey = rsaKeyFactory.generatePublic(rsaPublicKeySpec);
/*    */ 
/* 29 */     fileInput.close();
/*    */ 
/* 31 */     return rsaPublicKey;
/*    */   }
/*    */ 
/*    */   public static PrivateKey loadPKCS8DERPrivKey(String strPrivateKeyFilename)
/*    */     throws Exception
/*    */   {
/* 42 */     FileInputStream fileInput = new FileInputStream(strPrivateKeyFilename);
/* 43 */     byte[] bytes = new byte[fileInput.available()];
/* 44 */     int intRead = fileInput.read(bytes);
/*    */ 
/* 46 */     KeyFactory rsaKeyFactory = KeyFactory.getInstance("RSA");
/* 47 */     PKCS8EncodedKeySpec privKeySpec = new PKCS8EncodedKeySpec(bytes);
/* 48 */     PrivateKey rsaPrivateKey = rsaKeyFactory.generatePrivate(privKeySpec);
/*    */ 
/* 50 */     fileInput.close();
/*    */ 
/* 52 */     return rsaPrivateKey;
/*    */   }
/*    */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.security.SecurityUtil
 * JD-Core Version:    0.6.0
 */