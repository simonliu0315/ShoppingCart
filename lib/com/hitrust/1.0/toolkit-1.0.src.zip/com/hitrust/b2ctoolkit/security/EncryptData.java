/*    */ package com.hitrust.b2ctoolkit.security;
/*    */ 
/*    */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*    */ import com.hitrust.regional.security.RC4;
/*    */ import com.hitrust.regional.security.RSA;
/*    */ import com.hitrust.regional.security.RegionalSecurityException;
/*    */ import com.hitrust.regional.tool.ByteUtil;
/*    */ import javax.crypto.SecretKey;
/*    */ 
/*    */ public class EncryptData
/*    */ {
/* 20 */   private SecretKey exportKey = null;
/*    */ 
/*    */   public String getCIPHER(String strData, int iKeyLen)
/*    */     throws ToolkitException, Exception
/*    */   {
/* 37 */     byte[] bytesCipher = null;
/*    */     try
/*    */     {
/* 40 */       this.exportKey = RC4.rc4KeyGen(iKeyLen);
/*    */ 
/* 42 */       bytesCipher = RC4.rc4Enc(strData.getBytes(), this.exportKey);
/*    */     }
/*    */     catch (RegionalSecurityException e) {
/* 45 */       throw new ToolkitException("-16");
/*    */     }
/*    */ 
/* 48 */     return ByteUtil.bytes2HexStr(bytesCipher);
/*    */   }
/*    */ 
/*    */   public String getKEY(String strPubKeyName)
/*    */     throws ToolkitException
/*    */   {
/* 59 */     byte[] bytes = null;
/*    */     try
/*    */     {
/* 62 */       bytes = RSA.rsaEnc(this.exportKey.getEncoded(), strPubKeyName);
/*    */     }
/*    */     catch (RegionalSecurityException e) {
/* 65 */       throw new ToolkitException("-23");
/*    */     }
/*    */ 
/* 68 */     return ByteUtil.bytes2HexStr(bytes);
/*    */   }
/*    */ 
/*    */   public String getMAC(String strData, String strPrivateKeyFilename)
/*    */     throws ToolkitException
/*    */   {
/* 81 */     byte[] bytes = null;
/*    */     try
/*    */     {
/* 85 */       bytes = RSA.rsaSign(strData.getBytes(), strPrivateKeyFilename, 1);
/*    */     }
/*    */     catch (RegionalSecurityException e)
/*    */     {
/* 89 */       throw new ToolkitException("-27");
/*    */     }
/*    */ 
/* 92 */     return ByteUtil.bytes2HexStr(bytes);
/*    */   }
/*    */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.security.EncryptData
 * JD-Core Version:    0.6.0
 */