/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.util.HiMerchant;
/*     */ import com.hitrust.b2ctoolkit.util.HiServer;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class B2CApse extends B2CPay
/*     */ {
/*     */   public void transaction()
/*     */   {
/*  21 */     boolean logflag = false;
/*     */     try {
/*  23 */       if (isEmpty(getStoreId())) {
/*  24 */         throw new ToolkitException("-32");
/*     */       }
/*  26 */       getHiMerchant();
/*  27 */       getLogger();
/*     */ 
/*  29 */       logflag = true;
/*     */ 
/*  31 */       this.log.info("----- New Auth Start  -----");
/*  32 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*  33 */       this.log.info("[C]StoreID      = " + getStoreId());
/*     */ 
/*  36 */       checkData();
/*  37 */       this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/*  40 */       organizeMessage();
/*  41 */       this.log.info("Organize Message [ ok ].");
/*     */ 
/*  44 */       this.log.info("Send Message......");
/*  45 */       connectTo(HiServer.getAuthUrl());
/*  46 */       this.log.info("Receive Response [ ok ].");
/*     */ 
/*  49 */       parserResult();
/*  50 */       this.log.info("parsing Message [ ok ].");
/*     */ 
/*  52 */       this.log.info("----- New Auth End  -----\n");
/*     */     } catch (ToolkitException e) {
/*  54 */       setRetCode(e.getMessage());
/*  55 */       if (logflag) {
/*  56 */         this.log.info("Run Error! Code ==" + getRetCode());
/*  57 */         this.log.info("----- New Auth End  -----\n");
/*     */       }
/*     */     } catch (Exception e) {
/*  60 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkData() throws ToolkitException, Exception
/*     */   {
/*  66 */     if (isEmpty(getType())) {
/*  67 */       this.log.error("<Toolkit MSG> Input Parameter [TrxType] is wrong.");
/*  68 */       throw new ToolkitException("-45");
/*     */     }
/*     */ 
/*  71 */     if (isEmpty(getOrderNo())) {
/*  72 */       this.log.error("<Toolkit MSG> Input Parameter [ORDERNO] is null or empty.");
/*  73 */       throw new ToolkitException("-31");
/*     */     }
/*  75 */     this.log.info("[P]OrderNo      = " + getOrderNo());
/*     */ 
/*  78 */     if (isEmpty(getOrderDesc())) {
/*  79 */       if (isEmpty(this.hiMerchant.getOrderDesc())) {
/*  80 */         this.log.error("<Toolkit MSG> Input Parameter [ORDERDESC] is null or empty.");
/*  81 */         throw new ToolkitException("-33");
/*     */       }
/*  83 */       setOrderDesc(this.hiMerchant.getOrderDesc());
/*  84 */       this.log.info("[C]OrderDesc    = " + getOrderDesc());
/*     */     }
/*     */     else {
/*  87 */       this.log.info("[P]OrderDesc    = " + getOrderDesc());
/*     */     }
/*     */ 
/*  90 */     if (isEmpty(getCurrency())) {
/*  91 */       if (isEmpty(this.hiMerchant.getCurrency())) {
/*  92 */         this.log.error("<Toolkit MSG> Input Parameter [CURRENCY] is null or empty.");
/*  93 */         throw new ToolkitException("-34");
/*     */       }
/*  95 */       setCurrency(this.hiMerchant.getCurrency());
/*  96 */       this.log.info("[C]Currency     = " + getCurrency());
/*     */     }
/*     */     else {
/*  99 */       this.log.info("[P]Currency     = " + getCurrency());
/*     */     }
/*     */ 
/* 102 */     if (isEmpty(getAmount())) {
/* 103 */       this.log.error("<Toolkit MSG> Input Parameter [AMOUNT] is null or empty.");
/* 104 */       throw new ToolkitException("-35");
/*     */     }
/* 106 */     this.log.info("[P]Amount       = " + getAmount());
/*     */ 
/* 109 */     if (isEmpty(getReturnURL())) {
/* 110 */       if (isEmpty(this.hiMerchant.getReturnURL())) {
/* 111 */         this.log.error("<Toolkit MSG> Input Parameter [RETURNURL] is null or empty.");
/* 112 */         throw new ToolkitException("-37");
/*     */       }
/* 114 */       setReturnURL(this.hiMerchant.getReturnURL());
/* 115 */       this.log.info("[C]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */     else {
/* 118 */       this.log.info("[P]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */ 
/* 121 */     if (isEmpty(getDepositFlag())) {
/* 122 */       if (isEmpty(this.hiMerchant.getDeposit())) {
/* 123 */         this.log.error("<Toolkit MSG> Input Parameter [DEPOSIT] is null or empty.");
/* 124 */         throw new ToolkitException("-38");
/*     */       }
/* 126 */       setDepositFlag(this.hiMerchant.getDeposit());
/* 127 */       this.log.info("[C]Deposit      = " + getDepositFlag());
/*     */     }
/*     */     else {
/* 130 */       this.log.info("[P]Deposit      = " + getDepositFlag());
/*     */     }
/*     */ 
/* 133 */     if (isEmpty(getQueryFlag())) {
/* 134 */       if (isEmpty(this.hiMerchant.getQueryFlag())) {
/* 135 */         this.log.error("<Toolkit MSG> Input Parameter [QUERYFLAG] is null or empty.");
/* 136 */         throw new ToolkitException("-39");
/*     */       }
/* 138 */       setQueryFlag(this.hiMerchant.getQueryFlag());
/* 139 */       this.log.info("[C]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */     else {
/* 142 */       this.log.info("[P]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */ 
/* 145 */     if (isEmpty(getUpdateURL())) {
/* 146 */       if (isEmpty(this.hiMerchant.getUpdateURL())) {
/* 147 */         this.log.error("<Toolkit MSG> Input Parameter [UPDATEURL] is null or empty.");
/* 148 */         throw new ToolkitException("-40");
/*     */       }
/* 150 */       setUpdateURL(this.hiMerchant.getUpdateURL());
/* 151 */       this.log.info("[C]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */     else {
/* 154 */       this.log.info("[P]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */ 
/* 169 */     if (getTicketNo() == null) setTicketNo("");
/* 170 */     if (getPan() == null) setPan("");
/* 171 */     if (getExpiry() == null) setExpiry("");
/* 172 */     if (getE01() == null) setE01("");
/* 173 */     if (getE02() == null) setE02("");
/* 174 */     if (getE03() == null) setE03("");
/* 175 */     if (getE04() == null) setE04("");
/* 176 */     if (getE05() == null) setE05("");
/* 177 */     if (getE11() == null) setE11("");
/* 178 */     if (getE12() == null) setE12("");
/* 179 */     if (getE13() == null) setE13("");
/* 180 */     if (getE14() == null) setE14("");
/*     */ 
/* 182 */     this.log.info("[P]TicketNo     = " + getTicketNo());
/* 183 */     this.log.info("[P]PAN          = " + getPan());
/* 184 */     this.log.info("[P]Expiry       = " + getExpiry());
/* 185 */     this.log.info("[P]E01          = " + getE01());
/* 186 */     this.log.info("[P]E02          = " + getE02());
/* 187 */     this.log.info("[P]E03          = " + getE03());
/* 188 */     this.log.info("[P]E04          = " + getE04());
/* 189 */     this.log.info("[P]E05          = " + getE05());
/*     */ 
/* 191 */     this.log.info("[P]E11          = " + getE11());
/* 192 */     this.log.info("[P]E12          = " + getE12());
/* 193 */     this.log.info("[P]E13          = " + getE13());
/* 194 */     this.log.info("[P]E14          = " + getE14());
/*     */ 
/* 196 */     this.log.info("[P]E15          = " + getName());
/* 197 */     this.log.info("[P]E16          = " + getEmail());
/* 198 */     this.log.info("[P]E17          = " + getE17());
/*     */   }
/*     */ 
/*     */   private void organizeMessage() throws ToolkitException, Exception {
/* 202 */     String message = "";
/* 203 */     message = "T01=" + getType() + "&" + "T02=" + getOrderNo() + "&" + "T03=" + getStoreId() + "&" + "T04=" + getOrderDesc() + "&" + "T05=" + getCurrency() + "&" + "T06=" + getAmount() + "&" + "T08=" + getReturnURL() + "&" + "T09=" + getDepositFlag() + "&" + "T10=" + getQueryFlag() + "&" + "T11=" + getExtendField() + "&" + "T12=" + getUpdateURL() + "&" + "T13=" + getPan() + "&" + "T14=" + getExpiry() + "&" + "T15=" + getMerUpdateURL() + "&" + "O01=" + getTicketNo() + "&" + "E01=" + getE01() + "&" + "E02=" + getE02() + "&" + "E03=" + getE03() + "&" + "E04=" + getE04() + "&" + "E05=" + getE05() + "&" + "E11=" + getE11() + "&" + "E12=" + getE12() + "&" + "E13=" + getE13() + "&" + "E14=" + getE14() + "&" + "E15=" + getName() + "&" + "E16=" + getEmail() + "&" + "E17=" + getE17();
/*     */ 
/* 231 */     if (isEmpty(message)) {
/* 232 */       this.log.error("<Toolkit MSG> No Request Message.");
/* 233 */       throw new ToolkitException("-3");
/*     */     }
/* 235 */     setRequestMessage(message);
/*     */   }
/*     */ 
/*     */   private void parserResult() {
/* 239 */     setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/* 240 */     setAuthCode(parsingKeyword(getResponseMessage(), "R03"));
/* 241 */     setAuthRRN(parsingKeyword(getResponseMessage(), "R04"));
/* 242 */     setEci(parsingKeyword(getResponseMessage(), "R25"));
/* 243 */     setToken(parsingKeyword(getResponseMessage(), "R24"));
/* 244 */     this.log.info("@RC             = " + getRetCode());
/* 245 */     this.log.info("@Token          = " + getToken());
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.B2CApse
 * JD-Core Version:    0.6.0
 */