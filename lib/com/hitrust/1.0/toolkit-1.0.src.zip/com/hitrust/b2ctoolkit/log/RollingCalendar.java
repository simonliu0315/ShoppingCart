/*     */ package com.hitrust.b2ctoolkit.log;
/*     */ 
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ class RollingCalendar extends GregorianCalendar
/*     */ {
/* 290 */   int type = -1;
/*     */ 
/*     */   RollingCalendar()
/*     */   {
/*     */   }
/*     */ 
/*     */   RollingCalendar(TimeZone tz, Locale locale) {
/* 297 */     super(tz, locale);
/*     */   }
/*     */ 
/*     */   void setType(int type) {
/* 301 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public long getNextCheckMillis(Date now) {
/* 305 */     return getNextCheckDate(now).getTime();
/*     */   }
/*     */ 
/*     */   public Date getNextCheckDate(Date now) {
/* 309 */     setTime(now);
/*     */ 
/* 311 */     switch (this.type) {
/*     */     case 0:
/* 313 */       set(13, 0);
/* 314 */       set(14, 0);
/* 315 */       add(12, 1);
/* 316 */       break;
/*     */     case 1:
/* 318 */       set(12, 0);
/* 319 */       set(13, 0);
/* 320 */       set(14, 0);
/* 321 */       add(11, 1);
/* 322 */       break;
/*     */     case 2:
/* 324 */       set(12, 0);
/* 325 */       set(13, 0);
/* 326 */       set(14, 0);
/* 327 */       int hour = get(11);
/* 328 */       if (hour < 12) {
/* 329 */         set(11, 12);
/*     */       } else {
/* 331 */         set(11, 0);
/* 332 */         add(5, 1);
/*     */       }
/* 334 */       break;
/*     */     case 3:
/* 336 */       set(11, 0);
/* 337 */       set(12, 0);
/* 338 */       set(13, 0);
/* 339 */       set(14, 0);
/* 340 */       add(5, 1);
/* 341 */       break;
/*     */     case 4:
/* 343 */       set(7, getFirstDayOfWeek());
/* 344 */       set(11, 0);
/* 345 */       set(13, 0);
/* 346 */       set(14, 0);
/* 347 */       add(3, 1);
/* 348 */       break;
/*     */     case 5:
/* 350 */       set(5, 1);
/* 351 */       set(11, 0);
/* 352 */       set(13, 0);
/* 353 */       set(14, 0);
/* 354 */       add(2, 1);
/* 355 */       break;
/*     */     default:
/* 357 */       throw new IllegalStateException("Unknown periodicity type.");
/*     */     }
/* 359 */     return getTime();
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.log.RollingCalendar
 * JD-Core Version:    0.6.0
 */