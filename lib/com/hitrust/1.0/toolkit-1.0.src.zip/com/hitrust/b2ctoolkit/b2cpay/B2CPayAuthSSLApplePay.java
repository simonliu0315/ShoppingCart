/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.util.HiMerchant;
/*     */ import com.hitrust.b2ctoolkit.util.HiServer;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class B2CPayAuthSSLApplePay extends B2CPay
/*     */ {
/*     */   public void transaction()
/*     */   {
/*  27 */     boolean logflag = false;
/*     */     try {
/*  29 */       if (isEmpty(getStoreId())) {
/*  30 */         throw new ToolkitException("-32");
/*     */       }
/*  32 */       getHiMerchant();
/*     */ 
/*  34 */       getLogger();
/*     */ 
/*  36 */       logflag = true;
/*     */ 
/*  38 */       this.log.info("----- New AuthSSLApplePay Start  -----");
/*  39 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*     */ 
/*  43 */       setType("28");
/*     */ 
/*  46 */       checkData();
/*  47 */       this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/*  50 */       organizeMessage();
/*  51 */       this.log.info("Organize Message [ ok ].");
/*     */ 
/*  54 */       this.log.info("Send Message......");
/*  55 */       connectTo(HiServer.getOtherUrl());
/*  56 */       this.log.info("Receive Response [ ok ].");
/*     */ 
/*  59 */       parserResult();
/*  60 */       this.log.info("parsing Message [ ok ].");
/*     */ 
/*  62 */       this.log.info("----- New AuthSSLApplePay End  -----\n");
/*     */     } catch (ToolkitException e) {
/*  64 */       setRetCode(e.getMessage());
/*  65 */       if (logflag) {
/*  66 */         this.log.info("Run Error! Code ==" + getRetCode());
/*  67 */         this.log.info("----- New AuthSSLApplePay End  -----\n");
/*     */       }
/*     */     } catch (Exception e) {
/*  70 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkData() throws ToolkitException, Exception
/*     */   {
/*  76 */     if (isEmpty(getType())) {
/*  77 */       this.log.error("<Toolkit MSG> Input Parameter [TrxType] is wrong.");
/*  78 */       throw new ToolkitException("-45");
/*     */     }
/*     */ 
/*  81 */     if (isEmpty(getOrderNo())) {
/*  82 */       this.log.error("<Toolkit MSG> Input Parameter [ORDERNO] is null or empty.");
/*  83 */       throw new ToolkitException("-31");
/*     */     }
/*  85 */     this.log.info("[P]OrderNo      = " + getOrderNo());
/*     */ 
/*  88 */     if (isEmpty(getOrderDesc())) {
/*  89 */       if (isEmpty(this.hiMerchant.getOrderDesc())) {
/*  90 */         this.log.error("<Toolkit MSG> Input Parameter [ORDERDESC] is null or empty.");
/*  91 */         throw new ToolkitException("-33");
/*     */       }
/*  93 */       setOrderDesc(this.hiMerchant.getOrderDesc());
/*  94 */       this.log.info("[C]OrderDesc    = " + getOrderDesc());
/*     */     }
/*     */     else {
/*  97 */       this.log.info("[P]OrderDesc    = " + getOrderDesc());
/*     */     }
/*     */ 
/* 100 */     if (isEmpty(getCurrency())) {
/* 101 */       if (isEmpty(this.hiMerchant.getCurrency())) {
/* 102 */         this.log.error("<Toolkit MSG> Input Parameter [CURRENCY] is null or empty.");
/* 103 */         throw new ToolkitException("-34");
/*     */       }
/* 105 */       setCurrency(this.hiMerchant.getCurrency());
/* 106 */       this.log.info("[C]Currency     = " + getCurrency());
/*     */     }
/*     */     else {
/* 109 */       this.log.info("[P]Currency     = " + getCurrency());
/*     */     }
/*     */ 
/* 112 */     if (isEmpty(getAmount())) {
/* 113 */       this.log.error("<Toolkit MSG> Input Parameter [AMOUNT] is null or empty.");
/* 114 */       throw new ToolkitException("-35");
/*     */     }
/* 116 */     this.log.info("[P]Amount       = " + getAmount());
/*     */ 
/* 119 */     if (isEmpty(getReturnURL())) {
/* 120 */       if (isEmpty(this.hiMerchant.getReturnURL())) {
/* 121 */         this.log.error("<Toolkit MSG> Input Parameter [RETURNURL] is null or empty.");
/* 122 */         throw new ToolkitException("-37");
/*     */       }
/* 124 */       setReturnURL(this.hiMerchant.getReturnURL());
/* 125 */       this.log.info("[C]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */     else {
/* 128 */       this.log.info("[P]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */ 
/* 131 */     if (isEmpty(getDepositFlag())) {
/* 132 */       if (isEmpty(this.hiMerchant.getDeposit())) {
/* 133 */         this.log.error("<Toolkit MSG> Input Parameter [DEPOSIT] is null or empty.");
/* 134 */         throw new ToolkitException("-38");
/*     */       }
/* 136 */       setDepositFlag(this.hiMerchant.getDeposit());
/* 137 */       this.log.info("[C]Deposit      = " + getDepositFlag());
/*     */     }
/*     */     else {
/* 140 */       this.log.info("[P]Deposit      = " + getDepositFlag());
/*     */     }
/*     */ 
/* 143 */     if (isEmpty(getQueryFlag())) {
/* 144 */       if (isEmpty(this.hiMerchant.getQueryFlag())) {
/* 145 */         this.log.error("<Toolkit MSG> Input Parameter [QUERYFLAG] is null or empty.");
/* 146 */         throw new ToolkitException("-39");
/*     */       }
/* 148 */       setQueryFlag(this.hiMerchant.getQueryFlag());
/* 149 */       this.log.info("[C]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */     else {
/* 152 */       this.log.info("[P]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */ 
/* 155 */     if (isEmpty(getUpdateURL())) {
/* 156 */       if (isEmpty(this.hiMerchant.getUpdateURL())) {
/* 157 */         this.log.error("<Toolkit MSG> Input Parameter [UPDATEURL] is null or empty.");
/* 158 */         throw new ToolkitException("-40");
/*     */       }
/* 160 */       setUpdateURL(this.hiMerchant.getUpdateURL());
/* 161 */       this.log.info("[C]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */     else {
/* 164 */       this.log.info("[P]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */ 
/* 168 */     if (getTicketNo() == null) setTicketNo("");
/* 169 */     if (getPan() == null) setPan("");
/* 170 */     if (getExpiry() == null) setExpiry("");
/* 171 */     if (getE01() == null) setE01("");
/* 172 */     if (getE02() == null) setE02("");
/* 173 */     if (getE03() == null) setE03("");
/* 174 */     if (getE04() == null) setE04("");
/* 175 */     if (getE05() == null) setE05("");
/* 176 */     if (getE11() == null) setE11("");
/* 177 */     if (getE12() == null) setE12("");
/* 178 */     if (getE13() == null) setE13("");
/* 179 */     if (getE14() == null) setE14("");
/* 180 */     if (getE36() == null) setE36("");
/* 181 */     if (getE37() == null) setE37("");
/* 182 */     if (getE38() == null) setE38("");
/* 183 */     if (getE39() == null) setE39("");
/* 184 */     if (getE40() == null) setE40("");
/* 185 */     if (getE41() == null) setE41("");
/* 186 */     if (getE42() == null) setE42("");
/* 187 */     if (getE52() == null) setE52("");
/* 188 */     if (getE53() == null) setE53("");
/* 189 */     if (getE54() == null) setE54("");
/*     */ 
/* 191 */     this.log.info("[P]TicketNo     = " + getTicketNo());
/*     */ 
/* 204 */     if ((!isEmpty(getE36())) && 
/* 205 */       (getE36().length() > 10)) {
/* 206 */       this.log.error("<Toolkit MSG> Input Parameter [ID] is null or empty or format error.");
/* 207 */       throw new ToolkitException("-60");
/*     */     }
/* 209 */     if ((!isEmpty(getE37())) && 
/* 210 */       (getE37().length() > 15)) {
/* 211 */       this.log.error("<Toolkit MSG> Input Parameter [CELLPHONE] is null or empty or length error.");
/* 212 */       throw new ToolkitException("-61");
/*     */     }
/*     */ 
/* 215 */     if (!isEmpty(getE38())) {
/* 216 */       if (getE38().length() != 4) {
/* 217 */         this.log.error("<Toolkit MSG> Input Parameter [YEAR_OF_BIRTH] is null or empty or length error.");
/* 218 */         throw new ToolkitException("-62");
/* 219 */       }if (getE39().length() == 0) {
/* 220 */         this.log.error("<Toolkit MSG> Input Parameter [MMDD_OF_BIRTH] is null or empty or length error.");
/* 221 */         throw new ToolkitException("-63");
/*     */       }
/*     */     }
/*     */ 
/* 225 */     if (!isEmpty(getE39())) {
/* 226 */       if (getE39().length() != 4) {
/* 227 */         this.log.error("<Toolkit MSG> Input Parameter [MMDD_OF_BIRTH] is null or empty or length error.");
/* 228 */         throw new ToolkitException("-63");
/* 229 */       }if (getE38().length() == 0) {
/* 230 */         this.log.error("<Toolkit MSG> Input Parameter [YEAR_OF_BIRTH] is null or empty or length error.");
/* 231 */         throw new ToolkitException("-62");
/*     */       }
/*     */     }
/* 233 */     if ((!"".equals(getE40())) && (null != getE40()) && 
/* 234 */       (getE40().length() > 15)) {
/* 235 */       this.log.error("<Toolkit MSG> Input Parameter [HomePHONE] is null or empty or length error.");
/* 236 */       throw new ToolkitException("-64");
/*     */     }
/*     */ 
/* 239 */     if ((!"".equals(getE41())) && (null != getE41()) && 
/* 240 */       (getE41().length() > 15)) {
/* 241 */       this.log.error("<Toolkit MSG> Input Parameter [OfficePHONE] is null or empty or length error.");
/* 242 */       throw new ToolkitException("-65");
/*     */     }
/*     */ 
/* 245 */     if ("Y".equalsIgnoreCase(getE42()))
/*     */     {
/* 247 */       if (("".equals(getE36().trim())) && ("".equals(getE37().trim())) && ("".equals(getE38().trim())) && ("".equals(getE39().trim())) && ("".equals(getE40().trim())) && ("".equals(getE41().trim()))) {
/* 248 */         this.log.error("<Toolkit MSG> Input Parameter all is blank for identifying.");
/* 249 */         throw new ToolkitException("-66");
/*     */       }
/* 251 */       if ("1".equals(getDepositFlag())) {
/* 252 */         this.log.error("<Toolkit MSG> Input Parameter only for identifying cannot with depositeflag.");
/* 253 */         throw new ToolkitException("-67");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 259 */     if (!isEmpty(getE52()))
/*     */     {
/* 262 */       if (getE52().matches("[0-9]{8}"))
/*     */       {
/* 265 */         if (!isEmpty(getE53()))
/*     */         {
/* 267 */           if (!getE53().matches("[0-9]{4}"))
/*     */           {
/* 269 */             this.log.error("<Toolkit MSG> Input Parameter [E54] format error.");
/* 270 */             throw new ToolkitException("-74");
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 275 */           this.log.error("<Toolkit MSG> Input Parameter [E53] is null or empty.");
/* 276 */           throw new ToolkitException("-73");
/*     */         }
/*     */ 
/* 279 */         if (!isEmpty(getE54()))
/*     */         {
/* 281 */           if (getE54().length() > 10)
/*     */           {
/* 283 */             this.log.error("<Toolkit MSG> Input Parameter [E54] format error.");
/* 284 */             throw new ToolkitException("-74");
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 289 */           this.log.error("<Toolkit MSG> Input Parameter [E54] is null or empty.");
/* 290 */           throw new ToolkitException("-75");
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 295 */         this.log.error("<Toolkit MSG> Input Parameter [E52] format error.");
/* 296 */         throw new ToolkitException("-72");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 302 */     this.log.info("[P]E02          = " + getE02());
/* 303 */     this.log.info("[P]E03          = " + getE03());
/* 304 */     this.log.info("[P]E04          = " + getE04());
/* 305 */     this.log.info("[P]E05          = " + getE05());
/*     */ 
/* 307 */     this.log.info("[P]E11          = " + getE11());
/* 308 */     this.log.info("[P]E12          = " + getE12());
/* 309 */     this.log.info("[P]E13          = " + getE13());
/* 310 */     this.log.info("[P]E14          = " + getE14());
/*     */ 
/* 312 */     this.log.info("[P]E15          = " + getName());
/* 313 */     this.log.info("[P]E16          = " + getEmail());
/* 314 */     this.log.info("[P]E17          = " + getE17());
/*     */ 
/* 325 */     this.log.info("[P]E52          = " + getE52());
/* 326 */     this.log.info("[P]E53          = " + getE53());
/* 327 */     this.log.info("[P]E54          = " + getE54());
/*     */   }
/*     */ 
/*     */   private void organizeMessage() throws ToolkitException, Exception
/*     */   {
/* 332 */     String message = "";
/* 333 */     message = "T01=" + getType() + "&" + "T02=" + getOrderNo() + "&" + "T03=" + getStoreId() + "&" + "T04=" + getOrderDesc() + "&" + "T05=" + getCurrency() + "&" + "T06=" + getAmount() + "&" + "T08=" + getReturnURL() + "&" + "T09=" + getDepositFlag() + "&" + "T10=" + getQueryFlag() + "&" + "T11=" + getExtendField() + "&" + "T12=" + getUpdateURL() + "&" + "T13=" + getPan() + "&" + "T14=" + getExpiry() + "&" + "T15=" + getMerUpdateURL() + "&" + "T16=" + getTrxToken() + "&" + "O01=" + getTicketNo() + "&" + "E01=" + getE01() + "&" + "E02=" + getE02() + "&" + "E03=" + getE03() + "&" + "E04=" + getE04() + "&" + "E05=" + getE05() + "&" + "E11=" + getE11() + "&" + "E12=" + getE12() + "&" + "E13=" + getE13() + "&" + "E14=" + getE14() + "&" + "E15=" + getName() + "&" + "E16=" + getEmail() + "&" + "E17=" + getE17() + "&" + "E36=" + getE36() + "&" + "E37=" + getE37() + "&" + "E38=" + getE38() + "&" + "E39=" + getE39() + "&" + "E40=" + getE40() + "&" + "E41=" + getE41() + "&" + "E42=" + getE42() + "&" + "E52=" + getE52() + "&" + "E53=" + getE53() + "&" + "E54=" + getE54() + "&" + "E60=" + getE60() + "&" + "E61=" + getE61();
/*     */ 
/* 375 */     if (isEmpty(message)) {
/* 376 */       this.log.error("<Toolkit MSG> No Request Message.");
/* 377 */       throw new ToolkitException("-3");
/*     */     }
/* 379 */     setRequestMessage(message);
/*     */   }
/*     */ 
/*     */   private void parserResult() {
/* 383 */     setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/* 384 */     setOrderDesc(parsingKeyword(getResponseMessage(), "T04"));
/* 385 */     setCurrency(parsingKeyword(getResponseMessage(), "T05"));
/* 386 */     if (getQueryFlag().equals("1")) {
/* 387 */       setSecCode(parsingKeyword(getResponseMessage(), "R02"));
/* 388 */       setAuthCode(parsingKeyword(getResponseMessage(), "R03"));
/* 389 */       setAuthRRN(parsingKeyword(getResponseMessage(), "R04"));
/* 390 */       setOrderStatus(parsingKeyword(getResponseMessage(), "R05"));
/* 391 */       setCreditStatus(parsingKeyword(getResponseMessage(), "R06"));
/* 392 */       setAcquirer(parsingKeyword(getResponseMessage(), "R07"));
/* 393 */       setCardType(parsingKeyword(getResponseMessage(), "R08"));
/* 394 */       setApproveAmount(parsingKeyword(getResponseMessage(), "R09"));
/* 395 */       setCaptureAmount(parsingKeyword(getResponseMessage(), "R10"));
/* 396 */       setCaptureNum(parsingKeyword(getResponseMessage(), "R11"));
/* 397 */       setRefundAmount(parsingKeyword(getResponseMessage(), "R12"));
/* 398 */       setRefundNum(parsingKeyword(getResponseMessage(), "R13"));
/* 399 */       setOrderDate(parsingKeyword(getResponseMessage(), "R14"));
/* 400 */       setPayBatchNum(parsingKeyword(getResponseMessage(), "R15"));
/* 401 */       setCaptureCode(parsingKeyword(getResponseMessage(), "R16"));
/* 402 */       setCaptureDate(parsingKeyword(getResponseMessage(), "R17"));
/* 403 */       setPaymentNum(parsingKeyword(getResponseMessage(), "R18"));
/* 404 */       setRefundBatch(parsingKeyword(getResponseMessage(), "R20"));
/* 405 */       setRefundCode(parsingKeyword(getResponseMessage(), "R21"));
/* 406 */       setRefundRRN(parsingKeyword(getResponseMessage(), "R22"));
/* 407 */       setRefundDate(parsingKeyword(getResponseMessage(), "R23"));
/* 408 */       setToken(parsingKeyword(getResponseMessage(), "R24"));
/* 409 */       setEci(parsingKeyword(getResponseMessage(), "R25"));
/*     */ 
/* 414 */       setE28(parsingKeyword(getResponseMessage(), "E28"));
/* 415 */       setE29(parsingKeyword(getResponseMessage(), "E29"));
/*     */ 
/* 417 */       setRedemordernum(parsingKeyword(getResponseMessage(), "R28"));
/* 418 */       setRedem_discount_point(parsingKeyword(getResponseMessage(), "R29"));
/* 419 */       setRedem_discount_amount(parsingKeyword(getResponseMessage(), "R30"));
/* 420 */       setRedem_purchase_amount(parsingKeyword(getResponseMessage(), "R31"));
/* 421 */       setRedem_balance_point(parsingKeyword(getResponseMessage(), "R32"));
/*     */     }
/*     */ 
/* 424 */     this.log.info("@RC             = " + getRetCode());
/* 425 */     this.log.info("@Token          = " + getToken());
/* 426 */     this.log.info("@E06            = " + getE06());
/* 427 */     this.log.info("@E07            = " + getE07());
/* 428 */     this.log.info("@E08            = " + getE08());
/* 429 */     this.log.info("@E09            = " + getE09());
/* 430 */     this.log.info("@E10            = " + getE10());
/* 431 */     this.log.info("@AuthCode       = " + getAuthCode());
/* 432 */     this.log.info("@AuthRRN        = " + getAuthRRN());
/* 433 */     this.log.info("@CardType       = " + getCardType());
/* 434 */     this.log.info("@OrderStatus    = " + getOrderStatus());
/* 435 */     this.log.info("@Acquirer       = " + getAcquirer());
/* 436 */     this.log.info("@ApproveAmount  = " + getApproveAmount());
/* 437 */     this.log.info("@CaptureAmount  = " + getCaptureAmount());
/* 438 */     this.log.info("@RefundAmount   = " + getRefundAmount());
/* 439 */     this.log.info("@OrderDate      = " + getOrderDate());
/* 440 */     this.log.info("@PayBatchNum    = " + getPayBatchNum());
/* 441 */     this.log.info("@CaptureDate    = " + getCaptureDate());
/* 442 */     this.log.info("@RefundBatch    = " + getRefundBatch());
/* 443 */     this.log.info("@RefundCode     = " + getRefundCode());
/* 444 */     this.log.info("@RefundRRN      = " + getRefundRRN());
/* 445 */     this.log.info("@RefundDate     = " + getRefundDate());
/* 446 */     this.log.info("@ECI            = " + getEci());
/* 447 */     this.log.info("@E28            = " + getE28());
/* 448 */     this.log.info("@E29            = " + getE29());
/* 449 */     this.log.info("@Redemordernum         = " + getRedemordernum());
/* 450 */     this.log.info("@Redem_discount_point  = " + getRedem_discount_point());
/* 451 */     this.log.info("@Redem_discount_amount = " + getRedem_discount_amount());
/* 452 */     this.log.info("@Redem_purchase_amount = " + getRedem_purchase_amount());
/* 453 */     this.log.info("@Redem_balance_point   = " + getRedem_balance_point());
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.B2CPayAuthSSLApplePay
 * JD-Core Version:    0.6.0
 */