/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.util.HiMerchant;
/*     */ import com.hitrust.b2ctoolkit.util.HiServer;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class B2CPayOther extends B2CPay
/*     */ {
/*     */   public void transaction()
/*     */   {
/*  21 */     boolean logflag = false;
/*     */     try {
/*  23 */       if (isEmpty(getStoreId())) {
/*  24 */         throw new ToolkitException("-32");
/*     */       }
/*  26 */       getHiMerchant();
/*     */ 
/*  28 */       getLogger();
/*     */ 
/*  30 */       logflag = true;
/*     */ 
/*  32 */       this.log.info("----- New Other-Trx Start -----");
/*  33 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*     */ 
/*  36 */       checkData();
/*  37 */       this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/*  40 */       organizeMessage();
/*  41 */       this.log.info("Organize Message [ ok ].");
/*     */ 
/*  44 */       this.log.info("Send Message......");
/*  45 */       connectTo(HiServer.getOtherUrl());
/*  46 */       this.log.info("Receive Response [ ok ].");
/*     */ 
/*  49 */       parserResult();
/*  50 */       this.log.info("parsing Message [ ok ].");
/*     */ 
/*  52 */       this.log.info("----- New Other-Trx End -----\n");
/*     */     } catch (ToolkitException e) {
/*  54 */       setRetCode(e.getMessage());
/*  55 */       if (logflag) {
/*  56 */         this.log.info("Run Error! Code ==" + getRetCode());
/*  57 */         this.log.info("----- New Other-Trx End -----\n");
/*     */       }
/*     */     } catch (Exception e) {
/*  60 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkData()
/*     */     throws ToolkitException, Exception
/*     */   {
/*  67 */     int type = Integer.parseInt(getType());
/*  68 */     if ((isEmpty(getType())) || (((type < 3) || (type > 8)) && (type != 17) && (type != 18) && (type != 32) && (type != 33))) {
/*  69 */       this.log.error("<Toolkit MSG> Input Parameter [TrxType] is wrong.");
/*  70 */       throw new ToolkitException("-45");
/*     */     }
/*  72 */     this.log.info("[P]TrxType      = " + getTrxTypeName(type));
/*     */ 
/*  77 */     if (isEmpty(getOrderNo())) {
/*  78 */       this.log.error("<Toolkit MSG> Input Parameter [ORDERNO] is null or empty.");
/*  79 */       throw new ToolkitException("-31");
/*     */     }
/*  81 */     this.log.info("[P]OrderNo      = " + getOrderNo());
/*     */ 
/*  84 */     if (((getType().equals("3")) || (getType().equals("5"))) && (isEmpty(getAmount()))) {
/*  85 */       this.log.error("<Toolkit MSG> Input Parameter [AMOUNT] is null or empty.");
/*  86 */       throw new ToolkitException("-35");
/*     */     }
/*  88 */     this.log.info("[P]Amount       = " + getAmount());
/*     */ 
/*  91 */     if (isEmpty(getQueryFlag())) {
/*  92 */       if (isEmpty(this.hiMerchant.getQueryFlag())) {
/*  93 */         this.log.error("<Toolkit MSG> Input Parameter [QUERYFLAG] is null or empty.");
/*  94 */         throw new ToolkitException("-39");
/*     */       }
/*  96 */       setQueryFlag(this.hiMerchant.getQueryFlag());
/*  97 */       this.log.info("[C]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */     else {
/* 100 */       this.log.info("[P]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */ 
/* 103 */     if (getE01() == null) setE01("");
/* 104 */     if (getE02() == null) setE02("");
/* 105 */     if (getE03() == null) setE03("");
/* 106 */     if (getE04() == null) setE04("");
/* 107 */     if (getE05() == null) setE05("");
/* 108 */     if (getE11() == null) setE11("");
/* 109 */     if (getE12() == null) setE12("");
/* 110 */     if (getE13() == null) setE13("");
/* 111 */     if (getE14() == null) setE14("");
/*     */ 
/* 113 */     this.log.info("[P]E01          = " + getE01());
/* 114 */     this.log.info("[P]E02          = " + getE02());
/* 115 */     this.log.info("[P]E03          = " + getE03());
/* 116 */     this.log.info("[P]E04          = " + getE04());
/* 117 */     this.log.info("[P]E05          = " + getE05());
/* 118 */     this.log.info("[P]E11          = " + getE11());
/* 119 */     this.log.info("[P]E12          = " + getE12());
/* 120 */     this.log.info("[P]E13          = " + getE13());
/* 121 */     this.log.info("[P]E14          = " + getE14());
/*     */   }
/*     */ 
/*     */   private void organizeMessage() throws ToolkitException, Exception {
/* 125 */     String message = "";
/* 126 */     message = "T01=" + getType() + "&" + "T02=" + getOrderNo() + "&" + "T03=" + getStoreId() + "&" + "T06=" + getAmount() + "&" + "T10=" + getQueryFlag() + "&" + "T11=" + getExtendField() + "&" + "E01=" + getE01() + "&" + "E02=" + getE02() + "&" + "E03=" + getE03() + "&" + "E04=" + getE04() + "&" + "E05=" + getE05() + "&" + "E11=" + getE11() + "&" + "E12=" + getE12() + "&" + "E13=" + getE13() + "&" + "E14=" + getE14();
/*     */ 
/* 141 */     if (isEmpty(message)) {
/* 142 */       this.log.error("<Toolkit MSG> No Request Message.");
/* 143 */       throw new ToolkitException("-3");
/*     */     }
/* 145 */     setRequestMessage(message);
/*     */   }
/*     */ 
/*     */   private void parserResult() {
/* 149 */     setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/* 150 */     setOrderDesc(parsingKeyword(getResponseMessage(), "T04"));
/* 151 */     setCurrency(parsingKeyword(getResponseMessage(), "T05"));
/* 152 */     if (("7".equals(getType())) || (getQueryFlag().equals("1"))) {
/* 153 */       setSecCode(parsingKeyword(getResponseMessage(), "R02"));
/* 154 */       setAuthCode(parsingKeyword(getResponseMessage(), "R03"));
/* 155 */       setAuthRRN(parsingKeyword(getResponseMessage(), "R04"));
/* 156 */       setOrderStatus(parsingKeyword(getResponseMessage(), "R05"));
/* 157 */       setCreditStatus(parsingKeyword(getResponseMessage(), "R06"));
/* 158 */       setAcquirer(parsingKeyword(getResponseMessage(), "R07"));
/* 159 */       setCardType(parsingKeyword(getResponseMessage(), "R08"));
/* 160 */       setApproveAmount(parsingKeyword(getResponseMessage(), "R09"));
/* 161 */       setCaptureAmount(parsingKeyword(getResponseMessage(), "R10"));
/* 162 */       setCaptureNum(parsingKeyword(getResponseMessage(), "R11"));
/* 163 */       setRefundAmount(parsingKeyword(getResponseMessage(), "R12"));
/* 164 */       setRefundNum(parsingKeyword(getResponseMessage(), "R13"));
/* 165 */       setOrderDate(parsingKeyword(getResponseMessage(), "R14"));
/* 166 */       setPayBatchNum(parsingKeyword(getResponseMessage(), "R15"));
/* 167 */       setCaptureCode(parsingKeyword(getResponseMessage(), "R16"));
/* 168 */       setCaptureDate(parsingKeyword(getResponseMessage(), "R17"));
/* 169 */       setPaymentNum(parsingKeyword(getResponseMessage(), "R18"));
/* 170 */       setRefundBatch(parsingKeyword(getResponseMessage(), "R20"));
/* 171 */       setRefundCode(parsingKeyword(getResponseMessage(), "R21"));
/* 172 */       setRefundRRN(parsingKeyword(getResponseMessage(), "R22"));
/* 173 */       setRefundDate(parsingKeyword(getResponseMessage(), "R23"));
/* 174 */       setToken(parsingKeyword(getResponseMessage(), "R24"));
/* 175 */       setEci(parsingKeyword(getResponseMessage(), "R25"));
/* 176 */       setE06(parsingKeyword(getResponseMessage(), "E06"));
/* 177 */       setE07(parsingKeyword(getResponseMessage(), "E07"));
/* 178 */       setE08(parsingKeyword(getResponseMessage(), "E08"));
/* 179 */       setE09(parsingKeyword(getResponseMessage(), "E09"));
/* 180 */       setE10(parsingKeyword(getResponseMessage(), "E10"));
/*     */ 
/* 183 */       setName(parsingKeyword(getResponseMessage(), "E15"));
/* 184 */       setEmail(parsingKeyword(getResponseMessage(), "E16"));
/* 185 */       setE17(parsingKeyword(getResponseMessage(), "E17"));
/* 186 */       setE18(parsingKeyword(getResponseMessage(), "E18"));
/* 187 */       setE19(parsingKeyword(getResponseMessage(), "E19"));
/* 188 */       setE20(parsingKeyword(getResponseMessage(), "E20"));
/* 189 */       setE21(parsingKeyword(getResponseMessage(), "E21"));
/* 190 */       setE25(parsingKeyword(getResponseMessage(), "E25"));
/* 191 */       setE26(parsingKeyword(getResponseMessage(), "E26"));
/* 192 */       setE27(parsingKeyword(getResponseMessage(), "E27"));
/*     */ 
/* 195 */       setAuthhostdate(parsingKeyword(getResponseMessage(), "R26"));
/* 196 */       setAuthhosttime(parsingKeyword(getResponseMessage(), "R27"));
/* 197 */       setRedemordernum(parsingKeyword(getResponseMessage(), "R28"));
/* 198 */       setRedem_discount_point(parsingKeyword(getResponseMessage(), "R29"));
/* 199 */       setRedem_discount_amount(parsingKeyword(getResponseMessage(), "R30"));
/* 200 */       setRedem_purchase_amount(parsingKeyword(getResponseMessage(), "R31"));
/* 201 */       setRedem_balance_point(parsingKeyword(getResponseMessage(), "R32"));
/* 202 */       setCavv(parsingKeyword(getResponseMessage(), "R33"));
/*     */ 
/* 205 */       setE28(parsingKeyword(getResponseMessage(), "E28"));
/* 206 */       setE29(parsingKeyword(getResponseMessage(), "E29"));
/*     */     }
/*     */ 
/* 209 */     if ("32".equals(getType())) {
/* 210 */       setSIP_Data(parsingKeyword(getResponseMessage(), "R34"));
/*     */     }
/*     */ 
/* 214 */     if ((parsingKeyword(getResponseMessage(), "T13") != null) && (parsingKeyword(getResponseMessage(), "T13").length() > 0))
/* 215 */       setPan(parsingKeyword(getResponseMessage(), "T13"));
/*     */     else {
/* 217 */       setPan(parsingKeyword(getResponseMessage(), "R37"));
/*     */     }
/*     */ 
/* 221 */     this.log.info("@RetCode        = " + getRetCode());
/* 222 */     this.log.info("@AuthCode       = " + getAuthCode());
/* 223 */     this.log.info("@AuthRRN        = " + getAuthRRN());
/* 224 */     this.log.info("@CardType       = " + getCardType());
/* 225 */     this.log.info("@OrderStatus    = " + getOrderStatus());
/* 226 */     this.log.info("@Acquirer       = " + getAcquirer());
/* 227 */     this.log.info("@ApproveAmount  = " + getApproveAmount());
/* 228 */     this.log.info("@CaptureAmount  = " + getCaptureAmount());
/* 229 */     this.log.info("@RefundAmount   = " + getRefundAmount());
/* 230 */     this.log.info("@OrderDate      = " + getOrderDate());
/* 231 */     this.log.info("@PayBatchNum    = " + getPayBatchNum());
/* 232 */     this.log.info("@CaptureDate    = " + getCaptureDate());
/* 233 */     this.log.info("@RefundBatch    = " + getRefundBatch());
/* 234 */     this.log.info("@RefundCode     = " + getRefundCode());
/* 235 */     this.log.info("@RefundRRN      = " + getRefundRRN());
/* 236 */     this.log.info("@RefundDate     = " + getRefundDate());
/* 237 */     this.log.info("@Currency       = " + getCurrency());
/* 238 */     this.log.info("@ECI            = " + getEci());
/* 239 */     this.log.info("@E06            = " + getE06());
/* 240 */     this.log.info("@E07            = " + getE07());
/* 241 */     this.log.info("@E08            = " + getE08());
/* 242 */     this.log.info("@E09            = " + getE09());
/* 243 */     this.log.info("@E10            = " + getE10());
/* 244 */     this.log.info("@E18            = " + getE18());
/* 245 */     this.log.info("@E19            = " + getE19());
/* 246 */     this.log.info("@E20            = " + getE20());
/* 247 */     this.log.info("@E21            = " + getE21());
/* 248 */     this.log.info("@E25            = " + getE25());
/* 249 */     this.log.info("@E26            = " + getE26());
/* 250 */     this.log.info("@E27            = " + getE27());
/* 251 */     this.log.info("@E28            = " + getE28());
/* 252 */     this.log.info("@E29            = " + getE29());
/*     */ 
/* 255 */     this.log.info("@Authhostdate          = " + getAuthhostdate());
/* 256 */     this.log.info("@Authhosttime          = " + getAuthhosttime());
/* 257 */     this.log.info("@Redemordernum         = " + getRedemordernum());
/* 258 */     this.log.info("@Redem_discount_point  = " + getRedem_discount_point());
/* 259 */     this.log.info("@Redem_discount_amount = " + getRedem_discount_amount());
/* 260 */     this.log.info("@Redem_purchase_amount = " + getRedem_purchase_amount());
/* 261 */     this.log.info("@Redem_balance_point   = " + getRedem_balance_point());
/* 262 */     this.log.info("@Cavv                  = " + getCavv());
/* 263 */     this.log.info("@SIP_Data              = " + getSIP_Data());
/*     */   }
/*     */ 
/*     */   private String getTrxTypeName(int type)
/*     */   {
/* 269 */     String typeName = "";
/* 270 */     switch (type) {
/*     */     case 3:
/* 272 */       typeName = "Capture";
/* 273 */       break;
/*     */     case 4:
/* 275 */       typeName = "CaptureRe";
/* 276 */       break;
/*     */     case 5:
/* 278 */       typeName = "Refund";
/* 279 */       break;
/*     */     case 6:
/* 281 */       typeName = "RefundRe";
/* 282 */       break;
/*     */     case 7:
/* 284 */       typeName = "Query";
/* 285 */       break;
/*     */     case 8:
/* 287 */       typeName = "AuthRe";
/* 288 */       break;
/*     */     case 9:
/* 290 */       typeName = "APSE";
/* 291 */       break;
/*     */     case 10:
/* 293 */       typeName = "VIRTUAL";
/* 294 */       break;
/*     */     case 11:
/* 296 */       typeName = "POST";
/* 297 */       break;
/*     */     case 12:
/* 299 */       typeName = "EMVSIGN";
/* 300 */       break;
/*     */     case 13:
/* 302 */       typeName = "CARD_PAY";
/* 303 */       break;
/*     */     case 14:
/* 305 */       typeName = "CARD_SALE";
/* 306 */       break;
/*     */     case 15:
/* 308 */       typeName = "CARD_AUTH";
/* 309 */       break;
/*     */     case 16:
/* 311 */       typeName = "CARD_PRE_AUTH";
/* 312 */       break;
/*     */     case 17:
/* 314 */       typeName = "CARD_AUTH_REV";
/* 315 */       break;
/*     */     case 18:
/* 317 */       typeName = "CARD_REFUND";
/* 318 */       break;
/*     */     case 32:
/* 320 */       typeName = "SIP_QUERY";
/* 321 */       break;
/*     */     case 33:
/* 323 */       typeName = "SIP_CANCEL";
/* 324 */       break;
/*     */     case 19:
/*     */     case 20:
/*     */     case 21:
/*     */     case 22:
/*     */     case 23:
/*     */     case 24:
/*     */     case 25:
/*     */     case 26:
/*     */     case 27:
/*     */     case 28:
/*     */     case 29:
/*     */     case 30:
/*     */     case 31:
/*     */     default:
/* 327 */       typeName = "Unknow";
/*     */     }
/*     */ 
/* 331 */     return typeName;
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.B2CPayOther
 * JD-Core Version:    0.6.0
 */