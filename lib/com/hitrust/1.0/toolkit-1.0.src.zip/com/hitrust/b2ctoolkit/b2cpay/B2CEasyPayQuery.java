/*    */ package com.hitrust.b2ctoolkit.b2cpay;
/*    */ 
/*    */ import com.hitrust.b2ctoolkit.util.HiServer;
/*    */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Date;
/*    */ import java.util.HashMap;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.bouncycastle.util.encoders.Hex;
/*    */ 
/*    */ public class B2CEasyPayQuery extends B2CBase
/*    */ {
/* 16 */   private Date dateStartCreate = null;
/*    */ 
/* 19 */   private Date dateEndCreate = null;
/* 20 */   private Date dateStartAvailable = null;
/* 21 */   private Date dateEndAvailable = null;
/*    */ 
/* 23 */   private String easyPayLink = null;
/*    */ 
/* 25 */   private ArrayList epRTN = new ArrayList();
/* 26 */   private SimpleDateFormat sdfForTransmit = new SimpleDateFormat("yyyyMMddHHmmss");
/*    */ 
/*    */   public B2CEasyPayQuery(String storeId)
/*    */   {
/* 30 */     super(storeId, "30");
/*    */   }
/*    */ 
/*    */   protected String getConnectTargetURL() throws ToolkitException {
/* 34 */     return HiServer.getOtherUrl();
/*    */   }
/*    */ 
/*    */   public String getEasyPayLink() {
/* 38 */     return this.easyPayLink;
/*    */   }
/*    */ 
/*    */   public ArrayList getOrders()
/*    */   {
/* 43 */     return this.epRTN;
/*    */   }
/*    */ 
/*    */   protected void handleResponse(HashMap tagsFromResponse) throws Exception {
/* 47 */     this.log.info("----- B2CEasyPayQuery handleResponse -----");
/* 48 */     String tmp = (String)tagsFromResponse.get("S04");
/*    */ 
/* 50 */     if ((tmp == null) || (tmp.trim().length() == 0)) {
/* 51 */       throw new IllegalArgumentException("easyPayLink is empty");
/*    */     }
/* 53 */     this.easyPayLink = new String(Hex.decode(tmp));
/* 54 */     String orderline = (String)tagsFromResponse.get("T04");
/*    */ 
/* 56 */     B2CEasyPayUtility.parseOrderLinesTo(orderline, this.epRTN);
/*    */   }
/*    */ 
/*    */   protected void prepareData(HashMap tagsForSend) throws ToolkitException
/*    */   {
/* 61 */     this.log.info("----- B2CEasyPayQuery prepareData -----");
/*    */ 
/* 63 */     tagsForSend.put("T03", getStoreId());
/*    */ 
/* 65 */     tagsForSend.put("E63", this.dateStartAvailable == null ? "0" : this.sdfForTransmit.format(this.dateStartAvailable));
/*    */ 
/* 68 */     tagsForSend.put("E17", this.dateEndAvailable == null ? "0" : this.sdfForTransmit.format(this.dateEndAvailable));
/*    */ 
/* 72 */     tagsForSend.put("E64", this.dateStartCreate == null ? "0" : this.sdfForTransmit.format(this.dateStartCreate));
/*    */ 
/* 75 */     tagsForSend.put("E65", this.dateEndCreate == null ? "0" : this.sdfForTransmit.format(this.dateEndCreate));
/*    */ 
/* 79 */     tagsForSend.put("E16", getEmail() == null ? "0" : getEmail());
/*    */ 
/* 83 */     this.log.debug("PrepareData [ ok ].");
/*    */   }
/*    */ 
/*    */   public void setAvailableDate(Date payStartDate, Date payEndDay) {
/* 87 */     this.dateStartAvailable = payStartDate;
/* 88 */     this.dateEndAvailable = payEndDay;
/*    */   }
/*    */ 
/*    */   public void setCreateDate(Date createStartDate, Date createEndDate) {
/* 92 */     this.dateStartCreate = createStartDate;
/* 93 */     this.dateEndCreate = createEndDate;
/*    */   }
/*    */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.B2CEasyPayQuery
 * JD-Core Version:    0.6.0
 */