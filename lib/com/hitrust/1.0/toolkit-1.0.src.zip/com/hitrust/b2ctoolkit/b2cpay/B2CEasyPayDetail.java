/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import java.util.Date;
/*     */ 
/*     */ public class B2CEasyPayDetail
/*     */ {
/*     */   public static final int STATUS_0_NOT_PAID = 0;
/*     */   public static final int STATUS_1_PAID = 1;
/*     */   public static final int STATUS_2_PAYING = 2;
/*     */   public static final int STATUS_5_SUSPEND = 5;
/*     */   protected String storeId;
/*     */   protected String orderName;
/*     */   protected Date startDate;
/*     */   protected Date endDate;
/*     */   protected Date createDate;
/*     */   protected int amount;
/*     */   protected String mail;
/*     */   protected String orderId;
/*     */   protected int status;
/*     */   protected String token;
/*     */   protected Date payDate;
/*     */   protected String paytype;
/*     */   protected String installm_plan;
/*     */   protected String notice_mail;
/*     */ 
/*     */   public String getPaytype()
/*     */   {
/*  31 */     return this.paytype;
/*     */   }
/*     */   public void setPaytype(String paytype) {
/*  34 */     this.paytype = paytype;
/*     */   }
/*     */ 
/*     */   public String getInstallm_plan()
/*     */   {
/*  39 */     return this.installm_plan;
/*     */   }
/*     */   public void setInstallm_plan(String installm_plan) {
/*  42 */     this.installm_plan = installm_plan;
/*     */   }
/*     */   public String getNotice_mail() {
/*  45 */     return this.notice_mail;
/*     */   }
/*     */   public void setNotice_mail(String notice_mail) {
/*  48 */     this.notice_mail = notice_mail;
/*     */   }
/*     */ 
/*     */   public String getStoreId()
/*     */   {
/*  53 */     return this.storeId;
/*     */   }
/*     */   public void setStoreId(String storeId) {
/*  56 */     this.storeId = storeId;
/*     */   }
/*     */   public String getOrderName() {
/*  59 */     return this.orderName;
/*     */   }
/*     */   public void setOrderName(String orderName) {
/*  62 */     this.orderName = orderName;
/*     */   }
/*     */   public Date getStartDate() {
/*  65 */     return this.startDate;
/*     */   }
/*     */   public void setStartDate(Date startDate) {
/*  68 */     this.startDate = startDate;
/*     */   }
/*     */   public Date getEndDate() {
/*  71 */     return this.endDate;
/*     */   }
/*     */   public void setEndDate(Date endDate) {
/*  74 */     this.endDate = endDate;
/*     */   }
/*     */   public Date getCreateDate() {
/*  77 */     return this.createDate;
/*     */   }
/*     */   public void setCreateDate(Date createDate) {
/*  80 */     this.createDate = createDate;
/*     */   }
/*     */   public int getAmount() {
/*  83 */     return this.amount;
/*     */   }
/*     */   public void setAmount(int amount) {
/*  86 */     this.amount = amount;
/*     */   }
/*     */   public String getMail() {
/*  89 */     return this.mail;
/*     */   }
/*     */   public void setMail(String mail) {
/*  92 */     this.mail = mail;
/*     */   }
/*     */   public String getOrderId() {
/*  95 */     return this.orderId;
/*     */   }
/*     */   public void setOrderId(String orderId) {
/*  98 */     this.orderId = orderId;
/*     */   }
/*     */   public int getStatus() {
/* 101 */     return this.status;
/*     */   }
/*     */   public void setStatus(int status) {
/* 104 */     this.status = status;
/*     */   }
/*     */   public String getToken() {
/* 107 */     return this.token;
/*     */   }
/*     */   public void setToken(String token) {
/* 110 */     this.token = token;
/*     */   }
/*     */   public Date getPayDate() {
/* 113 */     return this.payDate;
/*     */   }
/*     */   public void setPayDate(Date payDate) {
/* 116 */     this.payDate = payDate;
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.B2CEasyPayDetail
 * JD-Core Version:    0.6.0
 */