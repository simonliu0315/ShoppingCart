/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.util.HiServer;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import java.io.PrintStream;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class UPOPPayOther extends B2CPay
/*     */ {
/*     */   public void transaction()
/*     */   {
/*  21 */     boolean logflag = false;
/*     */     try {
/*  23 */       if (isEmpty(getStoreId())) {
/*  24 */         throw new ToolkitException("-32");
/*     */       }
/*  26 */       getHiMerchant();
/*     */ 
/*  28 */       getLogger();
/*     */ 
/*  30 */       logflag = true;
/*     */ 
/*  32 */       this.log.info("----- New UPOP Other-Trx Start -----");
/*  33 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*     */ 
/*  36 */       checkData();
/*  37 */       this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/*  40 */       organizeMessage();
/*  41 */       this.log.info("Organize Message [ ok ].");
/*     */ 
/*  44 */       this.log.info("Send Message......");
/*  45 */       connectTo(HiServer.getUPOPOtherUrl());
/*  46 */       this.log.info("Receive Response [ ok ].");
/*     */ 
/*  49 */       parserResult();
/*  50 */       this.log.info("parsing Message [ ok ].");
/*     */ 
/*  52 */       this.log.info("----- New UPOP Other-Trx End -----\n");
/*     */     } catch (ToolkitException e) {
/*  54 */       setRetCode(e.getMessage());
/*  55 */       if (logflag) {
/*  56 */         this.log.info("Run Error! Code ==" + getRetCode());
/*  57 */         this.log.info("----- New UPOP Other-Trx End -----\n");
/*     */       }
/*     */     } catch (Exception e) {
/*  60 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkData() throws ToolkitException, Exception
/*     */   {
/*  66 */     int type = Integer.parseInt(getType());
/*  67 */     if ((isEmpty(getType())) || (type < 3) || (type > 8)) {
/*  68 */       this.log.error("<Toolkit MSG> Input Parameter [TrxType] is wrong.");
/*  69 */       throw new ToolkitException("-45");
/*     */     }
/*  71 */     String[] trxType = { "Capture", "CaptureRe", "Refund", "RefundRe", "Query", "AuthRe", "APSE", "VIRTUAL", "POST", "EMVSIGN", "CARD_PAY", "CARD_SALE", "CARD_AUTH", "CARD_PRE_AUTH", "CARD_AUTH_REV", "CARD_REFUND" };
/*  72 */     this.log.info("[P]TrxType      = " + trxType[(Integer.parseInt(getType()) - 3)]);
/*     */ 
/*  75 */     if (isEmpty(getOrderNo())) {
/*  76 */       this.log.error("<Toolkit MSG> Input Parameter [ORDERNO] is null or empty.");
/*  77 */       throw new ToolkitException("-31");
/*     */     }
/*  79 */     this.log.info("[P]OrderNo      = " + getOrderNo());
/*     */ 
/*  82 */     if (((getType().equals("3")) || (getType().equals("5"))) && (isEmpty(getAmount()))) {
/*  83 */       this.log.error("<Toolkit MSG> Input Parameter [AMOUNT] is null or empty.");
/*  84 */       throw new ToolkitException("-35");
/*     */     }
/*  86 */     this.log.info("[P]Amount       = " + getAmount());
/*     */   }
/*     */ 
/*     */   private void organizeMessage()
/*     */     throws ToolkitException, Exception
/*     */   {
/*  92 */     String message = "";
/*  93 */     message = "T01=" + getType() + "&" + "T02=" + getOrderNo() + "&" + "T03=" + getStoreId() + "&" + "T06=" + getAmount() + "&" + "T11=" + getExtendField();
/*     */ 
/*  98 */     if (isEmpty(message)) {
/*  99 */       this.log.error("<Toolkit MSG> No Request Message.");
/* 100 */       throw new ToolkitException("-3");
/*     */     }
/* 102 */     setRequestMessage(message);
/*     */   }
/*     */ 
/*     */   private void parserResult() {
/* 106 */     setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/* 107 */     setCurrency(parsingKeyword(getResponseMessage(), "T05"));
/* 108 */     if ("7".equals(getType())) {
/* 109 */       setOrderStatus(parsingKeyword(getResponseMessage(), "R05"));
/*     */     }
/* 111 */     setApproveAmount(parsingKeyword(getResponseMessage(), "R09"));
/* 112 */     setRefundAmount(parsingKeyword(getResponseMessage(), "R12"));
/* 113 */     System.out.println("getResponseMessage(" + getResponseMessage() + ")");
/* 114 */     System.out.println("getApproveAmount(" + getApproveAmount() + ")");
/* 115 */     System.out.println("getRefundAmount(" + getRefundAmount() + ")");
/* 116 */     this.log.info("@RetCode        = " + getRetCode());
/* 117 */     this.log.info("@OrderStatus    = " + getOrderStatus());
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.UPOPPayOther
 * JD-Core Version:    0.6.0
 */