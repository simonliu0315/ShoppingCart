/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.util.HiMerchant;
/*     */ import com.hitrust.b2ctoolkit.util.HiServer;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URLDecoder;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class TenpayAuth extends B2CPay
/*     */ {
/*     */   public void transaction()
/*     */   {
/*  23 */     boolean logflag = false;
/*     */     try {
/*  25 */       if (isEmpty(getStoreId())) {
/*  26 */         throw new ToolkitException("-32");
/*     */       }
/*  28 */       getHiMerchant();
/*  29 */       getLogger();
/*     */ 
/*  31 */       logflag = true;
/*     */ 
/*  33 */       this.log.info("----- New Tenpay Auth Start  -----");
/*  34 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*  35 */       this.log.info("[C]StoreID      = " + getStoreId());
/*     */ 
/*  38 */       setType("1");
/*  39 */       setWeight("0");
/*  40 */       setShip_fee_mode("0");
/*     */ 
/*  42 */       StringBuffer prodno = new StringBuffer();
/*  43 */       StringBuffer qty = new StringBuffer();
/*  44 */       String[] a = getItemNo();
/*  45 */       String[] q = getProdQty();
/*  46 */       for (int i = 0; i < getItemNo().length; i++) {
/*  47 */         prodno.append(a[i] + ",");
/*  48 */         qty.append(q[i] + ",");
/*     */       }
/*  50 */       setProdNo(prodno.toString());
/*  51 */       setQty(qty.toString());
/*     */ 
/*  53 */       checkData();
/*  54 */       this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/*  57 */       organizeMessage();
/*  58 */       this.log.info("Organize Message [ ok ].");
/*     */ 
/*  61 */       this.log.info("Send Message......");
/*  62 */       connectTo(HiServer.getTenpayAuthUrl());
/*  63 */       this.log.info("Receive Response [ ok ].");
/*     */ 
/*  66 */       parserResult();
/*  67 */       this.log.info("parsing Message [ ok ].");
/*     */ 
/*  69 */       this.log.info("----- New Tenpay Auth End  -----\n");
/*     */     } catch (ToolkitException e) {
/*  71 */       setRetCode(e.getMessage());
/*  72 */       if (logflag) {
/*  73 */         this.log.info("Run Error! Code ==" + getRetCode());
/*  74 */         this.log.info("----- New Tenpay Auth End  -----\n");
/*     */       }
/*     */     } catch (Exception e) {
/*  77 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkData() throws ToolkitException, Exception
/*     */   {
/*  83 */     if (isEmpty(getType())) {
/*  84 */       this.log.error("<Toolkit MSG> Input Parameter [TrxType] is wrong.");
/*  85 */       throw new ToolkitException("-45");
/*     */     }
/*     */ 
/*  88 */     if (isEmpty(getOrderNo())) {
/*  89 */       this.log.error("<Toolkit MSG> Input Parameter [ORDERNO] is null or empty.");
/*  90 */       throw new ToolkitException("-31");
/*     */     }
/*  92 */     this.log.info("[P]OrderNo      = " + getOrderNo());
/*     */ 
/*  95 */     if (isEmpty(getCurrency())) {
/*  96 */       if (isEmpty(this.hiMerchant.getCurrency())) {
/*  97 */         this.log.error("<Toolkit MSG> Input Parameter [CURRENCY] is null or empty.");
/*  98 */         throw new ToolkitException("-34");
/*     */       }
/* 100 */       setCurrency(this.hiMerchant.getCurrency());
/* 101 */       this.log.info("[C]Currency     = " + getCurrency());
/*     */     }
/*     */     else {
/* 104 */       this.log.info("[P]Currency     = " + getCurrency());
/*     */     }
/*     */ 
/* 107 */     if (isEmpty(getAmount())) {
/* 108 */       this.log.error("<Toolkit MSG> Input Parameter [AMOUNT] is null or empty.");
/* 109 */       throw new ToolkitException("-35");
/*     */     }
/* 111 */     this.log.info("[P]Amount       = " + getAmount());
/*     */ 
/* 114 */     if (isEmpty(getReturnURL())) {
/* 115 */       if (isEmpty(this.hiMerchant.getReturnURL())) {
/* 116 */         this.log.error("<Toolkit MSG> Input Parameter [RETURNURL] is null or empty.");
/* 117 */         throw new ToolkitException("-37");
/*     */       }
/* 119 */       setReturnURL(this.hiMerchant.getReturnURL());
/* 120 */       this.log.info("[C]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */     else {
/* 123 */       this.log.info("[P]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */ 
/* 126 */     if (isEmpty(getDepositFlag())) {
/* 127 */       if (isEmpty(this.hiMerchant.getDeposit())) {
/* 128 */         this.log.error("<Toolkit MSG> Input Parameter [DEPOSIT] is null or empty.");
/* 129 */         throw new ToolkitException("-38");
/*     */       }
/* 131 */       setDepositFlag(this.hiMerchant.getDeposit());
/* 132 */       this.log.info("[C]Deposit      = " + getDepositFlag());
/*     */     }
/*     */     else {
/* 135 */       this.log.info("[P]Deposit      = " + getDepositFlag());
/*     */     }
/*     */ 
/* 138 */     if (isEmpty(getUpdateURL())) {
/* 139 */       if (isEmpty(this.hiMerchant.getUpdateURL())) {
/* 140 */         this.log.error("<Toolkit MSG> Input Parameter [UPDATEURL] is null or empty.");
/* 141 */         throw new ToolkitException("-40");
/*     */       }
/* 143 */       setUpdateURL(this.hiMerchant.getUpdateURL());
/* 144 */       this.log.info("[C]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */     else {
/* 147 */       this.log.info("[P]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void organizeMessage() throws ToolkitException, Exception {
/* 152 */     String message = "";
/* 153 */     message = "T01=" + getType() + "&" + "T02=" + getOrderNo() + "&" + "T03=" + getStoreId() + "&" + "T05=" + getCurrency() + "&" + "T06=" + getAmount() + "&" + "T08=" + getReturnURL() + "&" + "T09=" + getDepositFlag() + "&" + "T11=" + getExtendField() + "&" + "T12=" + getUpdateURL() + "&" + "E43=" + getProdNo() + "&" + "E45=" + getQty() + "&" + "T15=" + getMerUpdateURL();
/*     */ 
/* 166 */     System.out.println(message);
/* 167 */     if (isEmpty(message)) {
/* 168 */       this.log.error("<Toolkit MSG> No Request Message.");
/* 169 */       throw new ToolkitException("-3");
/*     */     }
/* 171 */     setRequestMessage(message);
/*     */   }
/*     */ 
/*     */   private void parserResult() {
/* 175 */     System.out.println(getResponseMessage());
/* 176 */     setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/* 177 */     setToken(parsingKeyword(getResponseMessage(), "R24"));
/* 178 */     setHTML(URLDecoder.decode(parsingKeyword(getResponseMessage(), "R24")).trim());
/* 179 */     this.log.info("@RC             = " + getRetCode());
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 184 */     System.out.println(URLDecoder.decode(new B2CPay().parsingKeyword("R01=00&R03=&R04=&R25=&R24=+++++%3Chtml%3E%3Chead%3E%3Cmeta+http-equiv%3D%27Content-Type%27+content%3D%27text%2Fhtml%3B+charset%3Dutf-8%27%3E%3C%2Fhead%3E%3Cbody+%3E%3Cform+name%3D%27tenpay%27+id%3D%27tenpay%27+action%3D%27http%3A%2F%2Fskorder.arcrma.com%2Fcreate%27+method%3D%27post%27%3E%3Cinput+type%3D%27text%27+name%3D%27store%27+value%3D%2716313302A%27%3E+%3Cinput+type%3D%27text%27+name%3D%27channel%27+value%3D%27tenpay%27%3E+%3Cinput+type%3D%27text%27+name%3D%27pno%27+value%3D%27Ten0505_12%27+++%3E+++%3Cinput+type%3D%27text%27+name%3D%27amt%27+value%3D%27%23amt%23%27%3E+%3Cinput+type%3D%27text%27+name%3D%27return_url%27+value%3D%27%23return_url%23%27%3E+%3Cinput+type%3D%27text%27+name%3D%27pcode%27+value%3D%27911f39c3323ec4602058a7944de2f43e%27%3E+%3Cinput+type%3D%27text%27+name%3D%27count%27+value%3D%271%27%3E+%3Cinput+type%3D%27text%27+name%3D%27pid0%27++value%3D%27201503254457%27%3E+%3Cinput+type%3D%27text%27+name%3D%27qty0%27+value%3D%271%27%3E+%3Cinput+type%3D%27submit%27%3E+%3C%2Fform%3E%3C%2Fbody%3E%3Cscript%3Ethis.tenpay.submit%28%29%3B%3C%2Fscript%3E%3C%2Fhtml%3E", "R24")).trim());
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.TenpayAuth
 * JD-Core Version:    0.6.0
 */