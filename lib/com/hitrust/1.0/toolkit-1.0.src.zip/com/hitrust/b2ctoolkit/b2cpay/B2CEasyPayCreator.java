/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.util.HiServer;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.bouncycastle.util.encoders.Hex;
/*     */ 
/*     */ public class B2CEasyPayCreator extends B2CBase
/*     */ {
/*  18 */   private String email = null;
/*     */ 
/*  20 */   private String orderName = null;
/*  21 */   private Date startDate = null;
/*  22 */   private Date endDate = null;
/*     */ 
/*  24 */   private String easyPayLink = null;
/*     */ 
/*  27 */   private ArrayList rtn = new ArrayList();
/*     */ 
/*  29 */   private String installmentPlans = null;
/*     */ 
/*  32 */   private String noticeMail = null;
/*     */ 
/*     */   public String getInstallmentPlans()
/*     */   {
/*  37 */     return this.installmentPlans;
/*     */   }
/*     */ 
/*     */   public void setInstallmentPlans(String installmentPlans) {
/*  41 */     this.installmentPlans = installmentPlans;
/*     */   }
/*     */ 
/*     */   public String getNoticeMail() {
/*  45 */     return this.noticeMail;
/*     */   }
/*     */ 
/*     */   public void setNoticeMail(String noticeMail)
/*     */   {
/*  50 */     this.noticeMail = noticeMail;
/*     */   }
/*     */ 
/*     */   public B2CEasyPayCreator(String storeId)
/*     */   {
/*  55 */     super(storeId, "29");
/*     */   }
/*     */ 
/*     */   public String getEasyPayLink()
/*     */   {
/*  60 */     return this.easyPayLink;
/*     */   }
/*     */ 
/*     */   public ArrayList getEasyPayDetailList() {
/*  64 */     return this.rtn;
/*     */   }
/*     */ 
/*     */   protected void handleResponse(HashMap tagsFromResponse) throws Exception
/*     */   {
/*  69 */     this.log.info("----- B2CEasyPay handleResponse -----");
/*     */ 
/*  71 */     this.easyPayLink = new String(Hex.decode((String)tagsFromResponse.get("S04")));
/*  72 */     String mail_and_tokens = (String)tagsFromResponse.get("T16");
/*     */ 
/*  74 */     B2CEasyPayUtility.parseOrderLinesTo(mail_and_tokens, this.rtn);
/*     */   }
/*     */ 
/*     */   private void checkData()
/*     */     throws ToolkitException, Exception
/*     */   {
/*  83 */     if ((getInstallmentPlans().trim() != null) && (getInstallmentPlans().trim().length() > 0)) {
/*  84 */       String[] tmp = getInstallmentPlans().split(",");
/*  85 */       if (tmp.length > 0) {
/*     */         try
/*     */         {
/*     */           int currentTmp;
/*  87 */           for (int i = 0; i < tmp.length; i++)
/*     */           {
/*  89 */             currentTmp = Integer.parseInt(tmp[i]);
/*     */           }
/*     */         } catch (Exception e) {
/*  92 */           this.log.error("<Toolkit MSG> installment plan format error.");
/*  93 */           throw new ToolkitException("-82");
/*     */         }
/*     */       }
/*     */     }
/*  97 */     if (this.email.trim().length() == 0) {
/*  98 */       this.email = null;
/*     */     }
/* 100 */     if (this.installmentPlans.trim().length() == 0) {
/* 101 */       this.installmentPlans = null;
/*     */     }
/* 103 */     if (this.noticeMail.trim().length() == 0) {
/* 104 */       this.noticeMail = null;
/*     */     }
/* 106 */     if ((getDepositFlag() == null) || (getDepositFlag().length() == 0) || ("null".equals(getDepositFlag())))
/* 107 */       setDepositFlag("1");
/*     */   }
/*     */ 
/*     */   protected void prepareData(HashMap tagsForSend)
/*     */     throws ToolkitException
/*     */   {
/* 116 */     this.log.info("----- B2CEasyPay prepareData -----");
/*     */     try
/*     */     {
/* 119 */       checkData();
/*     */     } catch (Exception e) {
/* 121 */       this.log.error("<Toolkit MSG> installment plan format error.");
/* 122 */       throw new ToolkitException("-82");
/*     */     }
/*     */ 
/* 127 */     this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/* 128 */     this.log.info("[C]StoreID      = " + getStoreId());
/*     */ 
/* 130 */     this.log.info("[P]EMail      = " + this.email);
/* 131 */     if (isEmpty(this.email)) {
/* 132 */       this.log.error("<Toolkit MSG> Input Parameter [EMAIL] is null or empty.");
/* 133 */       throw new ToolkitException("-48");
/*     */     }
/*     */ 
/* 136 */     this.log.info("[P]OrderName  = " + this.orderName);
/* 137 */     if (isEmpty(this.orderName)) {
/* 138 */       this.log.error("-49");
/* 139 */       throw new ToolkitException("<Toolkit MSG> Input Parameter [ORDER_NAME] is invalid.");
/*     */     }
/* 141 */     if (this.orderName.getBytes().length > 20) {
/* 142 */       this.log.error("-49");
/* 143 */       throw new ToolkitException("<Toolkit MSG> Input Parameter [ORDER_NAME] is invalid.");
/*     */     }
/*     */ 
/* 146 */     this.log.info("[P]Amount     = " + getAmount());
/*     */     try {
/* 148 */       int amount = Integer.parseInt(getAmount());
/*     */ 
/* 150 */       if (amount <= 0) {
/* 151 */         this.log.error("-80");
/* 152 */         throw new ToolkitException("<Toolkit MSG> Input account verify amount error.");
/*     */       }
/*     */     } catch (Throwable th) {
/* 155 */       this.log.error("-80", th);
/* 156 */       throw new ToolkitException("<Toolkit MSG> Input account verify amount error.");
/*     */     }
/*     */ 
/* 160 */     this.log.info("[P]orderDesc  = " + getOrderDesc());
/* 161 */     if ((getOrderDesc() != null) && (getOrderDesc().length() > 500))
/*     */     {
/* 163 */       this.log.error("-81");
/* 164 */       throw new ToolkitException("<Toolkit MSG> Input order description is invalid.");
/*     */     }
/* 166 */     this.log.info("[P]InstallmentPlans  = " + getInstallmentPlans());
/* 167 */     this.log.info("[P]noticMail  = " + getNoticeMail());
/* 168 */     this.log.info("[P]updateURL  = " + getUpdateURL());
/* 169 */     this.log.info("[P]DepositFlag  = " + getDepositFlag());
/* 170 */     this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/* 172 */     SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
/*     */ 
/* 176 */     tagsForSend.put("T03", getStoreId());
/*     */     try {
/* 178 */       tagsForSend.put("E44", changeEncodingAndConvertToHex(this.orderName));
/*     */ 
/* 180 */       tagsForSend.put("T04", changeEncodingAndConvertToHex(getOrderDesc()));
/*     */ 
/* 182 */       tagsForSend.put("T12", getUpdateURL());
/*     */ 
/* 184 */       tagsForSend.put("E66", getNoticeMail());
/*     */     }
/*     */     catch (Throwable th) {
/* 187 */       this.log.error("convert to HEX failed: " + th.getMessage());
/* 188 */       throw new ToolkitException("-8");
/*     */     }
/* 190 */     tagsForSend.put("T09", getDepositFlag());
/* 191 */     tagsForSend.put("T06", getAmount());
/* 192 */     if (this.startDate == null)
/*     */     {
/* 194 */       tagsForSend.put("E63", "0");
/*     */ 
/* 196 */       tagsForSend.put("E17", "0");
/*     */     } else {
/* 198 */       tagsForSend.put("E63", sdf.format(this.startDate));
/* 199 */       tagsForSend.put("E17", sdf.format(this.endDate));
/*     */     }
/*     */ 
/* 202 */     tagsForSend.put("E16", this.email);
/* 203 */     tagsForSend.put("E03", getInstallmentPlans());
/* 204 */     tagsForSend.put("E66", getNoticeMail());
/* 205 */     this.log.info("[P]E03     = " + getInstallmentPlans());
/* 206 */     this.log.info("[P]E66     = " + getNoticeMail());
/*     */   }
/*     */ 
/*     */   public void setAvailableDate(Date startDate, Date endDate) {
/* 210 */     this.startDate = startDate;
/* 211 */     this.endDate = endDate;
/*     */   }
/*     */ 
/*     */   public void setEmailAddress(String email) {
/* 215 */     this.email = email;
/*     */   }
/*     */ 
/*     */   public void setOrderName(String orderName) {
/* 219 */     if ((orderName == null) || (orderName.length() > 20))
/* 220 */       throw new IllegalArgumentException("the size of orderName is longer than 20");
/* 221 */     this.orderName = orderName;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void setOrderNo(String hideIt) {
/*     */   }
/*     */ 
/*     */   protected String getConnectTargetURL() throws ToolkitException {
/* 230 */     return HiServer.getOtherUrl();
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.B2CEasyPayCreator
 * JD-Core Version:    0.6.0
 */