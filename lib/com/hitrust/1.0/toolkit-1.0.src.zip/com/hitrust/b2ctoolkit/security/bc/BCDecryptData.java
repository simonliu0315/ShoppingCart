/*     */ package com.hitrust.b2ctoolkit.security.bc;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.security.SecurityUtil;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import com.hitrust.regional.tool.ByteUtil;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.Security;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.CipherInputStream;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ import org.bouncycastle.jce.provider.BouncyCastleProvider;
/*     */ 
/*     */ public class BCDecryptData
/*     */ {
/*     */   public BCDecryptData()
/*     */   {
/*  28 */     if (Security.getProvider("BC") == null)
/*  29 */       Security.addProvider(new BouncyCastleProvider());
/*     */   }
/*     */ 
/*     */   public static String exceptionToString(Throwable th)
/*     */   {
/*  34 */     StringWriter sw = new StringWriter();
/*  35 */     PrintWriter pw = new PrintWriter(sw);
/*  36 */     th.printStackTrace(pw);
/*  37 */     return sw.toString();
/*     */   }
/*     */ 
/*     */   public static String decrypt(String strCipher, String strEncKey, String strMAC, String strPrivateKeyFileName, String strPubKeyFileName) throws Exception
/*     */   {
/*  42 */     byte[] bytesEncKey = null;
/*  43 */     byte[] bytesRC4Key = null;
/*  44 */     byte[] bytesCipher = null;
/*  45 */     byte[] bytesOriginalData = null;
/*  46 */     byte[] bytesMAC = null;
/*     */     try
/*     */     {
/*  50 */       if (Security.getProvider("BC") == null) {
/*  51 */         Security.addProvider(new BouncyCastleProvider());
/*     */       }
/*     */ 
/*  55 */       bytesEncKey = ByteUtil.hexStr2Bytes(strEncKey);
/*     */ 
/*  60 */       bytesRC4Key = new byte[16];
/*     */ 
/*  62 */       Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding", "BC");
/*  63 */       cipher.init(2, SecurityUtil.loadPKCS8DERPrivKey(strPrivateKeyFileName));
/*     */ 
/*  65 */       ByteArrayInputStream bytesInput = new ByteArrayInputStream(bytesEncKey);
/*  66 */       CipherInputStream cipherInput = new CipherInputStream(bytesInput, cipher);
/*     */ 
/*  68 */       DataInputStream dIn = new DataInputStream(cipherInput);
/*  69 */       dIn.readFully(bytesRC4Key);
/*  70 */       dIn.close();
/*  71 */       cipherInput.close();
/*     */     }
/*     */     catch (Exception e) {
/*  74 */       throw new ToolkitException("-27");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  79 */       SecretKeySpec rc4Key = new SecretKeySpec(bytesRC4Key, "RC4");
/*  80 */       bytesCipher = ByteUtil.hexStr2Bytes(strCipher);
/*     */ 
/*  82 */       Cipher cipher = Cipher.getInstance("RC4", "BC");
/*  83 */       cipher.init(2, rc4Key);
/*  84 */       ByteArrayInputStream bytesInput = new ByteArrayInputStream(bytesCipher);
/*     */ 
/*  86 */       CipherInputStream cipherInput = new CipherInputStream(bytesInput, cipher);
/*     */ 
/*  88 */       DataInputStream dIn = new DataInputStream(cipherInput);
/*  89 */       dIn.readFully(bytesCipher);
/*  90 */       dIn.close();
/*  91 */       cipherInput.close();
/*  92 */       bytesOriginalData = bytesCipher;
/*     */     }
/*     */     catch (Exception e) {
/*  95 */       throw new ToolkitException("-17");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 100 */       String strData = new String(bytesOriginalData);
/*     */ 
/* 102 */       bytesMAC = ByteUtil.hexStr2Bytes(strMAC);
/* 103 */       Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding", "BC");
/* 104 */       cipher.init(2, SecurityUtil.loadX509DERPublicKey(strPubKeyFileName));
/* 105 */       byte[] newMD = cipher.doFinal(bytesMAC);
/*     */ 
/* 108 */       byte[] bytesOriginal = new byte[16];
/*     */ 
/* 110 */       ByteArrayInputStream bytesInput = new ByteArrayInputStream(newMD);
/* 111 */       DataInputStream dIn = new DataInputStream(bytesInput);
/* 112 */       dIn.readFully(bytesOriginal);
/* 113 */       dIn.close();
/* 114 */       bytesInput.close();
/*     */ 
/* 116 */       MessageDigest digest = MessageDigest.getInstance("MD5");
/* 117 */       digest.update(strData.getBytes());
/* 118 */       byte[] oldMD = digest.digest();
/*     */ 
/* 121 */       if (ByteUtil.bytes2HexStr(bytesOriginal).equals(ByteUtil.bytes2HexStr(oldMD))) {
/* 122 */         return strData;
/*     */       }
/*     */ 
/* 125 */       throw new ToolkitException("-17");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 129 */       e.printStackTrace();
/* 130 */       System.out.println(e.toString());
/* 131 */     }throw new ToolkitException("-23");
/*     */   }
/*     */ 
/*     */   public static String prodLstdecrypt(String strCipher, String strEncKey, String strMAC, String strPrivateKeyFileName, String strPubKeyFileName)
/*     */     throws Exception
/*     */   {
/* 137 */     byte[] bytesEncKey = null;
/* 138 */     byte[] bytesRC4Key = null;
/* 139 */     byte[] bytesCipher = null;
/* 140 */     byte[] bytesOriginalData = null;
/* 141 */     byte[] bytesMAC = null;
/*     */     try
/*     */     {
/* 145 */       if (Security.getProvider("BC") == null) {
/* 146 */         Security.addProvider(new BouncyCastleProvider());
/*     */       }
/*     */ 
/* 150 */       bytesEncKey = ByteUtil.hexStr2Bytes(strEncKey);
/*     */ 
/* 155 */       bytesRC4Key = new byte[16];
/*     */ 
/* 157 */       Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding", "BC");
/* 158 */       cipher.init(2, SecurityUtil.loadPKCS8DERPrivKey(strPrivateKeyFileName));
/*     */ 
/* 160 */       ByteArrayInputStream bytesInput = new ByteArrayInputStream(bytesEncKey);
/* 161 */       CipherInputStream cipherInput = new CipherInputStream(bytesInput, cipher);
/*     */ 
/* 163 */       DataInputStream dIn = new DataInputStream(cipherInput);
/* 164 */       dIn.readFully(bytesRC4Key);
/* 165 */       dIn.close();
/* 166 */       cipherInput.close();
/*     */     }
/*     */     catch (Exception e) {
/* 169 */       throw new ToolkitException("-27");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 174 */       SecretKeySpec rc4Key = new SecretKeySpec(bytesRC4Key, "RC4");
/* 175 */       bytesCipher = ByteUtil.hexStr2Bytes(strCipher);
/*     */ 
/* 177 */       Cipher cipher = Cipher.getInstance("RC4", "BC");
/* 178 */       cipher.init(2, rc4Key);
/* 179 */       ByteArrayInputStream bytesInput = new ByteArrayInputStream(bytesCipher);
/*     */ 
/* 181 */       CipherInputStream cipherInput = new CipherInputStream(bytesInput, cipher);
/*     */ 
/* 183 */       DataInputStream dIn = new DataInputStream(cipherInput);
/* 184 */       dIn.readFully(bytesCipher);
/* 185 */       dIn.close();
/* 186 */       cipherInput.close();
/* 187 */       bytesOriginalData = bytesCipher;
/*     */     }
/*     */     catch (Exception e) {
/* 190 */       throw new ToolkitException("-17");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 195 */       String strData = new String(bytesOriginalData);
/*     */ 
/* 197 */       return strData;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 201 */       e.printStackTrace();
/* 202 */       System.out.println(e.toString());
/* 203 */     }throw new ToolkitException("-23");
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.security.bc.BCDecryptData
 * JD-Core Version:    0.6.0
 */