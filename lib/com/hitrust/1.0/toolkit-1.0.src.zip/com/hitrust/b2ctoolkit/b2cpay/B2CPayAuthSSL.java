/*     */ package com.hitrust.b2ctoolkit.b2cpay;
/*     */ 
/*     */ import com.hitrust.b2ctoolkit.util.HiMerchant;
/*     */ import com.hitrust.b2ctoolkit.util.HiServer;
/*     */ import com.hitrust.b2ctoolkit.util.ToolkitException;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class B2CPayAuthSSL extends B2CPay
/*     */ {
/*     */   public void transaction()
/*     */   {
/*  29 */     boolean logflag = false;
/*     */     try {
/*  31 */       if (isEmpty(getStoreId())) {
/*  32 */         throw new ToolkitException("-32");
/*     */       }
/*  34 */       getHiMerchant();
/*     */ 
/*  36 */       getLogger();
/*     */ 
/*  38 */       logflag = true;
/*     */ 
/*  40 */       this.log.info("----- New AuthSSL Start  -----");
/*  41 */       this.log.info("@@ HiTRUST B2C Payment ToolKit (Java) V3.0.8.20180201.1637.50 @@");
/*     */ 
/*  45 */       setType("1");
/*     */ 
/*  48 */       checkData();
/*  49 */       this.log.info("Check Input Parameter [ ok ].");
/*     */ 
/*  52 */       organizeMessage();
/*  53 */       this.log.info("Organize Message [ ok ].");
/*     */ 
/*  56 */       this.log.info("Send Message......");
/*  57 */       connectTo(HiServer.getOtherUrl());
/*  58 */       this.log.info("Receive Response [ ok ].");
/*     */ 
/*  61 */       parserResult();
/*  62 */       this.log.info("parsing Message [ ok ].");
/*     */ 
/*  64 */       this.log.info("----- New AuthSSL End  -----\n");
/*     */     } catch (ToolkitException e) {
/*  66 */       setRetCode(e.getMessage());
/*  67 */       if (logflag) {
/*  68 */         this.log.info("Run Error! Code ==" + getRetCode());
/*  69 */         this.log.info("----- New AuthSSL End  -----\n");
/*     */       }
/*     */     } catch (Exception e) {
/*  72 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkData() throws ToolkitException, Exception
/*     */   {
/*  78 */     if (isEmpty(getType())) {
/*  79 */       this.log.error("<Toolkit MSG> Input Parameter [TrxType] is wrong.");
/*  80 */       throw new ToolkitException("-45");
/*     */     }
/*     */ 
/*  83 */     if (isEmpty(getOrderNo())) {
/*  84 */       this.log.error("<Toolkit MSG> Input Parameter [ORDERNO] is null or empty.");
/*  85 */       throw new ToolkitException("-31");
/*     */     }
/*  87 */     this.log.info("[P]OrderNo      = " + getOrderNo());
/*     */ 
/*  90 */     if (isEmpty(getOrderDesc())) {
/*  91 */       if (isEmpty(this.hiMerchant.getOrderDesc())) {
/*  92 */         this.log.error("<Toolkit MSG> Input Parameter [ORDERDESC] is null or empty.");
/*  93 */         throw new ToolkitException("-33");
/*     */       }
/*  95 */       setOrderDesc(this.hiMerchant.getOrderDesc());
/*  96 */       this.log.info("[C]OrderDesc    = " + getOrderDesc());
/*     */     }
/*     */     else {
/*  99 */       this.log.info("[P]OrderDesc    = " + getOrderDesc());
/*     */     }
/*     */ 
/* 102 */     if (isEmpty(getCurrency())) {
/* 103 */       if (isEmpty(this.hiMerchant.getCurrency())) {
/* 104 */         this.log.error("<Toolkit MSG> Input Parameter [CURRENCY] is null or empty.");
/* 105 */         throw new ToolkitException("-34");
/*     */       }
/* 107 */       setCurrency(this.hiMerchant.getCurrency());
/* 108 */       this.log.info("[C]Currency     = " + getCurrency());
/*     */     }
/*     */     else {
/* 111 */       this.log.info("[P]Currency     = " + getCurrency());
/*     */     }
/*     */ 
/* 114 */     if (isEmpty(getAmount())) {
/* 115 */       this.log.error("<Toolkit MSG> Input Parameter [AMOUNT] is null or empty.");
/* 116 */       throw new ToolkitException("-35");
/*     */     }
/* 118 */     this.log.info("[P]Amount       = " + getAmount());
/*     */ 
/* 121 */     if ((!"".equals(getE59())) && (getE59() != null) && ("1".equals(getE59())) && 
/* 122 */       (!"000".equals(getAmount()))) {
/* 123 */       this.log.error("<Toolkit MSG> Input account verify amount error.");
/* 124 */       throw new ToolkitException("-80");
/*     */     }
/*     */ 
/* 128 */     if (isEmpty(getReturnURL())) {
/* 129 */       if (isEmpty(this.hiMerchant.getReturnURL())) {
/* 130 */         this.log.error("<Toolkit MSG> Input Parameter [RETURNURL] is null or empty.");
/* 131 */         throw new ToolkitException("-37");
/*     */       }
/* 133 */       setReturnURL(this.hiMerchant.getReturnURL());
/* 134 */       this.log.info("[C]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */     else {
/* 137 */       this.log.info("[P]ReturnURL    = " + getReturnURL());
/*     */     }
/*     */ 
/* 140 */     if (isEmpty(getDepositFlag())) {
/* 141 */       if (isEmpty(this.hiMerchant.getDeposit())) {
/* 142 */         this.log.error("<Toolkit MSG> Input Parameter [DEPOSIT] is null or empty.");
/* 143 */         throw new ToolkitException("-38");
/*     */       }
/* 145 */       setDepositFlag(this.hiMerchant.getDeposit());
/* 146 */       this.log.info("[C]Deposit      = " + getDepositFlag());
/*     */     }
/*     */     else {
/* 149 */       this.log.info("[P]Deposit      = " + getDepositFlag());
/*     */     }
/*     */ 
/* 152 */     if (isEmpty(getQueryFlag())) {
/* 153 */       if (isEmpty(this.hiMerchant.getQueryFlag())) {
/* 154 */         this.log.error("<Toolkit MSG> Input Parameter [QUERYFLAG] is null or empty.");
/* 155 */         throw new ToolkitException("-39");
/*     */       }
/* 157 */       setQueryFlag(this.hiMerchant.getQueryFlag());
/* 158 */       this.log.info("[C]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */     else {
/* 161 */       this.log.info("[P]QueryFlag    = " + getQueryFlag());
/*     */     }
/*     */ 
/* 164 */     if (isEmpty(getUpdateURL())) {
/* 165 */       if (isEmpty(this.hiMerchant.getUpdateURL())) {
/* 166 */         this.log.error("<Toolkit MSG> Input Parameter [UPDATEURL] is null or empty.");
/* 167 */         throw new ToolkitException("-40");
/*     */       }
/* 169 */       setUpdateURL(this.hiMerchant.getUpdateURL());
/* 170 */       this.log.info("[C]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */     else {
/* 173 */       this.log.info("[P]UpdateURL    = " + getUpdateURL());
/*     */     }
/*     */ 
/* 177 */     if (getTicketNo() == null) setTicketNo("");
/* 178 */     if (getPan() == null) setPan("");
/* 179 */     if (getExpiry() == null) setExpiry("");
/* 180 */     if (getE01() == null) setE01("");
/* 181 */     if (getE02() == null) setE02("");
/* 182 */     if (getE03() == null) setE03("");
/* 183 */     if (getE04() == null) setE04("");
/* 184 */     if (getE05() == null) setE05("");
/* 185 */     if (getE11() == null) setE11("");
/* 186 */     if (getE12() == null) setE12("");
/* 187 */     if (getE13() == null) setE13("");
/* 188 */     if (getE14() == null) setE14("");
/* 189 */     if (getE36() == null) setE36("");
/* 190 */     if (getE37() == null) setE37("");
/* 191 */     if (getE38() == null) setE38("");
/* 192 */     if (getE39() == null) setE39("");
/* 193 */     if (getE40() == null) setE40("");
/* 194 */     if (getE41() == null) setE41("");
/* 195 */     if (getE42() == null) setE42("");
/* 196 */     if (getE52() == null) setE52("");
/* 197 */     if (getE53() == null) setE53("");
/* 198 */     if (getE54() == null) setE54("");
/* 199 */     if (getE56() == null) setE56("");
/* 200 */     if (getE57() == null) setE57("");
/* 201 */     if (getE58() == null) setE58("");
/* 202 */     if (getE59() == null) setE59("");
/*     */ 
/* 204 */     this.log.info("[P]TicketNo     = " + getTicketNo());
/*     */ 
/* 216 */     if ((!isEmpty(getE36())) && 
/* 217 */       (getE36().length() > 10)) {
/* 218 */       this.log.error("<Toolkit MSG> Input Parameter [ID] is null or empty or format error.");
/* 219 */       throw new ToolkitException("-60");
/*     */     }
/* 221 */     if ((!isEmpty(getE37())) && 
/* 222 */       (getE37().length() > 15)) {
/* 223 */       this.log.error("<Toolkit MSG> Input Parameter [CELLPHONE] is null or empty or length error.");
/* 224 */       throw new ToolkitException("-61");
/*     */     }
/*     */ 
/* 227 */     if (!isEmpty(getE38())) {
/* 228 */       if (getE38().length() != 4) {
/* 229 */         this.log.error("<Toolkit MSG> Input Parameter [YEAR_OF_BIRTH] is null or empty or length error.");
/* 230 */         throw new ToolkitException("-62");
/* 231 */       }if (getE39().length() == 0) {
/* 232 */         this.log.error("<Toolkit MSG> Input Parameter [MMDD_OF_BIRTH] is null or empty or length error.");
/* 233 */         throw new ToolkitException("-63");
/*     */       }
/*     */     }
/*     */ 
/* 237 */     if (!isEmpty(getE39())) {
/* 238 */       if (getE39().length() != 4) {
/* 239 */         this.log.error("<Toolkit MSG> Input Parameter [MMDD_OF_BIRTH] is null or empty or length error.");
/* 240 */         throw new ToolkitException("-63");
/* 241 */       }if (getE38().length() == 0) {
/* 242 */         this.log.error("<Toolkit MSG> Input Parameter [YEAR_OF_BIRTH] is null or empty or length error.");
/* 243 */         throw new ToolkitException("-62");
/*     */       }
/*     */     }
/* 245 */     if ((!"".equals(getE40())) && (null != getE40()) && 
/* 246 */       (getE40().length() > 15)) {
/* 247 */       this.log.error("<Toolkit MSG> Input Parameter [HomePHONE] is null or empty or length error.");
/* 248 */       throw new ToolkitException("-64");
/*     */     }
/*     */ 
/* 251 */     if ((!"".equals(getE41())) && (null != getE41()) && 
/* 252 */       (getE41().length() > 15)) {
/* 253 */       this.log.error("<Toolkit MSG> Input Parameter [OfficePHONE] is null or empty or length error.");
/* 254 */       throw new ToolkitException("-65");
/*     */     }
/*     */ 
/* 257 */     if ("Y".equalsIgnoreCase(getE42()))
/*     */     {
/* 259 */       if (("".equals(getE36().trim())) && ("".equals(getE37().trim())) && ("".equals(getE38().trim())) && ("".equals(getE39().trim())) && ("".equals(getE40().trim())) && ("".equals(getE41().trim()))) {
/* 260 */         this.log.error("<Toolkit MSG> Input Parameter all is blank for identifying.");
/* 261 */         throw new ToolkitException("-66");
/*     */       }
/* 263 */       if ("1".equals(getDepositFlag())) {
/* 264 */         this.log.error("<Toolkit MSG> Input Parameter only for identifying cannot with depositeflag.");
/* 265 */         throw new ToolkitException("-67");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 272 */     if (!isEmpty(getE52()))
/*     */     {
/* 275 */       if (getE52().matches("[0-9]{8}"))
/*     */       {
/* 278 */         if (!isEmpty(getE53()))
/*     */         {
/* 280 */           if (!getE53().matches("[0-9]{4}"))
/*     */           {
/* 282 */             this.log.error("<Toolkit MSG> Input Parameter [E54] format error.");
/* 283 */             throw new ToolkitException("-74");
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 288 */           this.log.error("<Toolkit MSG> Input Parameter [E53] is null or empty.");
/* 289 */           throw new ToolkitException("-73");
/*     */         }
/*     */ 
/* 293 */         if (!isEmpty(getE54()))
/*     */         {
/* 295 */           if (getE54().length() > 10)
/*     */           {
/* 297 */             this.log.error("<Toolkit MSG> Input Parameter [E54] format error.");
/* 298 */             throw new ToolkitException("-74");
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 303 */           this.log.error("<Toolkit MSG> Input Parameter [E54] is null or empty.");
/* 304 */           throw new ToolkitException("-75");
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 309 */         this.log.error("<Toolkit MSG> Input Parameter [E52] format error.");
/* 310 */         throw new ToolkitException("-72");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 317 */     if ((!isEmpty(getE56())) && (isInteger(getE56()))) {
/* 318 */       if ((isEmpty(getE57())) || (getE57().length() > 6)) {
/* 319 */         this.log.error("<Toolkit MSG> Input Parameter [E57] format error.,E57=" + getE57());
/* 320 */         throw new ToolkitException("-78");
/*     */       }
/* 322 */       if ((isEmpty(getE58())) || ((!"D".equals(getE58())) && (!"W".equals(getE58())) && (!"M".equals(getE58())) && (!"Y".equals(getE58())))) {
/* 323 */         this.log.error("<Toolkit MSG> Input Parameter [E58] format error.,E58=" + getE58());
/* 324 */         throw new ToolkitException("-79");
/*     */       }
/* 326 */     } else if ((!isEmpty(getE56())) && (!isInteger(getE56()))) {
/* 327 */       this.log.error("-77,E56=" + getE56());
/* 328 */       throw new ToolkitException("-78");
/*     */     }
/*     */ 
/* 332 */     this.log.info("[P]E02          = " + getE02());
/* 333 */     this.log.info("[P]E03          = " + getE03());
/* 334 */     this.log.info("[P]E04          = " + getE04());
/* 335 */     this.log.info("[P]E05          = " + getE05());
/*     */ 
/* 337 */     this.log.info("[P]E11          = " + getE11());
/* 338 */     this.log.info("[P]E12          = " + getE12());
/* 339 */     this.log.info("[P]E13          = " + getE13());
/* 340 */     this.log.info("[P]E14          = " + getE14());
/*     */ 
/* 342 */     this.log.info("[P]E15          = " + getName());
/* 343 */     this.log.info("[P]E16          = " + getEmail());
/* 344 */     this.log.info("[P]E17          = " + getE17());
/*     */ 
/* 355 */     this.log.info("[P]E52          = " + getE52());
/* 356 */     this.log.info("[P]E53          = " + getE53());
/* 357 */     this.log.info("[P]E54          = " + getE54());
/* 358 */     this.log.info("[P]E56          = " + getE56());
/* 359 */     this.log.info("[P]E57          = " + getE57());
/* 360 */     this.log.info("[P]E58          = " + getE58());
/* 361 */     this.log.info("[P]E59          = " + getE59());
/*     */   }
/*     */ 
/*     */   private void organizeMessage() throws ToolkitException, Exception {
/* 365 */     String message = "";
/* 366 */     message = "T01=" + getType() + "&" + "T02=" + getOrderNo() + "&" + "T03=" + getStoreId() + "&" + "T04=" + getOrderDesc() + "&" + "T05=" + getCurrency() + "&" + "T06=" + getAmount() + "&" + "T08=" + getReturnURL() + "&" + "T09=" + getDepositFlag() + "&" + "T10=" + getQueryFlag() + "&" + "T11=" + getExtendField() + "&" + "T12=" + getUpdateURL() + "&" + "T13=" + getPan() + "&" + "T14=" + getExpiry() + "&" + "T15=" + getMerUpdateURL() + "&" + "O01=" + getTicketNo() + "&" + "E01=" + getE01() + "&" + "E02=" + getE02() + "&" + "E03=" + getE03() + "&" + "E04=" + getE04() + "&" + "E05=" + getE05() + "&" + "E11=" + getE11() + "&" + "E12=" + getE12() + "&" + "E13=" + getE13() + "&" + "E14=" + getE14() + "&" + "E15=" + getName() + "&" + "E16=" + getEmail() + "&" + "E17=" + getE17() + "&" + "E36=" + getE36() + "&" + "E37=" + getE37() + "&" + "E38=" + getE38() + "&" + "E39=" + getE39() + "&" + "E40=" + getE40() + "&" + "E41=" + getE41() + "&" + "E42=" + getE42() + "&" + "E52=" + getE52() + "&" + "E53=" + getE53() + "&" + "E54=" + getE54() + "&" + "E55=" + getE55() + "&" + "E56=" + getE56() + "&" + "E57=" + getE57() + "&" + "E58=" + getE58() + "&" + "E59=" + getE59();
/*     */ 
/* 411 */     if (isEmpty(message)) {
/* 412 */       this.log.error("<Toolkit MSG> No Request Message.");
/* 413 */       throw new ToolkitException("-3");
/*     */     }
/* 415 */     setRequestMessage(message);
/*     */   }
/*     */ 
/*     */   private void parserResult() {
/* 419 */     setRetCode(parsingKeyword(getResponseMessage(), "R01"));
/* 420 */     setOrderDesc(parsingKeyword(getResponseMessage(), "T04"));
/* 421 */     setCurrency(parsingKeyword(getResponseMessage(), "T05"));
/* 422 */     if (getQueryFlag().equals("1")) {
/* 423 */       setSecCode(parsingKeyword(getResponseMessage(), "R02"));
/* 424 */       setAuthCode(parsingKeyword(getResponseMessage(), "R03"));
/* 425 */       setAuthRRN(parsingKeyword(getResponseMessage(), "R04"));
/* 426 */       setOrderStatus(parsingKeyword(getResponseMessage(), "R05"));
/* 427 */       setCreditStatus(parsingKeyword(getResponseMessage(), "R06"));
/* 428 */       setAcquirer(parsingKeyword(getResponseMessage(), "R07"));
/* 429 */       setCardType(parsingKeyword(getResponseMessage(), "R08"));
/* 430 */       setApproveAmount(parsingKeyword(getResponseMessage(), "R09"));
/* 431 */       setCaptureAmount(parsingKeyword(getResponseMessage(), "R10"));
/* 432 */       setCaptureNum(parsingKeyword(getResponseMessage(), "R11"));
/* 433 */       setRefundAmount(parsingKeyword(getResponseMessage(), "R12"));
/* 434 */       setRefundNum(parsingKeyword(getResponseMessage(), "R13"));
/* 435 */       setOrderDate(parsingKeyword(getResponseMessage(), "R14"));
/* 436 */       setPayBatchNum(parsingKeyword(getResponseMessage(), "R15"));
/* 437 */       setCaptureCode(parsingKeyword(getResponseMessage(), "R16"));
/* 438 */       setCaptureDate(parsingKeyword(getResponseMessage(), "R17"));
/* 439 */       setPaymentNum(parsingKeyword(getResponseMessage(), "R18"));
/* 440 */       setRefundBatch(parsingKeyword(getResponseMessage(), "R20"));
/* 441 */       setRefundCode(parsingKeyword(getResponseMessage(), "R21"));
/* 442 */       setRefundRRN(parsingKeyword(getResponseMessage(), "R22"));
/* 443 */       setRefundDate(parsingKeyword(getResponseMessage(), "R23"));
/* 444 */       setToken(parsingKeyword(getResponseMessage(), "R24"));
/* 445 */       setEci(parsingKeyword(getResponseMessage(), "R25"));
/*     */ 
/* 450 */       setE28(parsingKeyword(getResponseMessage(), "E28"));
/* 451 */       setE29(parsingKeyword(getResponseMessage(), "E29"));
/*     */ 
/* 453 */       setRedemordernum(parsingKeyword(getResponseMessage(), "R28"));
/* 454 */       setRedem_discount_point(parsingKeyword(getResponseMessage(), "R29"));
/* 455 */       setRedem_discount_amount(parsingKeyword(getResponseMessage(), "R30"));
/* 456 */       setRedem_purchase_amount(parsingKeyword(getResponseMessage(), "R31"));
/* 457 */       setRedem_balance_point(parsingKeyword(getResponseMessage(), "R32"));
/*     */     }
/*     */ 
/* 460 */     this.log.info("@RC             = " + getRetCode());
/* 461 */     this.log.info("@Token          = " + getToken());
/* 462 */     this.log.info("@E06            = " + getE06());
/* 463 */     this.log.info("@E07            = " + getE07());
/* 464 */     this.log.info("@E08            = " + getE08());
/* 465 */     this.log.info("@E09            = " + getE09());
/* 466 */     this.log.info("@E10            = " + getE10());
/* 467 */     this.log.info("@AuthCode       = " + getAuthCode());
/* 468 */     this.log.info("@AuthRRN        = " + getAuthRRN());
/* 469 */     this.log.info("@CardType       = " + getCardType());
/* 470 */     this.log.info("@OrderStatus    = " + getOrderStatus());
/* 471 */     this.log.info("@Acquirer       = " + getAcquirer());
/* 472 */     this.log.info("@ApproveAmount  = " + getApproveAmount());
/* 473 */     this.log.info("@CaptureAmount  = " + getCaptureAmount());
/* 474 */     this.log.info("@RefundAmount   = " + getRefundAmount());
/* 475 */     this.log.info("@OrderDate      = " + getOrderDate());
/* 476 */     this.log.info("@PayBatchNum    = " + getPayBatchNum());
/* 477 */     this.log.info("@CaptureDate    = " + getCaptureDate());
/* 478 */     this.log.info("@RefundBatch    = " + getRefundBatch());
/* 479 */     this.log.info("@RefundCode     = " + getRefundCode());
/* 480 */     this.log.info("@RefundRRN      = " + getRefundRRN());
/* 481 */     this.log.info("@RefundDate     = " + getRefundDate());
/* 482 */     this.log.info("@ECI            = " + getEci());
/* 483 */     this.log.info("@E28            = " + getE28());
/* 484 */     this.log.info("@E29            = " + getE29());
/* 485 */     this.log.info("@Redemordernum         = " + getRedemordernum());
/* 486 */     this.log.info("@Redem_discount_point  = " + getRedem_discount_point());
/* 487 */     this.log.info("@Redem_discount_amount = " + getRedem_discount_amount());
/* 488 */     this.log.info("@Redem_purchase_amount = " + getRedem_purchase_amount());
/* 489 */     this.log.info("@Redem_balance_point   = " + getRedem_balance_point());
/*     */   }
/*     */ 
/*     */   private static boolean isInteger(String str) {
/* 493 */     Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
/* 494 */     return pattern.matcher(str).matches();
/*     */   }
/*     */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.b2cpay.B2CPayAuthSSL
 * JD-Core Version:    0.6.0
 */