/*    */ package com.hitrust.b2ctoolkit.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.util.Properties;
/*    */ 
/*    */ public class HiServer3
/*    */ {
/* 22 */   private static boolean file_Err_Flag = false;
/* 23 */   private static boolean element_Err_Flag = false;
/*    */   private static String IP;
/*    */   private static String Port;
/*    */   private static String RSAName;
/*    */   private static String AuthUrl;
/*    */   private static String OtherUrl;
/*    */   private static Properties pro;
/*    */   private static String ConnectionTimeout;
/*    */   private static String readTimeout;
/*    */ 
/*    */   private static void checkData()
/*    */     throws ToolkitException
/*    */   {
/* 26 */     if (file_Err_Flag)
/* 27 */       throw new ToolkitException("-21");
/* 28 */     if (element_Err_Flag)
/* 29 */       throw new ToolkitException("-24");
/*    */   }
/*    */ 
/*    */   public static String getIP()
/*    */     throws ToolkitException
/*    */   {
/* 44 */     checkData();
/* 45 */     return IP;
/*    */   }
/*    */ 
/*    */   public static int getPort() throws ToolkitException {
/* 49 */     checkData();
/*    */     try
/*    */     {
/* 52 */       port = Integer.parseInt(Port);
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */       int port;
/* 54 */       throw new ToolkitException("-24");
/*    */     }
/*    */     int port;
/* 56 */     return port;
/*    */   }
/*    */ 
/*    */   public static String getRSAName() throws ToolkitException
/*    */   {
/* 61 */     checkData();
/* 62 */     File RSAFile = new File(RSAName);
/* 63 */     if (!RSAFile.exists()) {
/* 64 */       throw new ToolkitException("-22");
/*    */     }
/* 66 */     return RSAName;
/*    */   }
/*    */ 
/*    */   public static String getAuthUrl() throws ToolkitException
/*    */   {
/* 71 */     checkData();
/* 72 */     return AuthUrl;
/*    */   }
/*    */ 
/*    */   public static String getOtherUrl()
/*    */     throws ToolkitException
/*    */   {
/* 79 */     checkData();
/* 80 */     return OtherUrl;
/*    */   }
/*    */ 
/*    */   public static String getConnectionTimeout()
/*    */   {
/* 86 */     return ConnectionTimeout;
/*    */   }
/*    */ 
/*    */   public static String getReadTimeout()
/*    */   {
/* 91 */     return readTimeout;
/*    */   }
/*    */ 
/*    */   static {
/*    */     try {
/* 96 */       String path = "HiServer.conf";
/* 97 */       pro = new Properties();
/* 98 */       pro.load(HiServer3.class.getClassLoader().getResourceAsStream(path));
/* 99 */       IP = pro.getProperty("IP");
/* 100 */       Port = pro.getProperty("Port");
/* 101 */       RSAName = pro.getProperty("RSAName");
/* 102 */       AuthUrl = pro.getProperty("AuthUrl");
/* 103 */       OtherUrl = pro.getProperty("OtherUrl");
/* 104 */       ConnectionTimeout = pro.getProperty("ConnectionTimeout");
/* 105 */       readTimeout = pro.getProperty("readTimeout");
/* 106 */       if ((IP == null) || (Port == null) || (RSAName == null) || (AuthUrl == null) || (OtherUrl == null))
/*    */       {
/* 108 */         element_Err_Flag = true;
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 112 */       file_Err_Flag = true;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\Private\購物車\creditcard\CreditCard_toolkit_JAVA_TW_V3.0.8\Java\lib\toolkit-1.0.jar
 * Qualified Name:     com.hitrust.b2ctoolkit.util.HiServer3
 * JD-Core Version:    0.6.0
 */